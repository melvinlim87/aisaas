# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2024-01-15

### Added
- User authentication system with login, logout, and password reset
- Sub-account user management with role-based access control
- Email-based invitation system for sub-account users
- Password change functionality for existing users
- Protected routes requiring authentication
- User profile management
- Role-based permissions system
- Sub-account user invitation and acceptance flow
- Email notifications for password resets and invitations

### Changed
- Updated header component to include user profile menu
- Enhanced sub-account management with user list and permissions
- Improved routing system with authentication guards

### Fixed
- Fixed issue with session persistence after page reload
- Corrected sub-account permission inheritance
- Fixed email template rendering issues

## [1.0.0] - 2024-01-01

### Added
- Initial release with core features
- AI-powered chatbot integration
- CRM system with contact management
- Knowledge base functionality
- Appointment scheduling system
- Analytics dashboard with real-time metrics
- Multi-channel conversation support
- Live agent dashboard
- Ticket management system
- Custom chart builder
- Theme customization options
- Workflow automation tools
- Calendar integration
- Email notification system
- File upload and training capabilities
- Real-time chat interface
- Support for multiple chat channels (web, WhatsApp, Messenger, Instagram)

### Technical Features
- React with TypeScript implementation
- Tailwind CSS for styling
- Lucide icons integration
- Chart.js for analytics visualization
- React Router for navigation
- React Grid Layout for dashboard customization
- React Beautiful DnD for drag-and-drop interfaces
- React Markdown for content rendering
- Toast notifications
- WebSocket support for real-time features
- Service worker for offline capabilities
- Local storage persistence
- Responsive design across all devices

## Types of Changes
- `Added` for new features
- `Changed` for changes in existing functionality
- `Deprecated` for soon-to-be removed features
- `Removed` for now removed features
- `Fixed` for any bug fixes
- `Security` in case of vulnerabilities

## Version Number Format
- Major version (X.0.0) - Incompatible API changes
- Minor version (0.X.0) - Added functionality in a backward compatible manner
- Patch version (0.0.X) - Bug fixes and minor improvements