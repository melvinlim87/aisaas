import { create } from 'zustand';

interface AIModel {
  id: string;
  name: string;
  baseCost: number;
  markup: number;
}

interface StoreState {
  openAIKey: string;
  setOpenAIKey: (key: string) => void;
  selectedModel: string;
  setSelectedModel: (model: string) => void;
  models: AIModel[];
  updateModelMarkup: (modelId: string, markup: number) => void;
}

export const useStore = create<StoreState>((set) => ({
  openAIKey: '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',
  setOpenAIKey: (key) => set({ openAIKey: key }),
  selectedModel: 'gpt4-mini',
  setSelectedModel: (model) => set({ selectedModel: model }),
  models: [
    { id: 'gpt4-mini', name: 'GPT-4 Mini', baseCost: 0.001, markup: 0.0005 },
    { id: 'gpt4-turbo', name: 'GPT-4 Turbo', baseCost: 0.002, markup: 0.001 },
    { id: 'llama-3', name: 'Llama 3', baseCost: 0.0005, markup: 0.0002 }
  ],
  updateModelMarkup: (modelId, markup) => 
    set((state) => ({
      models: state.models.map(model =>
        model.id === modelId ? { ...model, markup } : model
      )
    }))
}));