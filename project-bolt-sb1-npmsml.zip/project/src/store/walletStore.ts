import { create } from 'zustand';
import { WalletBalance, WalletTransaction } from '../types/wallet';

interface WalletState {
  balance: WalletBalance | null;
  transactions: WalletTransaction[];
  setBalance: (balance: WalletBalance) => void;
  setTransactions: (transactions: WalletTransaction[]) => void;
  addTransaction: (transaction: WalletTransaction) => void;
  updateBalance: (amount: number) => void;
}

export const useWalletStore = create<WalletState>((set) => ({
  balance: null,
  transactions: [],
  setBalance: (balance) => set({ balance }),
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (transaction) => set((state) => ({
    transactions: [transaction, ...state.transactions]
  })),
  updateBalance: (amount) => set((state) => ({
    balance: state.balance ? {
      ...state.balance,
      amount,
      updatedAt: new Date()
    } : null
  }))
}));