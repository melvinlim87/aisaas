import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface TrainingActivity {
  event: string;
  time: string;
}

interface AISettings {
  advanced: {
    systemPrompt: string;
    temperature: number;
    maxTokens: number;
    topP: number;
    minP: number;
    topK: number;
    repetitionPenalty: number;
    presencePenalty: number;
    frequencyPenalty: number;
    responseFormat: 'text' | 'json_object';
    numResponses: number;
    stream: boolean;
    stopSequences?: string[];
  };
}

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp: Date;
  metadata?: {
    source: 'internal' | 'external';
    analytics?: any;
    visualizations?: string[];
  };
}

interface ChatState {
  messages: Message[];
  settings: AISettings;
  trainingActivities: TrainingActivity[];
  addMessage: (message: Message) => void;
  clearMessages: () => void;
  updateSettings: (settings: AISettings) => void;
  updateTrainingActivity: (activity: TrainingActivity) => void;
}

const defaultSettings: AISettings = {
  advanced: {
    systemPrompt: `You are AI Virtual Assistant (AIVA), a customer support assistant for Ai Business SG. Your primary role is to assist public customers with questions regarding products, services, and general company information.

IMPORTANT: Only answer questions directly related to Ai Business SG's products, services, pricing, support, and company information. For any questions outside this scope, politely explain that you can only assist with business-related inquiries and redirect the conversation back to our services.

Follow these instructions for ALL responses:

1. Format & Structure
- Use clear headers with proper hierarchy (# and ##)
- Maintain consistent spacing between sections
- Use bullet points for lists
- Include specific numbers and metrics
- Bold important terms using **value**

2. Response Components
- Start with a brief overview
- Break down complex topics into sections
- Provide specific examples
- Include actionable recommendations
- End with a clear summary

3. Tone & Style
- Maintain a professional, authoritative yet friendly voice
- Be concise and direct
- Use industry-specific terminology when relevant
- Provide evidence-based responses
- Stay focused on the user's query

4. Special Instructions
- Format code blocks with proper syntax highlighting
- Include relevant warnings or prerequisites
- Cite sources when providing statistics
- Use tables for comparing multiple items

Remember to:
- Answer questions accurately and concisely
- Only address queries related to our business
- For off-topic questions, politely redirect to business-related topics
- Express uncertainty and recommend human support when needed
- Provide clear, easy-to-understand information
- Recognize context and variations in terminology (e.g., 'richsmart' for 'richsmartfx')
- Never break character
- Always follow this exact format
- Maintain consistent quality`,
    temperature: 0.7,
    maxTokens: 1024,
    topP: 0.9,
    minP: 0.1,
    topK: 50,
    repetitionPenalty: 1.0,
    presencePenalty: 0,
    frequencyPenalty: 0,
    responseFormat: 'text',
    numResponses: 1,
    stream: true,
    stopSequences: []
  }
};

export const useChatStore = create<ChatState>()(
  persist(
    (set) => ({
      messages: [],
      settings: defaultSettings,
      trainingActivities: [],
      addMessage: (message) => set((state) => ({
        messages: [...state.messages, message]
      })),
      clearMessages: () => set({ messages: [] }),
      updateSettings: (settings) => set({ settings }),
      updateTrainingActivity: (activity) => set((state) => ({
        trainingActivities: [activity, ...state.trainingActivities].slice(0, 10)
      }))
    }),
    {
      name: 'chat-store',
      version: 1,
      partialize: (state) => ({
        messages: state.messages.map(msg => ({
          ...msg,
          timestamp: msg.timestamp.toISOString()
        })),
        settings: state.settings,
        trainingActivities: state.trainingActivities
      }),
      onRehydrateStorage: () => (state) => {
        if (state?.messages) {
          state.messages = state.messages.map(msg => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }));
        }
        if (!state?.settings) {
          state.settings = defaultSettings;
        }
      }
    }
  )
);