import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface ChartConfig {
  id: string;
  type: 'line' | 'bar' | 'pie';
  title: string;
  data: {
    labels: string[];
    datasets: Array<{
      label: string;
      data: number[];
      backgroundColor?: string[];
      borderColor?: string;
      fill?: boolean;
    }>;
  };
}

interface ChartStore {
  charts: ChartConfig[];
  addChart: (chart: ChartConfig) => void;
  updateChart: (chart: ChartConfig) => void;
  deleteChart: (chartId: string) => void;
}

export const useChartStore = create<ChartStore>()(
  persist(
    (set) => ({
      charts: [],
      addChart: (chart) => set((state) => ({
        charts: [...state.charts, chart]
      })),
      updateChart: (chart) => set((state) => ({
        charts: state.charts.map((c) => 
          c.id === chart.id ? chart : c
        )
      })),
      deleteChart: (chartId) => set((state) => ({
        charts: state.charts.filter((c) => c.id !== chartId)
      }))
    }),
    {
      name: 'custom-charts',
      version: 1
    }
  )
);