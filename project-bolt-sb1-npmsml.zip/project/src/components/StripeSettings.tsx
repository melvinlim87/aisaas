import React, { useState } from 'react';
import { CreditCard, Key, Globe, Save } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface StripeConfig {
  publicKey: string;
  secretKey: string;
  webhookSecret: string;
  enableTestMode: boolean;
  allowedPaymentMethods: string[];
  currency: string;
}

const StripeSettings: React.FC = () => {
  const [config, setConfig] = useState<StripeConfig>({
    publicKey: '',
    secretKey: '',
    webhookSecret: '',
    enableTestMode: true,
    allowedPaymentMethods: ['card'],
    currency: 'USD'
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      // Here you would implement the actual API call to save Stripe settings
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulated API call
      toast.success('Stripe settings saved successfully!');
    } catch (error) {
      toast.error('Failed to save Stripe settings');
      console.error('Error saving Stripe settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const paymentMethods = [
    { id: 'card', label: 'Credit/Debit Cards' },
    { id: 'sepa', label: 'SEPA Direct Debit' },
    { id: 'ideal', label: 'iDEAL' },
    { id: 'bancontact', label: 'Bancontact' },
    { id: 'giropay', label: 'Giropay' }
  ];

  const currencies = [
    { code: 'USD', label: 'US Dollar' },
    { code: 'EUR', label: 'Euro' },
    { code: 'GBP', label: 'British Pound' },
    { code: 'AUD', label: 'Australian Dollar' },
    { code: 'CAD', label: 'Canadian Dollar' }
  ];

  return (
    <div className="space-y-6">
      {/* API Keys */}
      <div className="border rounded-lg p-4">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Key className="h-5 w-5 mr-2" />
          Stripe API Keys
        </h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Public Key (Publishable)
            </label>
            <input
              type="text"
              value={config.publicKey}
              onChange={(e) => setConfig({ ...config, publicKey: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="pk_test_..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Secret Key
            </label>
            <input
              type="password"
              value={config.secretKey}
              onChange={(e) => setConfig({ ...config, secretKey: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="sk_test_..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Webhook Secret
            </label>
            <input
              type="password"
              value={config.webhookSecret}
              onChange={(e) => setConfig({ ...config, webhookSecret: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="whsec_..."
            />
          </div>
        </div>
      </div>

      {/* Payment Methods */}
      <div className="border rounded-lg p-4">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <CreditCard className="h-5 w-5 mr-2" />
          Payment Methods
        </h3>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {paymentMethods.map((method) => (
              <div key={method.id} className="flex items-center">
                <input
                  type="checkbox"
                  id={`method-${method.id}`}
                  checked={config.allowedPaymentMethods.includes(method.id)}
                  onChange={(e) => {
                    const methods = e.target.checked
                      ? [...config.allowedPaymentMethods, method.id]
                      : config.allowedPaymentMethods.filter(m => m !== method.id);
                    setConfig({ ...config, allowedPaymentMethods: methods });
                  }}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor={`method-${method.id}`} className="ml-2 text-sm text-gray-700">
                  {method.label}
                </label>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* General Settings */}
      <div className="border rounded-lg p-4">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Globe className="h-5 w-5 mr-2" />
          General Settings
        </h3>
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="test-mode"
              checked={config.enableTestMode}
              onChange={(e) => setConfig({ ...config, enableTestMode: e.target.checked })}
              className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="test-mode" className="ml-2 text-sm text-gray-700">
              Enable Test Mode
            </label>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Default Currency
            </label>
            <select
              value={config.currency}
              onChange={(e) => setConfig({ ...config, currency: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              {currencies.map((currency) => (
                <option key={currency.code} value={currency.code}>
                  {currency.label} ({currency.code})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center disabled:opacity-50"
        >
          <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
          {isSaving ? 'Saving...' : 'Save Stripe Settings'}
        </button>
      </div>
    </div>
  );
};

export default StripeSettings;