import React from 'react';
import { User } from 'lucide-react';
import toast from 'react-hot-toast';

interface LiveChatTransferButtonProps {
  onTransfer: () => void;
  isTransferring: boolean;
}

const LiveChatTransferButton: React.FC<LiveChatTransferButtonProps> = ({ onTransfer, isTransferring }) => {
  return (
    <button
      onClick={onTransfer}
      disabled={isTransferring}
      className="flex items-center px-3 py-2 text-sm text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors duration-200"
    >
      <User className="h-4 w-4 mr-2" />
      {isTransferring ? 'Connecting to agent...' : 'Talk to a Live Agent'}
    </button>
  );
};

export default LiveChatTransferButton;