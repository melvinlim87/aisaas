import React, { useState } from 'react';
import { Key, Eye, EyeOff, Save } from 'lucide-react';
import { generateSecurePassword } from '../utils/passwordUtils';
import toast from 'react-hot-toast';

interface SubAccountCredentialsProps {
  subAccountId: string;
  email: string;
  onCredentialsUpdate: (credentials: { username: string; password: string }) => void;
  onClose: () => void;
}

const SubAccountCredentials: React.FC<SubAccountCredentialsProps> = ({
  subAccountId,
  email,
  onCredentialsUpdate,
  onClose
}) => {
  const [username, setUsername] = useState(email);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGeneratePassword = () => {
    setIsGenerating(true);
    try {
      const newPassword = generateSecurePassword();
      setPassword(newPassword);
      toast.success('Password generated successfully');
    } catch (error) {
      toast.error('Failed to generate password');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onCredentialsUpdate({ username, password });
      toast.success('Login credentials updated successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to update login credentials');
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold flex items-center">
            <Key className="h-5 w-5 mr-2" />
            Login Credentials
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Username/Email
            </label>
            <input
              type="email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="block w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 px-3 flex items-center"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={handleGeneratePassword}
            disabled={isGenerating}
            className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {isGenerating ? (
              'Generating...'
            ) : (
              'Generate Secure Password'
            )}
          </button>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Credentials
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SubAccountCredentials;