import React, { useState } from 'react';
import { Upload, AlertCircle, Link as LinkIcon, FileText, ChevronDown, ChevronUp, Search, CheckCircle, XCircle } from 'lucide-react';
import { trainWithUrl } from '../services/trainingService';
import { useChatStore } from '../store/chatStore';
import { discoverPages, DiscoveredPage } from '../services/pageDiscoveryService';
import toast from 'react-hot-toast';

interface TrainingLog {
  url: string;
  displayPath: string;
  status: 'success' | 'error';
  content?: string;
  timestamp: Date;
}

interface UrlTrainingProps {
  onTrainingComplete: () => void;
}

const UrlTraining: React.FC<UrlTrainingProps> = ({ onTrainingComplete }) => {
  const [url, setUrl] = useState('');
  const [isTraining, setIsTraining] = useState(false);
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('');
  const [trainingLogs, setTrainingLogs] = useState<TrainingLog[]>([]);
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [discoveredPages, setDiscoveredPages] = useState<DiscoveredPage[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { updateTrainingActivity } = useChatStore();

  const handleDiscover = async () => {
    if (!url) {
      setError('Please enter a valid URL');
      return;
    }

    setIsDiscovering(true);
    setError(null);
    setStatusMessage('Discovering pages...');

    try {
      const pages = await discoverPages(url);
      setDiscoveredPages(pages);
      toast.success(`Discovered ${pages.length} pages`);
    } catch (error) {
      const errorMessage = error instanceof Error 
        ? error.message 
        : 'Failed to discover pages. Please check the URL and try again.';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsDiscovering(false);
    }
  };

  const handleTrain = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      setError('Please enter a valid URL');
      return;
    }

    const selectedPages = discoveredPages.filter(page => page.selected);
    if (discoveredPages.length > 0 && selectedPages.length === 0) {
      setError('Please select at least one page to train');
      return;
    }

    try {
      const baseUrl = new URL(url).origin;
      setIsTraining(true);
      setError(null);
      setProgress(0);
      setStatusMessage('Initializing training...');

      const pagesToTrain = selectedPages.length > 0 ? selectedPages : [{
        url,
        displayPath: '/',
        title: 'Home',
        selected: true
      }];
      
      let completedPages = 0;

      for (const page of pagesToTrain) {
        await trainWithUrl(
          page.url,
          {
            maxDepth: 1,
            excludePaths: ['/api', '/admin'],
            includeImages: false
          },
          (progressUpdate) => {
            const overallProgress = (completedPages + progressUpdate.progress / 100) / pagesToTrain.length * 100;
            setProgress(overallProgress);
            setStatusMessage(`Processing ${page.displayPath}... (${Math.round(progressUpdate.progress)}%)`);
            
            if (progressUpdate.status === 'error') {
              toast.error(`Failed to process ${page.displayPath}`);
            }

            if (progressUpdate.content) {
              setTrainingLogs(prev => [{
                url: page.url,
                displayPath: page.displayPath,
                status: 'success',
                content: progressUpdate.content,
                timestamp: new Date()
              }, ...prev]);
            }
          }
        );
        completedPages++;
      }

      updateTrainingActivity({
        event: `Completed training for ${pagesToTrain.length} pages from ${url}`,
        time: new Date().toISOString()
      });

      toast.success('Training completed successfully');
      onTrainingComplete();
      setUrl('');
      setDiscoveredPages([]);
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to train with URL';
      setError(errorMessage);
      setTrainingLogs(prev => [{
        url,
        displayPath: '/',
        status: 'error',
        timestamp: new Date()
      }, ...prev]);
      toast.error(errorMessage);
    } finally {
      setIsTraining(false);
      setProgress(0);
      setStatusMessage('');
    }
  };

  const toggleLogExpansion = (url: string) => {
    setExpandedLog(expandedLog === url ? null : url);
  };

  const togglePageSelection = (url: string) => {
    setDiscoveredPages(pages =>
      pages.map(page =>
        page.url === url ? { ...page, selected: !page.selected } : page
      )
    );
  };

  const toggleAllPages = (selected: boolean) => {
    setDiscoveredPages(pages =>
      pages.map(page => ({ ...page, selected }))
    );
  };

  const filteredPages = discoveredPages.filter(page =>
    page.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    page.displayPath.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <form onSubmit={handleTrain} className="space-y-4">
        <div className="flex gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <LinkIcon className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Enter website URL to train"
              className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              disabled={isTraining || isDiscovering}
            />
          </div>
          <button
            type="button"
            onClick={handleDiscover}
            disabled={isDiscovering || isTraining || !url}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center"
          >
            <Search className={`h-5 w-5 mr-2 ${isDiscovering ? 'animate-spin' : ''}`} />
            {isDiscovering ? 'Discovering...' : 'Discover Pages'}
          </button>
          <button
            type="submit"
            disabled={isTraining || isDiscovering || !url}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 flex items-center"
          >
            <Upload className={`h-5 w-5 mr-2 ${isTraining ? 'animate-spin' : ''}`} />
            {isTraining ? 'Training...' : 'Train'}
          </button>
        </div>

        {discoveredPages.length > 0 && (
          <div className="border rounded-lg p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Discovered Pages</h3>
              <div className="flex items-center space-x-4">
                <button
                  type="button"
                  onClick={() => toggleAllPages(true)}
                  className="text-sm text-indigo-600 hover:text-indigo-700"
                >
                  Select All
                </button>
                <button
                  type="button"
                  onClick={() => toggleAllPages(false)}
                  className="text-sm text-indigo-600 hover:text-indigo-700"
                >
                  Deselect All
                </button>
              </div>
            </div>
            
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search pages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2">
              {filteredPages.map((page) => (
                <div
                  key={page.url}
                  className="flex items-center p-2 hover:bg-gray-50 rounded-lg cursor-pointer"
                  onClick={() => togglePageSelection(page.url)}
                >
                  <div className={`w-5 h-5 rounded border mr-3 flex items-center justify-center ${
                    page.selected ? 'bg-indigo-600 border-indigo-600' : 'border-gray-300'
                  }`}>
                    {page.selected && <CheckCircle className="w-4 h-4 text-white" />}
                  </div>
                  <div className="flex-1 truncate">
                    <div className="font-medium text-sm">{page.displayPath}</div>
                    <div className="text-xs text-gray-500 truncate">{page.title}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {(isTraining || isDiscovering) && (
          <div className="space-y-2">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-sm text-gray-600 text-center">
              {statusMessage} ({Math.round(progress)}%)
            </p>
          </div>
        )}
      </form>

      {error && (
        <div className="flex items-center text-red-500 text-sm bg-red-50 p-3 rounded-lg">
          <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Training Logs */}
      {trainingLogs.length > 0 && (
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-indigo-500" />
              Training Logs
            </h3>
          </div>
          <div className="divide-y divide-gray-200">
            {trainingLogs.map((log, index) => (
              <div key={index} className="p-4">
                <div 
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleLogExpansion(log.url)}
                >
                  <div className="flex items-center space-x-3">
                    {log.status === 'success' ? (
                      <div className="flex items-center text-green-500">
                        <CheckCircle className="h-5 w-5" />
                        <span className="ml-2 text-sm font-medium text-green-600">Successfully Trained</span>
                      </div>
                    ) : (
                      <div className="flex items-center text-red-500">
                        <XCircle className="h-5 w-5" />
                        <span className="ml-2 text-sm font-medium text-red-600">Training Failed</span>
                      </div>
                    )}
                    <span className="font-medium text-gray-900">{log.displayPath}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-500">
                      {log.timestamp.toLocaleTimeString()}
                    </span>
                    {log.content && (
                      expandedLog === log.url ? 
                        <ChevronUp className="h-5 w-5 text-gray-400" /> :
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </div>
                {expandedLog === log.url && log.content && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">
                      {log.content.slice(0, 500)}...
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default UrlTraining;