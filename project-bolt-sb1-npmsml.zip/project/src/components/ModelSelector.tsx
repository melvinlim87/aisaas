import React from 'react';
import { AI_MODELS } from '../config/constants';
import { useStore } from '../store/useStore';

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (modelId: string) => void;
  hasImage: boolean;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onModelChange, hasImage }) => {
  const openAIKey = useStore(state => state.openAIKey);

  return (
    <div className="flex items-center space-x-2 mb-4">
      <span className="text-sm font-medium text-gray-700">AI Model:</span>
      <select
        value={selectedModel}
        onChange={(e) => onModelChange(e.target.value)}
        className="block w-48 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
      >
        {Object.values(AI_MODELS)
          .filter(model => {
            // Show all models that either:
            // 1. Support vision if we have an image
            // 2. Are from DeepInfra
            // 3. Are from OpenAI if we have an API key
            return (!hasImage || model.supportsVision) && 
                   (model.provider === 'deepinfra' || 
                    (model.provider === 'openai' && openAIKey));
          })
          .map(model => (
            <option key={model.id} value={model.id}>
              {model.name}
            </option>
          ))}
      </select>
    </div>
  );
};

export default ModelSelector;