import React, { useState } from 'react';
import { Save, Play, Book, AlertCircle, CheckCircle } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import { chatbotService } from '../services/chatbotService';
import toast from 'react-hot-toast';
import ReactMarkdown from 'react-markdown';

const PromptEditor: React.FC = () => {
  const { settings, updateSettings } = useChatStore();
  const [testMessage, setTestMessage] = useState('');
  const [testResponse, setTestResponse] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const handleSave = async () => {
    try {
      await updateSettings(settings);
      toast.success('System prompt updated successfully');
    } catch (error) {
      console.error('Error saving prompt:', error);
      toast.error('Failed to save system prompt');
    }
  };

  const handleTest = async () => {
    if (!testMessage.trim()) {
      toast.error('Please enter a test message');
      return;
    }

    setIsTesting(true);
    try {
      const response = await chatbotService.testPrompt(settings.advanced.systemPrompt, testMessage);
      setTestResponse(response.content);
      toast.success('Test completed successfully');
    } catch (error) {
      console.error('Error testing prompt:', error);
      toast.error('Failed to test prompt');
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="h-full flex">
      {/* Prompt Editor */}
      <div className="flex-1 p-6 border-r overflow-y-auto">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">System Prompt</h2>
            <div className="flex space-x-2">
              <button
                onClick={() => setShowGuide(true)}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center"
              >
                <Book className="h-5 w-5 mr-2" />
                View Guide
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center"
              >
                <Save className="h-5 w-5 mr-2" />
                Save Prompt
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center text-sm text-gray-600 mb-2">
                <AlertCircle className="h-4 w-4 mr-2 text-indigo-500" />
                This prompt defines how the AI Analytics Assistant interprets and responds to queries.
              </div>
            </div>

            <textarea
              value={settings.advanced.systemPrompt}
              onChange={(e) => updateSettings({
                ...settings,
                advanced: { ...settings.advanced, systemPrompt: e.target.value }
              })}
              className="w-full h-[400px] font-mono text-sm rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="Enter your system prompt..."
            />
          </div>

          {/* Test Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Test Prompt</h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                placeholder="Enter a test message..."
                className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
              <button
                onClick={handleTest}
                disabled={isTesting}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center disabled:opacity-50"
              >
                <Play className="h-5 w-5 mr-2" />
                {isTesting ? 'Testing...' : 'Test'}
              </button>
            </div>

            {testResponse && (
              <div className="bg-gray-50 rounded-lg p-4 mt-4">
                <div className="flex items-center mb-2">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <h4 className="font-medium">Test Response</h4>
                </div>
                <div className="prose max-w-none">
                  <ReactMarkdown>{testResponse}</ReactMarkdown>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Guide Panel */}
      {showGuide && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-3xl h-[80vh] flex flex-col">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-xl font-semibold">Analytics Assistant Guide</h2>
              <button
                onClick={() => setShowGuide(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ×
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <div className="prose max-w-none">
                <h3>Prompt Structure</h3>
                <p>The system prompt should include:</p>
                <ul>
                  <li>Clear definition of the assistant's role and capabilities</li>
                  <li>Specific instructions for handling analytics queries</li>
                  <li>Data interpretation guidelines</li>
                  <li>Response formatting requirements</li>
                </ul>

                <h3>Best Practices</h3>
                <ul>
                  <li>Use clear section headers</li>
                  <li>Include specific metrics and KPIs</li>
                  <li>Define visualization preferences</li>
                  <li>Specify data source handling</li>
                  <li>Include error handling instructions</li>
                </ul>

                <h3>Example Sections</h3>
                <pre className="bg-gray-50 p-4 rounded-lg">
{`# Role Definition
You are an AI Analytics Assistant specializing in business metrics...

# Data Sources
Access and analyze data from:
- Revenue metrics
- User engagement
- Customer feedback
- Performance indicators

# Response Format
1. Executive Summary
2. Key Metrics
3. Trend Analysis
4. Recommendations

# Visualization Guidelines
- Use appropriate chart types
- Include clear labels
- Highlight key trends
- Provide context for metrics`}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptEditor;