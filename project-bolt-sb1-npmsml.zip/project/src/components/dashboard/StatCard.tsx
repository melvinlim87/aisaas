import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  icon: LucideIcon;
  iconColor: string;
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'neutral' | 'negative';
}

const StatCard: React.FC<StatCardProps> = ({ icon: Icon, iconColor, title, value, change, changeType }) => {
  const changeColors = {
    positive: 'text-emerald-400',
    neutral: 'text-amber-400',
    negative: 'text-rose-400'
  };

  return (
    <div className="stat-card rounded-lg p-6 transition-all duration-200">
      <div className="flex items-center">
        <Icon className={`h-8 w-8 ${iconColor}`} />
        <div className="ml-4">
          <p className="text-sm font-medium text-secondary">{title}</p>
          <h3 className="text-xl font-bold text-primary">{value}</h3>
          <p className={`text-sm ${changeColors[changeType]}`}>{change}</p>
        </div>
      </div>
    </div>
  );
};

export default StatCard;