import React from 'react';
import { LucideIcon, BarChart } from 'lucide-react';
import { Line, Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import DashboardWidget from './DashboardWidget';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface ChartWidgetProps {
  title: string;
  icon?: LucideIcon;
  config: any;
  isCustomizing?: boolean;
}

const ChartWidget: React.FC<ChartWidgetProps> = ({ title, icon, config, isCustomizing }) => {
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: {
            size: 12
          }
        }
      }
    },
    scales: {
      y: {
        grid: {
          color: 'rgba(139, 92, 246, 0.1)'
        },
        beginAtZero: true
      },
      x: {
        grid: {
          display: false
        }
      }
    }
  };

  const renderChart = () => {
    switch (config.type) {
      case 'line':
        return <Line data={config.data} options={chartOptions} />;
      case 'bar':
        return <Bar data={config.data} options={chartOptions} />;
      case 'pie':
        return <Pie data={config.data} options={chartOptions} />;
      default:
        return null;
    }
  };

  return (
    <DashboardWidget title={title} icon={icon || BarChart} isCustomizing={isCustomizing}>
      <div className="h-[calc(100%-2rem)] w-full pt-2">
        {renderChart()}
      </div>
    </DashboardWidget>
  );
};

export default ChartWidget;