import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import DualChatInterface from '../DualChatInterface';
import DashboardWidget from './DashboardWidget';

interface AnalyticsWidgetProps {
  isCustomizing?: boolean;
}

const AnalyticsWidget: React.FC<AnalyticsWidgetProps> = ({ isCustomizing }) => {
  const [showChat, setShowChat] = useState(false);
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setShowChat(true);
    }
  };

  const gradientButtonClass = `
    flex items-center px-4 py-2 rounded-lg text-white
    bg-gradient-to-r from-indigo-600 to-purple-600
    hover:from-indigo-500 hover:to-purple-500
    focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
    transition-all duration-200 shadow-lg
    hover:shadow-xl
    disabled:opacity-50 disabled:cursor-not-allowed
  `;

  return (
    <>
      <DashboardWidget title="AI Analytics Assistant" isCustomizing={isCustomizing}>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask about analytics, metrics, or performance..."
            className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          />
          <button
            type="submit"
            disabled={!query.trim()}
            className={gradientButtonClass}
          >
            <Search className="h-5 w-5 mr-2" />
            Analyze
          </button>
        </form>
      </DashboardWidget>

      {/* Chat Popup */}
      {showChat && (
        <>
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30" 
            onClick={() => setShowChat(false)} 
          />
          
          {/* Popup Container */}
          <div className="fixed inset-4 md:inset-auto md:right-4 md:bottom-4 md:top-auto md:left-auto md:w-[600px] md:h-[600px] bg-white rounded-lg shadow-xl z-40 flex flex-col overflow-hidden">
            {/* Popup Header */}
            <div className="flex-none px-4 py-3 border-b border-gray-200 flex justify-between items-center bg-white">
              <h3 className="font-semibold">Analytics Assistant</h3>
              <button
                onClick={() => setShowChat(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors p-1 rounded-lg hover:bg-gray-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Chat Interface Container */}
            <div className="flex-1 overflow-hidden">
              <DualChatInterface initialQuery={query} />
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default AnalyticsWidget;