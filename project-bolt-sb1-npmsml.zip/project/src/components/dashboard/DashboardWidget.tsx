import React from 'react';
import { LucideIcon, GripVertical } from 'lucide-react';

interface DashboardWidgetProps {
  title: string;
  icon?: LucideIcon;
  isCustomizing?: boolean;
  children: React.ReactNode;
}

const DashboardWidget: React.FC<DashboardWidgetProps> = ({
  title,
  icon: Icon,
  isCustomizing,
  children
}) => {
  return (
    <div className="dashboard-widget h-full flex flex-col">
      <div className="widget-header flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center">
          {Icon && <Icon className="h-5 w-5 mr-2 text-indigo-400" />}
          <h3 className="font-semibold text-primary">{title}</h3>
        </div>
        {isCustomizing && (
          <div className="drag-handle">
            <GripVertical className="h-5 w-5 text-secondary" />
          </div>
        )}
      </div>
      <div className="widget-content flex-1 p-4">
        {children}
      </div>
    </div>
  );
};

export default DashboardWidget;