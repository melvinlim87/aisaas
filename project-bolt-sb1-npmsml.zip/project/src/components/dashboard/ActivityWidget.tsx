import React from 'react';
import { Activity, Clock } from 'lucide-react';
import DashboardWidget from './DashboardWidget';

interface ActivityItem {
  id: number;
  type: string;
  title: string;
  time: string;
}

interface ActivityWidgetProps {
  activities: ActivityItem[];
  isCustomizing?: boolean;
}

const ActivityWidget: React.FC<ActivityWidgetProps> = ({ activities, isCustomizing }) => {
  return (
    <DashboardWidget title="Recent Activity" icon={Activity} isCustomizing={isCustomizing}>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start">
            <div className="flex-shrink-0">
              <Clock className="h-5 w-5 text-gray-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-900">{activity.title}</p>
              <p className="text-sm text-gray-500">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    </DashboardWidget>
  );
};

export default ActivityWidget;