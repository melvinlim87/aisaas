import React from 'react';
import { ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { BillingTransaction } from '../../types/billing';

interface BillingTransactionsProps {
  transactions: BillingTransaction[];
}

const BillingTransactions: React.FC<BillingTransactionsProps> = ({ transactions }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-indigo-600" />
          Transaction History
        </h2>
      </div>

      <div className="divide-y divide-gray-200">
        {transactions.length > 0 ? (
          transactions.map((transaction) => (
            <div key={transaction.id} className="p-4 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  {transaction.type === 'credit' ? (
                    <ArrowUpRight className="h-5 w-5 text-green-500 mr-3" />
                  ) : (
                    <ArrowDownRight className="h-5 w-5 text-red-500 mr-3" />
                  )}
                  <div>
                    <p className="font-medium text-gray-900">{transaction.description}</p>
                    <p className="text-sm text-gray-500">
                      {transaction.createdAt.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className={`font-semibold ${
                  transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'credit' ? '+' : '-'}${transaction.amount.toFixed(2)}
                </div>
              </div>
              {transaction.metadata && (
                <div className="mt-2 ml-8 text-sm text-gray-500">
                  {transaction.metadata.aiModel && (
                    <span className="mr-4">Model: {transaction.metadata.aiModel}</span>
                  )}
                  {transaction.metadata.promptTokens && (
                    <span className="mr-4">Prompt Tokens: {transaction.metadata.promptTokens}</span>
                  )}
                  {transaction.metadata.completionTokens && (
                    <span>Completion Tokens: {transaction.metadata.completionTokens}</span>
                  )}
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="p-8 text-center text-gray-500">
            No transactions yet
          </div>
        )}
      </div>
    </div>
  );
};

export default BillingTransactions;