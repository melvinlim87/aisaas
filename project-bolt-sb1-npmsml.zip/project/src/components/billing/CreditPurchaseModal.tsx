import React, { useState } from 'react';
import { X, CreditCard, AlertCircle } from 'lucide-react';
import { billingService } from '../../services/billingService';
import { BillingSettings } from '../../types/billing';
import toast from 'react-hot-toast';

interface CreditPurchaseModalProps {
  subAccountId: string;
  onClose: () => void;
  onSuccess: () => void;
}

const CreditPurchaseModal: React.FC<CreditPurchaseModalProps> = ({
  subAccountId,
  onClose,
  onSuccess
}) => {
  const [amount, setAmount] = useState<number>(20);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<BillingSettings | null>(null);

  React.useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const billingSettings = await billingService.getBillingSettings();
      setSettings(billingSettings);
    } catch (error) {
      console.error('Error loading billing settings:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to load settings';
      setError(errorMessage);
    }
  };

  const presetAmounts = [10, 20, 50, 100];

  const handlePurchase = async () => {
    if (!settings) return;

    if (amount < settings.minPurchaseAmount || amount > settings.maxPurchaseAmount) {
      setError(`Amount must be between $${settings.minPurchaseAmount} and $${settings.maxPurchaseAmount}`);
      return;
    }

    try {
      setIsProcessing(true);
      setError(null);
      await billingService.purchaseCredits(subAccountId, amount, 'stripe');
      toast.success('Credits purchased successfully');
      onSuccess();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to purchase credits';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const calculateCredits = (purchaseAmount: number): number => {
    if (!settings) return 0;
    return Math.floor(purchaseAmount / settings.creditCost);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold flex items-center">
            <CreditCard className="h-6 w-6 mr-2" />
            Purchase Credits
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Amount
            </label>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {presetAmounts.map((preset) => (
                <button
                  key={preset}
                  onClick={() => setAmount(preset)}
                  className={`p-3 rounded-lg border text-center transition-colors ${
                    amount === preset
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                      : 'border-gray-200 hover:border-indigo-600'
                  }`}
                >
                  ${preset}
                  <div className="text-sm text-gray-500">
                    {calculateCredits(preset)} credits
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Custom Amount
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                $
              </span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Math.max(0, Number(e.target.value)))}
                className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                min={settings?.minPurchaseAmount || 0}
                max={settings?.maxPurchaseAmount || 1000}
                step="1"
              />
            </div>
            <p className="mt-1 text-sm text-gray-500">
              You will receive {calculateCredits(amount)} credits
            </p>
          </div>

          <button
            onClick={handlePurchase}
            disabled={isProcessing || amount <= 0 || !settings}
            className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="h-5 w-5 mr-2" />
                Purchase Credits
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreditPurchaseModal;