import React, { useState, useRef, useEffect } from 'react';
import { Send, Image, Paperclip, MoreVertical, User, Bot, MessageSquare, Phone, Mail } from 'lucide-react';
import { Conversation, Message } from '../types/chat';

interface ConversationViewProps {
  conversation: Conversation;
  onSendMessage: (content: string, attachments?: File[]) => Promise<void>;
}

const ConversationView: React.FC<ConversationViewProps> = ({ conversation, onSendMessage }) => {
  const [message, setMessage] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [conversation.messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!message.trim() && attachments.length === 0) return;

    try {
      setIsLoading(true);
      await onSendMessage(message, attachments);
      setMessage('');
      setAttachments([]);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'web':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'whatsapp':
        return <Phone className="h-5 w-5 text-green-500" />;
      case 'messenger':
        return <MessageSquare className="h-5 w-5 text-purple-500" />;
      case 'instagram':
        return <Mail className="h-5 w-5 text-pink-500" />;
      case 'telegram':
        return <MessageSquare className="h-5 w-5 text-blue-400" />;
      default:
        return <MessageSquare className="h-5 w-5 text-gray-500" />;
    }
  };

  const getChannelLabel = (channel: string) => {
    switch (channel) {
      case 'web':
        return 'Website Chat';
      case 'whatsapp':
        return 'WhatsApp';
      case 'messenger':
        return 'Messenger';
      case 'instagram':
        return 'Instagram';
      case 'telegram':
        return 'Telegram';
      default:
        return channel;
    }
  };

  const renderMessage = (message: Message) => {
    const isUser = message.role === 'user';
    const containerClass = isUser
      ? 'ml-auto bg-blue-500 text-white'
      : 'mr-auto bg-gray-100 text-gray-900';

    return (
      <div
        key={message.id}
        className={`max-w-[70%] rounded-lg p-3 mb-2 ${containerClass}`}
      >
        <div className="flex items-center mb-1">
          {!isUser && (
            <div className="flex items-center text-sm">
              {message.role === 'assistant' ? (
                <Bot className="h-4 w-4 mr-1" />
              ) : (
                <User className="h-4 w-4 mr-1" />
              )}
              <span className="font-medium">
                {message.role === 'assistant' ? 'AI Assistant' : 'Support Agent'}
              </span>
            </div>
          )}
        </div>
        <div className="break-words">{message.content}</div>
        {message.attachments?.map((attachment, index) => (
          <div key={index} className="mt-2">
            {attachment.type === 'image' ? (
              <img
                src={attachment.url}
                alt={attachment.name}
                className="max-w-full rounded"
              />
            ) : (
              <a
                href={attachment.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm underline"
              >
                {attachment.name}
              </a>
            )}
          </div>
        ))}
        <div className="text-xs opacity-75 mt-1">
          {message.timestamp.toLocaleTimeString()}
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Channel Indicator */}
      <div className="px-4 py-2 bg-gray-50 border-b flex items-center">
        {getChannelIcon(conversation.channel)}
        <span className="ml-2 text-sm font-medium text-gray-700">
          {getChannelLabel(conversation.channel)}
        </span>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversation.messages.map(renderMessage)}
        <div ref={messagesEndRef} />
      </div>

      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="px-4 py-2 border-t border-gray-200">
          <div className="flex flex-wrap gap-2">
            {attachments.map((file, index) => (
              <div
                key={index}
                className="flex items-center bg-gray-100 rounded px-2 py-1"
              >
                <span className="text-sm truncate max-w-xs">{file.name}</span>
                <button
                  onClick={() => removeAttachment(index)}
                  className="ml-2 text-gray-500 hover:text-red-500"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <input
            type="file"
            id="file-input"
            className="hidden"
            multiple
            onChange={handleFileSelect}
          />
          <button
            onClick={() => document.getElementById('file-input')?.click()}
            className="p-2 text-gray-400 hover:text-gray-600"
          >
            <Paperclip className="h-5 w-5" />
          </button>
          <button
            onClick={handleSend}
            disabled={isLoading || (!message.trim() && attachments.length === 0)}
            className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
          >
            <Send className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConversationView;