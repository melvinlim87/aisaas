// Rename file to LiveAgentTransferSettings.tsx
import React, { useState } from 'react';
import { MessageSquare, Bell, Globe, Save } from 'lucide-react';
import type { LiveAgentTransferSettings as LiveAgentTransferSettingsType } from '../types/ai';
import { liveAgentTransferService } from '../services/liveAgentTransferService';
import toast from 'react-hot-toast';

const LiveAgentTransferSettings: React.FC = () => {
  const [settings, setSettings] = useState<LiveAgentTransferSettingsType>(liveAgentTransferService.getSettings());
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      liveAgentTransferService.updateSettings(settings);
      toast.success('Live agent transfer settings saved successfully!');
    } catch (error) {
      console.error('Error saving live agent transfer settings:', error);
      toast.error('Failed to save live agent transfer settings');
    } finally {
      setIsSaving(false);
    }
  };

  // ... rest of the component code remains the same, just update text labels
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center">
          <MessageSquare className="h-6 w-6 mr-2" />
          Live Agent Transfer Settings
        </h2>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center disabled:opacity-50"
        >
          <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
          {isSaving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      {/* General Settings */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4">General Settings</h3>
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="enable-transfer"
              checked={settings.enabled}
              onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <label htmlFor="enable-transfer" className="ml-2 text-gray-700">
              Enable Live Agent Transfer
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Trigger Keywords (comma-separated)
            </label>
            <input
              type="text"
              value={settings.triggerKeywords.join(', ')}
              onChange={(e) => setSettings({
                ...settings,
                triggerKeywords: e.target.value.split(',').map(k => k.trim()).filter(Boolean)
              })}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Transfer Message
            </label>
            <input
              type="text"
              value={settings.transferMessage}
              onChange={(e) => setSettings({ ...settings, transferMessage: e.target.value })}
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Rest of the component remains the same */}
    </div>
  );
};

export default LiveAgentTransferSettings;