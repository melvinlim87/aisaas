import React, { useState, useRef } from 'react';
import { Upload, File, X, AlertCircle, FileText, ChevronDown, ChevronUp } from 'lucide-react';
import toast from 'react-hot-toast';

interface FileUploadProps {
  onTrainingComplete: () => void;
}

interface TrainingLog {
  fileName: string;
  status: 'success' | 'error';
  content?: string;
  timestamp: Date;
}

const FileUpload: React.FC<FileUploadProps> = ({ onTrainingComplete }) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isTraining, setIsTraining] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [trainingLogs, setTrainingLogs] = useState<TrainingLog[]>([]);
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const validFiles = selectedFiles.filter(file => {
      const isValid = file.type === 'application/pdf' || 
                     file.type === 'application/msword' ||
                     file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
                     file.type === 'text/plain' ||
                     file.type === 'text/markdown';
      
      if (!isValid) {
        setError(`File "${file.name}" is not a supported format`);
      }
      return isValid;
    });

    setFiles(prev => [...prev, ...validFiles]);
    setError(null);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleTrain = async () => {
    if (files.length === 0) {
      setError('Please select at least one file');
      return;
    }

    try {
      setIsTraining(true);
      setError(null);
      
      // Process each file
      for (const file of files) {
        // Simulated file processing
        const fileContent = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.readAsText(file);
        });

        // Add to training logs
        setTrainingLogs(prev => [{
          fileName: file.name,
          status: 'success',
          content: fileContent.slice(0, 500) + '...',
          timestamp: new Date()
        }, ...prev]);

        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      onTrainingComplete();
      setFiles([]);
      toast.success('Files processed successfully');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process files');
      toast.error('Failed to process files');
    } finally {
      setIsTraining(false);
    }
  };

  const toggleLogExpansion = (fileName: string) => {
    setExpandedLog(expandedLog === fileName ? null : fileName);
  };

  return (
    <div className="space-y-6">
      {/* File Upload Area */}
      <div
        className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-indigo-500 transition-colors cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <div className="flex flex-col items-center">
          <Upload className="h-8 w-8 text-gray-400 mb-2" />
          <p className="text-sm text-gray-600">
            Click to upload or drag and drop
          </p>
          <p className="text-xs text-gray-500 mt-1">
            PDF, DOC, DOCX, TXT, MD (Max 10MB per file)
          </p>
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          multiple
          accept=".pdf,.doc,.docx,.txt,.md"
        />
      </div>

      {/* Selected Files */}
      {files.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">Selected Files</h3>
          <ul className="space-y-2">
            {files.map((file, index) => (
              <li key={index} className="flex items-center justify-between bg-white p-2 rounded-md">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 text-gray-400 mr-2" />
                  <span className="text-sm text-gray-600">{file.name}</span>
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="flex items-center text-red-500 text-sm">
          <AlertCircle className="h-4 w-4 mr-2" />
          {error}
        </div>
      )}

      {/* Training Button */}
      <button
        onClick={handleTrain}
        disabled={isTraining || files.length === 0}
        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isTraining ? (
          <>
            <Upload className="h-5 w-5 mr-2 animate-spin" />
            Training...
          </>
        ) : (
          <>
            <Upload className="h-5 w-5 mr-2" />
            Train with Files
          </>
        )}
      </button>

      {/* Training Logs */}
      {trainingLogs.length > 0 && (
        <div className="bg-white rounded-lg shadow border border-gray-200">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900 flex items-center">
              <FileText className="h-5 w-5 mr-2 text-indigo-500" />
              Training Logs
            </h3>
          </div>
          <div className="divide-y divide-gray-200">
            {trainingLogs.map((log, index) => (
              <div key={index} className="p-4">
                <div 
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => toggleLogExpansion(log.fileName)}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-1 rounded-full ${
                      log.status === 'success' ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${
                        log.status === 'success' ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                    </div>
                    <span className="font-medium text-gray-900">{log.fileName}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-500">
                      {log.timestamp.toLocaleTimeString()}
                    </span>
                    {log.content && (
                      expandedLog === log.fileName ? 
                        <ChevronUp className="h-5 w-5 text-gray-400" /> :
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </div>
                {expandedLog === log.fileName && log.content && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <pre className="text-sm text-gray-700 whitespace-pre-wrap font-mono">
                      {log.content}
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;