import React, { useState } from 'react';
import { Calendar, Key, Save, AlertCircle, ExternalLink } from 'lucide-react';
import { CalendarProvider, calendarService } from '../services/calendarProviders';
import toast from 'react-hot-toast';

const CalendarProviderSettings: React.FC = () => {
  const [providers, setProviders] = useState<CalendarProvider[]>(calendarService.getProviders());
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      providers.forEach(provider => {
        calendarService.updateProviderConfig(provider.id, provider);
      });
      toast.success('Calendar provider settings saved successfully');
    } catch (error) {
      console.error('Error saving calendar provider settings:', error);
      toast.error('Failed to save calendar provider settings');
    } finally {
      setIsSaving(false);
    }
  };

  const handleConnect = (providerId: string) => {
    const provider = providers.find(p => p.id === providerId);
    if (!provider) return;

    // Construct OAuth URL
    const params = new URLSearchParams({
      client_id: provider.clientId,
      redirect_uri: `${window.location.origin}/calendar/callback`,
      response_type: 'code',
      scope: provider.scopes.join(' ')
    });

    // Open OAuth window
    window.open(`${provider.authUrl}?${params.toString()}`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center">
          <Calendar className="h-6 w-6 mr-2" />
          Calendar Providers
        </h2>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center disabled:opacity-50"
        >
          <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
          {isSaving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-yellow-400 mr-2" />
          <div>
            <p className="text-sm text-yellow-700">
              Configure calendar providers to enable automatic calendar event creation for appointments.
              You'll need to create developer accounts and obtain API credentials for each provider.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {providers.map((provider) => (
          <div key={provider.id} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <img src={provider.icon} alt={provider.name} className="h-6 w-6 mr-2" />
                <h3 className="text-lg font-medium">{provider.name}</h3>
              </div>
              <div className="flex items-center space-x-2">
                <a
                  href={`https://console.cloud.google.com/apis/credentials`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:text-indigo-700 flex items-center"
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Developer Console
                </a>
                <button
                  onClick={() => handleConnect(provider.id)}
                  disabled={!provider.clientId || !provider.clientSecret}
                  className={`px-4 py-2 rounded-lg ${
                    provider.isConnected
                      ? 'bg-green-100 text-green-800'
                      : 'bg-indigo-600 text-white hover:bg-indigo-700'
                  } disabled:opacity-50`}
                >
                  {provider.isConnected ? 'Connected' : 'Connect'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Client ID</label>
                <input
                  type="text"
                  value={provider.clientId}
                  onChange={(e) => {
                    const updatedProviders = providers.map(p =>
                      p.id === provider.id ? { ...p, clientId: e.target.value } : p
                    );
                    setProviders(updatedProviders);
                  }}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Client Secret</label>
                <input
                  type="password"
                  value={provider.clientSecret}
                  onChange={(e) => {
                    const updatedProviders = providers.map(p =>
                      p.id === provider.id ? { ...p, clientSecret: e.target.value } : p
                    );
                    setProviders(updatedProviders);
                  }}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700">Required Scopes</label>
              <div className="mt-1 bg-gray-50 rounded-lg p-2">
                <code className="text-sm text-gray-700">
                  {provider.scopes.join(' ')}
                </code>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CalendarProviderSettings;