import React from 'react';
import { X, Users, MessageSquare, Clock, ThumbsUp } from 'lucide-react';
import { Line } from 'react-chartjs-2';

interface SubAccountUsageProps {
  account: {
    name: string;
    analytics: {
      monthlyActiveUsers: number;
      totalConversations: number;
      avgResponseTime: number;
      satisfactionRate: number;
    };
  };
  onClose: () => void;
}

const SubAccountUsage: React.FC<SubAccountUsageProps> = ({ account, onClose }) => {
  const usageData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Active Users',
        data: [300, 350, 400, 450, 500, account.analytics.monthlyActiveUsers],
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.1)',
        fill: true,
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Monthly Active Users'
      }
    },
    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-4xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Usage Analytics - {account.name}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-indigo-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Users className="h-5 w-5 text-indigo-600 mr-2" />
              <h3 className="text-sm font-medium text-indigo-900">Active Users</h3>
            </div>
            <p className="text-2xl font-bold text-indigo-600">
              {account.analytics.monthlyActiveUsers}
            </p>
            <p className="text-sm text-indigo-700">Monthly active users</p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <MessageSquare className="h-5 w-5 text-green-600 mr-2" />
              <h3 className="text-sm font-medium text-green-900">Conversations</h3>
            </div>
            <p className="text-2xl font-bold text-green-600">
              {account.analytics.totalConversations}
            </p>
            <p className="text-sm text-green-700">Total conversations</p>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <Clock className="h-5 w-5 text-yellow-600 mr-2" />
              <h3 className="text-sm font-medium text-yellow-900">Response Time</h3>
            </div>
            <p className="text-2xl font-bold text-yellow-600">
              {account.analytics.avgResponseTime}s
            </p>
            <p className="text-sm text-yellow-700">Average response time</p>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center mb-2">
              <ThumbsUp className="h-5 w-5 text-blue-600 mr-2" />
              <h3 className="text-sm font-medium text-blue-900">Satisfaction</h3>
            </div>
            <p className="text-2xl font-bold text-blue-600">
              {account.analytics.satisfactionRate}%
            </p>
            <p className="text-sm text-blue-700">Customer satisfaction</p>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 border">
          <Line data={usageData} options={chartOptions} />
        </div>
      </div>
    </div>
  );
};

export default SubAccountUsage;