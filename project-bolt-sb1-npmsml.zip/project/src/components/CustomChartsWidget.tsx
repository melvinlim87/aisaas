import React, { useState } from 'react';
import { Plus, Settings } from 'lucide-react';
import { useChartStore, ChartConfig } from '../store/chartStore';
import CustomChartBuilder from './CustomChartBuilder';
import AnalyticsVisualization from './AnalyticsVisualization';

interface CustomChartsWidgetProps {
  isCustomizing?: boolean;
  gradientButtonClass?: string;
}

const CustomChartsWidget: React.FC<CustomChartsWidgetProps> = ({ isCustomizing, gradientButtonClass }) => {
  const { charts, addChart, updateChart, deleteChart } = useChartStore();
  const [showBuilder, setShowBuilder] = useState(false);
  const [editingChart, setEditingChart] = useState<ChartConfig | null>(null);

  const handleSave = (chart: ChartConfig) => {
    // Add gradient colors to the chart config
    const enhancedChart = {
      ...chart,
      data: {
        ...chart.data,
        datasets: chart.data.datasets.map(dataset => ({
          ...dataset,
          borderColor: 'rgb(139, 92, 246)', // Purple-500
          backgroundColor: function(context: any) {
            const chart = context.chart;
            const { ctx, chartArea } = chart;
            if (!chartArea) return;
            
            const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
            gradient.addColorStop(0, 'rgba(139, 92, 246, 0.1)'); // Purple-500
            gradient.addColorStop(1, 'rgba(45, 212, 191, 0.4)'); // Teal-400
            return gradient;
          },
          fill: true,
          tension: 0.4,
          borderWidth: 3
        }))
      },
      options: {
        ...chart.options,
        scales: {
          y: {
            grid: {
              color: 'rgba(139, 92, 246, 0.1)'
            }
          },
          x: {
            grid: {
              display: false
            }
          }
        }
      }
    };

    if (editingChart) {
      updateChart(enhancedChart);
    } else {
      addChart(enhancedChart);
    }
    setShowBuilder(false);
    setEditingChart(null);
  };

  const handleDelete = (chartId: string) => {
    deleteChart(chartId);
    setShowBuilder(false);
    setEditingChart(null);
  };

  if (showBuilder) {
    return (
      <CustomChartBuilder
        onSave={handleSave}
        onDelete={editingChart ? handleDelete : undefined}
        initialConfig={editingChart || undefined}
      />
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-semibold">Custom Charts</h2>
        <button
          onClick={() => setShowBuilder(true)}
          className={gradientButtonClass || "bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center"}
        >
          <Plus className="h-5 w-5 mr-2" />
          Add Chart
        </button>
      </div>

      {charts.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <p>No custom charts yet. Click "Add Chart" to create one.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {charts.map((chart) => (
            <div key={chart.id} className="border rounded-lg p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-medium">{chart.title}</h3>
                <button
                  onClick={() => {
                    setEditingChart(chart);
                    setShowBuilder(true);
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <Settings className="h-5 w-5" />
                </button>
              </div>
              <div className="h-64">
                <AnalyticsVisualization
                  config={{
                    type: chart.type,
                    data: chart.data,
                    options: {
                      ...chart.options,
                      plugins: {
                        title: {
                          display: true,
                          text: chart.title
                        }
                      }
                    }
                  }}
                  className="w-full h-full"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomChartsWidget;