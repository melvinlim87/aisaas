import React from 'react';
import { Chart as ChartJS } from 'chart.js/auto';
import { Pie, Bar, Line } from 'react-chartjs-2';

interface ChartData {
  type: 'pie' | 'bar' | 'line';
  data: {
    labels: string[];
    datasets: Array<{
      label?: string;
      data: number[];
      backgroundColor?: string[];
      borderColor?: string;
      fill?: boolean;
    }>;
  };
}

interface AnalyticsChartProps {
  chartData: ChartData;
}

const AnalyticsChart: React.FC<AnalyticsChartProps> = ({ chartData }) => {
  const commonOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            size: 12
          }
        }
      },
      tooltip: {
        enabled: true,
        mode: 'index' as const,
        intersect: false,
        padding: 12,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleFont: {
          size: 14,
          weight: 'bold'
        },
        bodyFont: {
          size: 13
        },
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== undefined) {
              label += context.parsed.y;
            } else if (context.parsed !== undefined) {
              label += context.parsed;
            }
            return label;
          }
        }
      }
    },
    scales: chartData.type !== 'pie' ? {
      y: {
        beginAtZero: true,
        grid: {
          drawBorder: false,
          color: 'rgba(0, 0, 0, 0.1)'
        },
        ticks: {
          font: {
            size: 12
          }
        }
      },
      x: {
        grid: {
          display: false
        },
        ticks: {
          font: {
            size: 12
          }
        }
      }
    } : undefined
  };

  const renderChart = () => {
    switch (chartData.type) {
      case 'pie':
        return <Pie data={chartData.data} options={commonOptions} />;
      case 'bar':
        return <Bar data={chartData.data} options={commonOptions} />;
      case 'line':
        return <Line data={chartData.data} options={commonOptions} />;
      default:
        return null;
    }
  };

  return (
    <div className="h-64 mt-4">
      {renderChart()}
    </div>
  );
};

export default AnalyticsChart;