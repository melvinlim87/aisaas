import React, { useState } from 'react';
import { Save, Play, AlertCircle, Bot, CheckCircle } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import { chatbotService } from '../services/chatbotService';
import toast from 'react-hot-toast';

const SystemPromptEditor: React.FC = () => {
  const { settings, updateSettings } = useChatStore();
  const [testMessage, setTestMessage] = useState('');
  const [testResponse, setTestResponse] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await updateSettings(settings);
      toast.success('System prompt updated successfully');
    } catch (error) {
      console.error('Error saving prompt:', error);
      toast.error('Failed to save system prompt');
    } finally {
      setIsSaving(false);
    }
  };

  const handleTest = async () => {
    if (!testMessage.trim()) {
      toast.error('Please enter a test message');
      return;
    }

    setIsTesting(true);
    try {
      const response = await chatbotService.testPrompt(settings.advanced.systemPrompt, testMessage);
      setTestResponse(response.content);
      toast.success('Test completed successfully');
    } catch (error) {
      console.error('Error testing prompt:', error);
      toast.error('Failed to test prompt');
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center">
          <Bot className="h-5 w-5 mr-2 text-indigo-600" />
          System Prompt Configuration
        </h2>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center disabled:opacity-50"
        >
          <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
          {isSaving ? 'Saving...' : 'Save Prompt'}
        </button>
      </div>

      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-lg">
        <div className="flex items-center text-sm text-indigo-800 mb-2">
          <AlertCircle className="h-4 w-4 mr-2" />
          This prompt defines how your AI assistant behaves and responds to user queries.
        </div>
      </div>

      <div className="space-y-4">
        <textarea
          value={settings.advanced.systemPrompt}
          onChange={(e) => updateSettings({
            ...settings,
            advanced: { ...settings.advanced, systemPrompt: e.target.value }
          })}
          className="w-full h-[400px] font-mono text-sm rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          placeholder="Enter your system prompt..."
        />

        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-medium mb-2">Quick Tips:</h3>
          <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
            <li>Define clear role and responsibilities</li>
            <li>Specify response format and style</li>
            <li>Include handling for edge cases</li>
            <li>Set boundaries and limitations</li>
            <li>Add example interactions</li>
          </ul>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-medium mb-4">Test Your Prompt</h3>
          <div className="flex gap-2">
            <input
              type="text"
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              placeholder="Enter a test message..."
              className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
            <button
              onClick={handleTest}
              disabled={isTesting}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center disabled:opacity-50"
            >
              <Play className="h-5 w-5 mr-2" />
              {isTesting ? 'Testing...' : 'Test'}
            </button>
          </div>

          {testResponse && (
            <div className="mt-4 bg-gray-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                <h4 className="font-medium">Test Response</h4>
              </div>
              <pre className="whitespace-pre-wrap text-sm text-gray-700 font-mono bg-white p-4 rounded-lg border">
                {testResponse}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SystemPromptEditor;