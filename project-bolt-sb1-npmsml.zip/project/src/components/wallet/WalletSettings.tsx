import React, { useState, useEffect } from 'react';
import { X, Settings, AlertCircle } from 'lucide-react';
import { walletService } from '../../services/walletService';
import { WalletSettings as WalletSettingsType } from '../../types/wallet';
import toast from 'react-hot-toast';

interface WalletSettingsProps {
  onClose: () => void;
  onSave: () => void;
}

const WalletSettings: React.FC<WalletSettingsProps> = ({ onClose, onSave }) => {
  const [settings, setSettings] = useState<WalletSettingsType>({
    lowBalanceAlert: 5.00,
    autoReloadAmount: 20.00,
    autoReloadEnabled: false,
    notificationEmail: ''
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const currentSettings = await walletService.getSettings();
      setSettings(currentSettings);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to load settings';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      setError(null);
      await walletService.updateSettings(settings);
      toast.success('Settings saved successfully');
      onSave();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to save settings';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
        <div className="bg-white rounded-lg w-full max-w-md p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold flex items-center">
            <Settings className="h-6 w-6 mr-2" />
            Wallet Settings
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-center">
            <AlertCircle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Low Balance Alert
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                $
              </span>
              <input
                type="number"
                value={settings.lowBalanceAlert}
                onChange={(e) => setSettings({
                  ...settings,
                  lowBalanceAlert: Math.max(0, Number(e.target.value))
                })}
                className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                min="0"
                step="1"
              />
            </div>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="auto-reload"
              checked={settings.autoReloadEnabled}
              onChange={(e) => setSettings({
                ...settings,
                autoReloadEnabled: e.target.checked
              })}
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor="auto-reload" className="ml-2 block text-sm text-gray-900">
              Enable Auto Reload
            </label>
          </div>

          {settings.autoReloadEnabled && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Auto Reload Amount
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                  $
                </span>
                <input
                  type="number"
                  value={settings.autoReloadAmount}
                  onChange={(e) => setSettings({
                    ...settings,
                    autoReloadAmount: Math.max(0, Number(e.target.value))
                  })}
                  className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  min="0"
                  step="1"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notification Email
            </label>
            <input
              type="email"
              value={settings.notificationEmail}
              onChange={(e) => setSettings({
                ...settings,
                notificationEmail: e.target.value
              })}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Enter email for notifications"
            />
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center"
            >
              {isSaving ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Saving...
                </>
              ) : (
                'Save Settings'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletSettings;