import React from 'react';
import { CreditCard, AlertTriangle } from 'lucide-react';
import { WalletBalance as WalletBalanceType } from '../../types/wallet';

interface WalletBalanceProps {
  balance: WalletBalanceType;
  onTopUp: () => void;
}

const WalletBalance: React.FC<WalletBalanceProps> = ({ balance, onTopUp }) => {
  const isLowBalance = balance.amount < 10.00;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center">
          <CreditCard className="h-5 w-5 mr-2 text-indigo-600" />
          Wallet Balance
        </h2>
        <button
          onClick={onTopUp}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
        >
          Top Up
        </button>
      </div>

      <div className="text-3xl font-bold text-gray-900 mb-2">
        {balance.currency} {balance.amount.toFixed(2)}
      </div>

      <div className="text-sm text-gray-500">
        Last updated: {balance.updatedAt.toLocaleString()}
      </div>

      {isLowBalance && (
        <div className="mt-4 bg-yellow-50 text-yellow-800 p-3 rounded-lg flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <span>Low balance alert! Consider topping up your wallet.</span>
        </div>
      )}
    </div>
  );
};

export default WalletBalance;