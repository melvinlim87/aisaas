import React, { useState, useEffect } from 'react';
import { BarChart2, Users, CreditCard, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { billingService } from '../../services/billingService';
import toast from 'react-hot-toast';

interface BillingOverview {
  totalRevenue: number;
  activeSubAccounts: number;
  totalCreditsUsed: number;
  recentTransactions: Array<{
    id: string;
    subAccountName: string;
    amount: number;
    type: 'credit' | 'debit';
    description: string;
    timestamp: Date;
  }>;
  subAccountStats: Array<{
    id: string;
    name: string;
    creditsUsed: number;
    lastBillingAmount: number;
    nextBillingDate: Date;
    status: 'active' | 'overdue' | 'suspended';
  }>;
}

const SubAccountBillingOverview: React.FC = () => {
  const [overview, setOverview] = useState<BillingOverview | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBillingOverview();
  }, []);

  const loadBillingOverview = async () => {
    try {
      const data = await billingService.getMasterAccountOverview();
      setOverview(data);
    } catch (error) {
      toast.error('Failed to load billing overview');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-12rem)]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
      </div>
    );
  }

  if (!overview) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Sub-Account Billing Overview</h1>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${overview.totalRevenue.toLocaleString()}</p>
            </div>
            <BarChart2 className="h-8 w-8 text-indigo-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Sub-Accounts</p>
              <p className="text-2xl font-bold text-gray-900">{overview.activeSubAccounts}</p>
            </div>
            <Users className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Credits Used</p>
              <p className="text-2xl font-bold text-gray-900">{overview.totalCreditsUsed.toLocaleString()}</p>
            </div>
            <CreditCard className="h-8 w-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Sub-Account Stats */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b">
          <h2 className="text-lg font-semibold">Sub-Account Billing Status</h2>
        </div>
        <div className="divide-y">
          {overview.subAccountStats.map((stat) => (
            <div key={stat.id} className="p-6 hover:bg-gray-50">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-gray-900">{stat.name}</h3>
                  <p className="text-sm text-gray-500">
                    Next billing: {new Date(stat.nextBillingDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold">${stat.lastBillingAmount}</p>
                  <p className="text-sm text-gray-500">{stat.creditsUsed.toLocaleString()} credits used</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  stat.status === 'active' ? 'bg-green-100 text-green-800' :
                  stat.status === 'overdue' ? 'bg-red-100 text-red-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {stat.status.charAt(0).toUpperCase() + stat.status.slice(1)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b">
          <h2 className="text-lg font-semibold">Recent Transactions</h2>
        </div>
        <div className="divide-y">
          {overview.recentTransactions.map((transaction) => (
            <div key={transaction.id} className="p-6 hover:bg-gray-50">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  {transaction.type === 'credit' ? (
                    <ArrowUpRight className="h-5 w-5 text-green-500 mr-3" />
                  ) : (
                    <ArrowDownRight className="h-5 w-5 text-red-500 mr-3" />
                  )}
                  <div>
                    <p className="font-medium text-gray-900">{transaction.subAccountName}</p>
                    <p className="text-sm text-gray-500">{transaction.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-semibold ${
                    transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {transaction.type === 'credit' ? '+' : '-'}${transaction.amount}
                  </p>
                  <p className="text-sm text-gray-500">
                    {new Date(transaction.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubAccountBillingOverview;