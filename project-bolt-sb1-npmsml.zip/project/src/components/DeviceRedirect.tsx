import React, { useEffect, useState } from 'react';
import { Tablet, Smartphone } from 'lucide-react';

const DeviceRedirect: React.FC = () => {
  const [deviceType, setDeviceType] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');

  useEffect(() => {
    const checkDevice = () => {
      const width = window.innerWidth;
      if (width <= 768) {
        setDeviceType('mobile');
      } else if (width <= 1024) {
        setDeviceType('tablet');
      } else {
        setDeviceType('desktop');
      }
    };

    checkDevice();
    window.addEventListener('resize', checkDevice);
    return () => window.removeEventListener('resize', checkDevice);
  }, []);

  if (deviceType === 'desktop') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full text-center">
        <div className="flex justify-center space-x-4 mb-6">
          <Smartphone className="h-12 w-12 text-indigo-600" />
          <Tablet className="h-12 w-12 text-purple-600" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          Mobile & Tablet Version In Progress
        </h1>
        <p className="text-gray-600 mb-6">
          We're currently optimizing our application for mobile and tablet devices. Please access the platform from a desktop computer for the best experience.
        </p>
        <div className="p-4 bg-indigo-50 rounded-lg">
          <p className="text-sm text-indigo-800">
            Recommended minimum screen width: 1024px
          </p>
        </div>
      </div>
    </div>
  );
};

export default DeviceRedirect;