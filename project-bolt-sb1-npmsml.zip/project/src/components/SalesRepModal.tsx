import React, { useState } from 'react';
import { Users, X } from 'lucide-react';
import { SalesRep } from '../types/user';
import { userService } from '../services/userService';
import toast from 'react-hot-toast';

interface SalesRepModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSalesRepAdded: (rep: SalesRep) => void;
  currentSalesReps: SalesRep[];
}

const SalesRepModal: React.FC<SalesRepModalProps> = ({
  isOpen,
  onClose,
  onSalesRepAdded,
  currentSalesReps
}) => {
  const [newSalesRep, setNewSalesRep] = useState({
    name: '',
    email: '',
    availability: {
      start: '09:00',
      end: '17:00',
      days: [1, 2, 3, 4, 5]
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!newSalesRep.name || !newSalesRep.email) {
        toast.error('Please fill in all required fields');
        return;
      }

      const addedRep = await userService.addSalesRep(newSalesRep);
      onSalesRepAdded(addedRep);
      setNewSalesRep({
        name: '',
        email: '',
        availability: {
          start: '09:00',
          end: '17:00',
          days: [1, 2, 3, 4, 5]
        }
      });
      toast.success('Sales representative added successfully');
    } catch (error) {
      console.error('Error adding sales rep:', error);
      toast.error('Failed to add sales representative');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold flex items-center">
            <Users className="h-6 w-6 mr-2" />
            Manage Sales Reps
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Name</label>
            <input
              type="text"
              value={newSalesRep.name}
              onChange={(e) => setNewSalesRep({ ...newSalesRep, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              value={newSalesRep.email}
              onChange={(e) => setNewSalesRep({ ...newSalesRep, email: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Working Hours</label>
            <div className="flex space-x-4">
              <input
                type="time"
                value={newSalesRep.availability.start}
                onChange={(e) => setNewSalesRep({
                  ...newSalesRep,
                  availability: { ...newSalesRep.availability, start: e.target.value }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="mt-2">to</span>
              <input
                type="time"
                value={newSalesRep.availability.end}
                onChange={(e) => setNewSalesRep({
                  ...newSalesRep,
                  availability: { ...newSalesRep.availability, end: e.target.value }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
            >
              Add Sales Rep
            </button>
          </div>
        </form>

        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-2">Current Sales Reps</h3>
          <div className="space-y-2">
            {currentSalesReps.map((rep) => (
              <div
                key={rep.id}
                className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
              >
                <div>
                  <p className="font-medium">{rep.name}</p>
                  <p className="text-sm text-gray-500">{rep.email}</p>
                </div>
                <div className="text-sm text-gray-500">
                  {rep.availability.start} - {rep.availability.end}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesRepModal;