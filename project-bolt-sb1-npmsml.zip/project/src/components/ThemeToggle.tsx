import React from 'react';
import { Sun, Moon, Palette } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const ThemeToggle: React.FC = () => {
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('gradient');
    else setTheme('light');
  };

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-lg transition-colors duration-200"
    >
      {theme === 'light' && <Moon className="h-5 w-5" />}
      {theme === 'dark' && <Palette className="h-5 w-5" />}
      {theme === 'gradient' && <Sun className="h-5 w-5" />}
    </button>
  );
};

export default ThemeToggle;