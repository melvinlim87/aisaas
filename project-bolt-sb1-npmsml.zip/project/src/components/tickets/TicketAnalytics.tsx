import React from 'react';
import { MessageSquare, AlertCircle, Clock, CheckCircle, XCircle } from 'lucide-react';

interface Analytics {
  total: number;
  active: number;
  pending: number;
  resolved: number;
  closed: number;
}

interface TicketAnalyticsProps {
  analytics: Analytics;
}

const TicketAnalytics: React.FC<TicketAnalyticsProps> = ({ analytics }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
      <div className="bg-white rounded-lg shadow p-3">
        <div className="flex items-center justify-between mb-1">
          <div className="bg-indigo-50 p-2 rounded-lg">
            <MessageSquare className="h-5 w-5 text-indigo-500" />
          </div>
          <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
            Total
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-semibold text-gray-900">{analytics.total}</p>
          <p className="text-sm text-gray-500">Total Tickets</p>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-3">
        <div className="flex items-center justify-between mb-1">
          <div className="bg-green-50 p-2 rounded-lg">
            <Clock className="h-5 w-5 text-green-500" />
          </div>
          <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
            Active
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-semibold text-gray-900">{analytics.active}</p>
          <p className="text-sm text-gray-500">Active</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-3">
        <div className="flex items-center justify-between mb-1">
          <div className="bg-yellow-50 p-2 rounded-lg">
            <AlertCircle className="h-5 w-5 text-yellow-500" />
          </div>
          <span className="text-xs font-medium text-yellow-600 bg-yellow-50 px-2 py-0.5 rounded-full">
            Pending
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-semibold text-gray-900">{analytics.pending}</p>
          <p className="text-sm text-gray-500">Pending</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-3">
        <div className="flex items-center justify-between mb-1">
          <div className="bg-blue-50 p-2 rounded-lg">
            <CheckCircle className="h-5 w-5 text-blue-500" />
          </div>
          <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
            Resolved
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-semibold text-gray-900">{analytics.resolved}</p>
          <p className="text-sm text-gray-500">Resolved</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-3">
        <div className="flex items-center justify-between mb-1">
          <div className="bg-gray-50 p-2 rounded-lg">
            <XCircle className="h-5 w-5 text-gray-500" />
          </div>
          <span className="text-xs font-medium text-gray-600 bg-gray-50 px-2 py-0.5 rounded-full">
            Closed
          </span>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-semibold text-gray-900">{analytics.closed}</p>
          <p className="text-sm text-gray-500">Closed</p>
        </div>
      </div>
    </div>
  );
};

export default TicketAnalytics;