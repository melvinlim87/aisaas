import React, { useState } from 'react';
import { Command, Plus, Trash2, Save, AlertCircle, BrainCircuit, Code, Play, MessageSquare, Info } from 'lucide-react';
import { chatbotService } from '../services/chatbotService';
import toast from 'react-hot-toast';

const EXAMPLE_SYSTEM_PROMPT = `You are an AI assistant focused on [specific domain].

Follow these instructions for ALL responses:

1. Format & Structure
- Use clear headers with proper hierarchy (# and ##)
- Maintain consistent spacing between sections
- Use bullet points for lists
- Include specific numbers and metrics
- Bold important terms using **value**

2. Response Components
- Start with a brief overview
- Break down complex topics into sections
- Provide specific examples
- Include actionable recommendations
- End with a clear summary

3. Tone & Style
- Maintain a professional, authoritative voice
- Be concise and direct
- Use industry-specific terminology
- Provide evidence-based responses
- Stay focused on the user's query

4. Special Instructions
- Always format code blocks with proper syntax highlighting
- Include relevant warnings or prerequisites
- Cite sources when providing statistics
- Use tables for comparing multiple items

Remember:
- Never break character
- Always follow this exact format
- Maintain consistent quality`;

const CommandTraining: React.FC = () => {
  const [activeTab, setActiveTab] = useState('prompt');
  const [basePrompt, setBasePrompt] = useState(EXAMPLE_SYSTEM_PROMPT);
  const [testMessage, setTestMessage] = useState('');
  const [testResponse, setTestResponse] = useState<{
    content: string;
    timestamp: Date;
  } | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  const handleTestPrompt = async () => {
    if (!testMessage.trim()) {
      toast.error('Please enter a test message');
      return;
    }

    if (!basePrompt.trim()) {
      toast.error('Please enter a base system prompt');
      return;
    }

    setIsTesting(true);
    try {
      const response = await chatbotService.testPrompt(basePrompt, testMessage);
      setTestResponse({
        content: response.content,
        timestamp: response.timestamp
      });
      toast.success('Test completed successfully');
    } catch (error) {
      console.error('Error testing prompt:', error);
      toast.error('Failed to test prompt');
    } finally {
      setIsTesting(false);
    }
  };

  const handleSavePrompt = async () => {
    try {
      // Save the prompt logic here
      toast.success('Prompt saved successfully');
    } catch (error) {
      console.error('Error saving prompt:', error);
      toast.error('Failed to save prompt');
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Tab Navigation */}
      <div className="flex space-x-4 border-b">
        <button
          onClick={() => setActiveTab('prompt')}
          className={`px-4 py-2 border-b-2 ${
            activeTab === 'prompt'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Code className="h-5 w-5 mr-2" />
            Base System Prompt
          </div>
        </button>
        <button
          onClick={() => setActiveTab('commands')}
          className={`px-4 py-2 border-b-2 ${
            activeTab === 'commands'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Command className="h-5 w-5 mr-2" />
            Command Training
          </div>
        </button>
      </div>

      {/* Content */}
      {activeTab === 'prompt' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold flex items-center">
              <BrainCircuit className="h-6 w-6 mr-2" />
              Base System Prompt
            </h2>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="mb-4">
              <h3 className="text-lg font-medium mb-2">Custom Instructions</h3>
              <div className="flex items-center text-gray-600 mb-4 bg-blue-50 p-4 rounded-lg">
                <Info className="h-5 w-5 mr-2 text-blue-500" />
                <p className="text-sm">
                  Define the base behavior and personality of your AI assistant. The system prompt sets the foundation for how the AI will respond to all queries.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="relative">
                <textarea
                  value={basePrompt}
                  onChange={(e) => setBasePrompt(e.target.value)}
                  className="w-full h-[400px] font-mono text-sm rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="Enter your base system prompt..."
                />
                <div className="absolute top-2 right-2">
                  <button
                    onClick={() => setBasePrompt(EXAMPLE_SYSTEM_PROMPT)}
                    className="text-xs text-indigo-600 hover:text-indigo-700"
                  >
                    Load Example
                  </button>
                </div>
              </div>

              {/* Test Prompt Section */}
              <div className="mt-8 border-t pt-6">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <Play className="h-5 w-5 mr-2 text-indigo-600" />
                  Test Your Instructions
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Enter a test message
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={testMessage}
                        onChange={(e) => setTestMessage(e.target.value)}
                        placeholder="Enter a message to test how the AI will respond..."
                        className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                      />
                      <button
                        onClick={handleTestPrompt}
                        disabled={isTesting}
                        className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center disabled:opacity-50"
                      >
                        <Play className="h-5 w-5 mr-2" />
                        {isTesting ? 'Testing...' : 'Test'}
                      </button>
                    </div>
                  </div>

                  {testResponse && (
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center mb-2">
                        <MessageSquare className="h-5 w-5 text-indigo-600 mr-2" />
                        <span className="text-sm font-medium">AI Response</span>
                        <span className="text-xs text-gray-500 ml-2">
                          {testResponse.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="prose max-w-none">
                        <pre className="text-sm text-gray-700 whitespace-pre-wrap bg-white rounded-lg p-3 border">
                          {testResponse.content}
                        </pre>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <button
              onClick={handleSavePrompt}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
            >
              <Save className="h-5 w-5 mr-2" />
              Save Instructions
            </button>
          </div>
        </div>
      )}

      {activeTab === 'commands' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold flex items-center">
              <Command className="h-6 w-6 mr-2" />
              Command Training
            </h2>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center">
              <Plus className="h-5 w-5 mr-2" />
              Add Command
            </button>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <p className="text-gray-600 mb-4">
              Train your AI assistant to recognize and respond to specific commands. Each command can have
              its own custom behavior and response template.
            </p>

            {/* Command list will go here */}
            <div className="text-center text-gray-500 py-8">
              No commands added yet. Click "Add Command" to get started.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommandTraining;