import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import DailyView from './DailyView';
import WeeklyView from './WeeklyView';
import MonthlyView from './MonthlyView';
import CalendarEventModal from './CalendarEventModal';
import { Appointment } from '../../types/appointments';

interface CalendarViewProps {
  view: 'daily' | 'weekly' | 'monthly';
  currentDate: Date;
  appointments: Appointment[];
  onDateChange: (date: Date) => void;
  onAppointmentClick: (appointment: Appointment) => void;
  salesReps?: Array<{ id: string; name: string }>;
  onAppointmentCreate?: (appointment: Omit<Appointment, 'id'>) => void;
  onAppointmentUpdate?: (appointment: Appointment) => void;
}

const CalendarView: React.FC<CalendarViewProps> = ({
  view,
  currentDate,
  appointments,
  onDateChange,
  onAppointmentClick,
  salesReps = [],
  onAppointmentCreate,
  onAppointmentUpdate
}) => {
  const [showEventModal, setShowEventModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | undefined>();

  const handlePrevious = () => {
    const newDate = new Date(currentDate);
    switch (view) {
      case 'daily':
        newDate.setDate(currentDate.getDate() - 1);
        break;
      case 'weekly':
        newDate.setDate(currentDate.getDate() - 7);
        break;
      case 'monthly':
        newDate.setMonth(currentDate.getMonth() - 1);
        break;
    }
    onDateChange(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(currentDate);
    switch (view) {
      case 'daily':
        newDate.setDate(currentDate.getDate() + 1);
        break;
      case 'weekly':
        newDate.setDate(currentDate.getDate() + 7);
        break;
      case 'monthly':
        newDate.setMonth(currentDate.getMonth() + 1);
        break;
    }
    onDateChange(newDate);
  };

  const handleSaveAppointment = (appointmentData: Omit<Appointment, 'id'>) => {
    if (selectedAppointment) {
      onAppointmentUpdate?.({ ...appointmentData, id: selectedAppointment.id });
    } else {
      onAppointmentCreate?.(appointmentData);
    }
    setShowEventModal(false);
    setSelectedAppointment(undefined);
  };

  const getHeaderText = () => {
    const options: Intl.DateTimeFormatOptions = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    };

    switch (view) {
      case 'daily':
        return currentDate.toLocaleDateString(undefined, options);
      case 'weekly':
        const weekStart = new Date(currentDate);
        weekStart.setDate(currentDate.getDate() - currentDate.getDay());
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6);
        return `${weekStart.toLocaleDateString(undefined, { month: 'long', day: 'numeric' })} - ${weekEnd.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}`;
      case 'monthly':
        return currentDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
      default:
        return '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-4 border-b flex items-center justify-between bg-gray-50">
        <button
          onClick={handlePrevious}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <h2 className="text-xl font-semibold">{getHeaderText()}</h2>
        <button
          onClick={handleNext}
          className="p-2 hover:bg-gray-100 rounded-lg"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="p-4">
        {view === 'daily' && (
          <DailyView
            date={currentDate}
            appointments={appointments}
            onAppointmentClick={onAppointmentClick}
          />
        )}
        {view === 'weekly' && (
          <WeeklyView
            date={currentDate}
            appointments={appointments}
            onAppointmentClick={onAppointmentClick}
          />
        )}
        {view === 'monthly' && (
          <MonthlyView
            date={currentDate}
            appointments={appointments}
            onAppointmentClick={onAppointmentClick}
          />
        )}
      </div>

      {showEventModal && (
        <CalendarEventModal
          isOpen={showEventModal}
          onClose={() => {
            setShowEventModal(false);
            setSelectedAppointment(undefined);
          }}
          onSave={handleSaveAppointment}
          editingEvent={selectedAppointment}
          salesReps={salesReps}
        />
      )}
    </div>
  );
};

export default CalendarView;