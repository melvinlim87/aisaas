import React from 'react';
import { Clock } from 'lucide-react';
import { Appointment } from '../../types/appointments';

interface WeeklyViewProps {
  date: Date;
  appointments: Appointment[];
  onAppointmentClick: (appointment: Appointment) => void;
}

const WeeklyView: React.FC<WeeklyViewProps> = ({ date, appointments, onAppointmentClick }) => {
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const day = new Date(date);
    day.setDate(date.getDate() - date.getDay() + i);
    return day;
  });

  const businessHours = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM to 8 PM

  const getAppointmentsForDayAndHour = (day: Date, hour: number) => {
    const dateStr = day.toISOString().split('T')[0];
    return appointments.filter(app => {
      const appHour = parseInt(app.time.split(':')[0]);
      return app.date === dateStr && appHour === hour;
    });
  };

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[800px]">
        {/* Header */}
        <div className="grid grid-cols-8 gap-2 mb-4">
          <div className="text-gray-500 text-sm">Time</div>
          {weekDays.map((day, index) => (
            <div
              key={index}
              className={`text-center ${
                day.toDateString() === new Date().toDateString()
                  ? 'bg-blue-50 rounded-lg p-2'
                  : 'p-2'
              }`}
            >
              <div className="font-medium">
                {day.toLocaleDateString('default', { weekday: 'short' })}
              </div>
              <div className="text-sm text-gray-500">
                {day.toLocaleDateString('default', { day: 'numeric', month: 'short' })}
              </div>
            </div>
          ))}
        </div>

        {/* Time Slots */}
        {businessHours.map(hour => (
          <div key={hour} className="grid grid-cols-8 gap-2 mb-2">
            <div className="text-gray-500 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {`${hour.toString().padStart(2, '0')}:00`}
            </div>
            {weekDays.map((day, index) => {
              const hourAppointments = getAppointmentsForDayAndHour(day, hour);
              return (
                <div
                  key={index}
                  className="min-h-[4rem] border rounded-lg p-1"
                >
                  {hourAppointments.map(appointment => (
                    <div
                      key={appointment.id}
                      onClick={() => onAppointmentClick(appointment)}
                      className="bg-blue-100 text-blue-800 p-2 rounded-lg mb-1 cursor-pointer hover:bg-blue-200 text-sm"
                    >
                      <div className="font-medium truncate">{appointment.title}</div>
                      <div className="text-xs">{appointment.time}</div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WeeklyView;