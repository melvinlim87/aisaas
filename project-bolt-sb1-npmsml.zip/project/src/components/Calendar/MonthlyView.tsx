import React from 'react';
import { Appointment } from '../../types/appointments';

interface MonthlyViewProps {
  date: Date;
  appointments: Appointment[];
  onAppointmentClick: (appointment: Appointment) => void;
}

const MonthlyView: React.FC<MonthlyViewProps> = ({ date, appointments, onAppointmentClick }) => {
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const year = date.getFullYear();
  const month = date.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDayOfMonth = getFirstDayOfMonth(year, month);

  const getAppointmentsForDay = (day: number) => {
    const dateStr = new Date(year, month, day).toISOString().split('T')[0];
    return appointments.filter(app => app.date === dateStr);
  };

  const days = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    days.push(i);
  }

  return (
    <div className="grid grid-cols-7 gap-2">
      {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
        <div key={day} className="text-center font-medium text-gray-500 py-2">
          {day}
        </div>
      ))}

      {days.map((day, index) => {
        if (day === null) {
          return <div key={`empty-${index}`} className="h-32 bg-gray-50 rounded-lg" />;
        }

        const dayAppointments = getAppointmentsForDay(day);
        const isToday = new Date(year, month, day).toDateString() === new Date().toDateString();

        return (
          <div
            key={day}
            className={`h-32 border rounded-lg p-2 overflow-y-auto ${
              isToday ? 'bg-blue-50 border-blue-200' : ''
            }`}
          >
            <div className="text-right mb-1">
              <span className={`text-sm ${isToday ? 'font-bold text-blue-600' : 'text-gray-500'}`}>
                {day}
              </span>
            </div>
            {dayAppointments.map(appointment => (
              <div
                key={appointment.id}
                onClick={() => onAppointmentClick(appointment)}
                className="bg-blue-100 text-blue-800 p-1 rounded mb-1 cursor-pointer hover:bg-blue-200"
              >
                <div className="text-xs font-medium truncate">{appointment.title}</div>
                <div className="text-xs">{appointment.time}</div>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
};

export default MonthlyView;