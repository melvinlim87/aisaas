import React from 'react';
import { Clock } from 'lucide-react';
import { Appointment } from '../../types/appointments';

interface DailyViewProps {
  date: Date;
  appointments: Appointment[];
  onAppointmentClick: (appointment: Appointment) => void;
}

const DailyView: React.FC<DailyViewProps> = ({ date, appointments, onAppointmentClick }) => {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const dateStr = date.toISOString().split('T')[0];
  const dayAppointments = appointments.filter(app => app.date === dateStr);

  const getAppointmentsForHour = (hour: number) => {
    return dayAppointments.filter(app => {
      const appHour = parseInt(app.time.split(':')[0]);
      return appHour === hour;
    });
  };

  return (
    <div className="space-y-2">
      {hours.map(hour => {
        const hourAppointments = getAppointmentsForHour(hour);
        const timeStr = `${hour.toString().padStart(2, '0')}:00`;

        return (
          <div key={hour} className="flex">
            <div className="w-20 py-2 text-gray-500 text-sm flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {timeStr}
            </div>
            <div className="flex-1 min-h-[4rem] border-l pl-4">
              {hourAppointments.map(appointment => (
                <div
                  key={appointment.id}
                  onClick={() => onAppointmentClick(appointment)}
                  className="bg-blue-100 text-blue-800 p-2 rounded-lg mb-2 cursor-pointer hover:bg-blue-200"
                >
                  <div className="font-medium">{appointment.title}</div>
                  <div className="text-sm">
                    {appointment.time} - {appointment.salesRepName}
                  </div>
                  <div className="text-xs text-blue-600">
                    {appointment.location.type === 'digital' ? '🌐 Online' : '📍 In-person'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DailyView;