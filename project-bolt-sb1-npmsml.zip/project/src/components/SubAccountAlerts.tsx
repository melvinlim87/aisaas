import React, { useState } from 'react';
import { X, Save, Bell, Mail, MessageSquare, Globe } from 'lucide-react';
import { AlertConfig } from '../types/subAccount';
import toast from 'react-hot-toast';

interface SubAccountAlertsProps {
  subAccountId: string;
  currentConfig: AlertConfig;
  onSave: (config: AlertConfig) => Promise<void>;
  onClose: () => void;
}

const SubAccountAlerts: React.FC<SubAccountAlertsProps> = ({
  subAccountId,
  currentConfig,
  onSave,
  onClose
}) => {
  const [config, setConfig] = useState<AlertConfig>(currentConfig);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await onSave(config);
      toast.success('Alert settings updated successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to update alert settings');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-2xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold flex items-center">
            <Bell className="h-6 w-6 mr-2" />
            Alert Settings
          </h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Thresholds */}
          <div>
            <h3 className="text-lg font-medium mb-4">Alert Thresholds</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Usage Threshold (%)
                </label>
                <input
                  type="number"
                  value={config.usageThreshold}
                  onChange={(e) => setConfig({ ...config, usageThreshold: parseInt(e.target.value) })}
                  className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  min="1"
                  max="100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Credit Threshold
                </label>
                <input
                  type="number"
                  value={config.creditThreshold}
                  onChange={(e) => setConfig({ ...config, creditThreshold: parseInt(e.target.value) })}
                  className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Inactivity Period (hours)
                </label>
                <input
                  type="number"
                  value={config.inactivityPeriod}
                  onChange={(e) => setConfig({ ...config, inactivityPeriod: parseInt(e.target.value) })}
                  className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  min="1"
                />
              </div>
            </div>
          </div>

          {/* Recipients */}
          <div>
            <h3 className="text-lg font-medium mb-4">Alert Recipients</h3>
            <div className="space-y-2">
              {config.recipients.map((email, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      const newRecipients = [...config.recipients];
                      newRecipients[index] = e.target.value;
                      setConfig({ ...config, recipients: newRecipients });
                    }}
                    className="flex-1 rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  />
                  <button
                    onClick={() => {
                      const newRecipients = config.recipients.filter((_, i) => i !== index);
                      setConfig({ ...config, recipients: newRecipients });
                    }}
                    className="text-red-500 hover:text-red-700"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}
              <button
                onClick={() => setConfig({
                  ...config,
                  recipients: [...config.recipients, '']
                })}
                className="text-indigo-600 hover:text-indigo-700 text-sm font-medium"
              >
                + Add Recipient
              </button>
            </div>
          </div>

          {/* Notification Channels */}
          <div>
            <h3 className="text-lg font-medium mb-4">Notification Channels</h3>
            <div className="space-y-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={config.channels.email}
                  onChange={(e) => setConfig({
                    ...config,
                    channels: { ...config.channels, email: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <Mail className="h-5 w-5 ml-2 mr-2 text-gray-400" />
                <span className="text-sm text-gray-700">Email Notifications</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={config.channels.slack}
                  onChange={(e) => setConfig({
                    ...config,
                    channels: { ...config.channels, slack: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <MessageSquare className="h-5 w-5 ml-2 mr-2 text-gray-400" />
                <span className="text-sm text-gray-700">Slack Notifications</span>
              </label>

              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={config.channels.webhook}
                  onChange={(e) => setConfig({
                    ...config,
                    channels: { ...config.channels, webhook: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <Globe className="h-5 w-5 ml-2 mr-2 text-gray-400" />
                <span className="text-sm text-gray-700">Webhook Notifications</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center"
            >
              <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
              {isSaving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubAccountAlerts;