import React, { useState } from 'react';
import { Code, Copy, Check, Settings, Globe } from 'lucide-react';
import toast from 'react-hot-toast';

const EmbedCodeGenerator: React.FC = () => {
  const [settings, setSettings] = useState({
    width: '380',
    height: '600',
    position: 'bottom-right',
    theme: 'light',
    autoOpen: false,
    delay: 3
  });
  const [copied, setCopied] = useState(false);

  const generateEmbedCode = () => {
    const positionStyles = {
      'bottom-right': 'bottom: 20px; right: 20px;',
      'bottom-left': 'bottom: 20px; left: 20px;',
      'top-right': 'top: 20px; right: 20px;',
      'top-left': 'top: 20px; left: 20px;'
    };

    return `<!-- AI Chatbot Widget -->
<div id="ai-chatbot-widget" style="position: fixed; ${positionStyles[settings.position as keyof typeof positionStyles]} z-index: 9999;">
  <iframe 
    src="${window.location.origin}/external-chat?theme=${settings.theme}${settings.autoOpen ? '&autoOpen=true' : ''}&delay=${settings.delay}"
    width="${settings.width}"
    height="${settings.height}"
    style="border: none; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);"
    allow="microphone"
    title="Chat Support"
  ></iframe>
</div>`;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generateEmbedCode());
    setCopied(true);
    toast.success('Embed code copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold text-indigo-900 mb-4 flex items-center">
          <Globe className="h-6 w-6 mr-2" />
          Widget Configuration
        </h2>
        <p className="text-indigo-800">
          Customize your chat widget's appearance and behavior before embedding it on your website.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Appearance Settings */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4 flex items-center">
            <Settings className="h-5 w-5 mr-2 text-indigo-600" />
            Appearance
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Width (px)
              </label>
              <input
                type="number"
                value={settings.width}
                onChange={(e) => setSettings({ ...settings, width: e.target.value })}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Height (px)
              </label>
              <input
                type="number"
                value={settings.height}
                onChange={(e) => setSettings({ ...settings, height: e.target.value })}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Position
              </label>
              <select
                value={settings.position}
                onChange={(e) => setSettings({ ...settings, position: e.target.value })}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              >
                <option value="bottom-right">Bottom Right</option>
                <option value="bottom-left">Bottom Left</option>
                <option value="top-right">Top Right</option>
                <option value="top-left">Top Left</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Theme
              </label>
              <select
                value={settings.theme}
                onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </div>
          </div>
        </div>

        {/* Behavior Settings */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium mb-4 flex items-center">
            <Settings className="h-5 w-5 mr-2 text-indigo-600" />
            Behavior
          </h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="autoOpen"
                checked={settings.autoOpen}
                onChange={(e) => setSettings({ ...settings, autoOpen: e.target.checked })}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <label htmlFor="autoOpen" className="ml-2 text-sm text-gray-700">
                Auto-open widget
              </label>
            </div>
            {settings.autoOpen && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Open delay (seconds)
                </label>
                <input
                  type="number"
                  value={settings.delay}
                  onChange={(e) => setSettings({ ...settings, delay: parseInt(e.target.value) })}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  min="0"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Embed Code */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium flex items-center">
            <Code className="h-5 w-5 mr-2 text-indigo-600" />
            Embed Code
          </h3>
          <button
            onClick={handleCopyCode}
            className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            {copied ? (
              <>
                <Check className="h-5 w-5 mr-2" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="h-5 w-5 mr-2" />
                Copy Code
              </>
            )}
          </button>
        </div>
        <div className="relative">
          <pre className="bg-gray-50 rounded-lg p-4 text-sm font-mono overflow-x-auto">
            {generateEmbedCode()}
          </pre>
        </div>
      </div>

      {/* Preview */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4">Widget Preview</h3>
        <div className="relative h-[600px] border rounded-lg overflow-hidden">
          <iframe
            src={`/external-chat?theme=${settings.theme}`}
            width="100%"
            height="100%"
            style={{ border: 'none' }}
            title="Chat Widget Preview"
          />
        </div>
      </div>
    </div>
  );
};

export default EmbedCodeGenerator;