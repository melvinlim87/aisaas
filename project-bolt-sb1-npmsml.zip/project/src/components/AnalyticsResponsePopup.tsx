import React, { useState } from 'react';
import { X, Download, ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import AnalyticsVisualization from './AnalyticsVisualization';

interface AnalyticsResponsePopupProps {
  isOpen: boolean;
  onClose: () => void;
  response: {
    content: string;
    metadata?: {
      analytics?: {
        chartConfig?: any[];
      };
    };
  } | null;
}

const AnalyticsResponsePopup: React.FC<AnalyticsResponsePopupProps> = ({
  isOpen,
  onClose,
  response
}) => {
  const [currentChartIndex, setCurrentChartIndex] = useState(0);
  
  if (!isOpen || !response) return null;

  const charts = response.metadata?.analytics?.chartConfig || [];
  const hasCharts = charts.length > 0;

  const nextChart = () => {
    setCurrentChartIndex((prev) => (prev + 1) % charts.length);
  };

  const prevChart = () => {
    setCurrentChartIndex((prev) => (prev - 1 + charts.length) % charts.length);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-4xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-semibold">Analytics Insights</h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                const blob = new Blob([response.content], { type: 'text/markdown' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'analytics-report.md';
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Download Report"
            >
              <Download className="h-5 w-5" />
            </button>
            <button
              onClick={() => {
                const win = window.open('', '_blank');
                if (win) {
                  win.document.write(`
                    <html>
                      <head>
                        <title>Analytics Report</title>
                        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/github-markdown-css/github-markdown.min.css">
                        <style>
                          .markdown-body {
                            box-sizing: border-box;
                            min-width: 200px;
                            max-width: 980px;
                            margin: 0 auto;
                            padding: 45px;
                          }
                        </style>
                      </head>
                      <body class="markdown-body">
                        ${response.content}
                      </body>
                    </html>
                  `);
                }
              }}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Open in New Tab"
            >
              <ExternalLink className="h-5 w-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg"
              title="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="prose max-w-none">
            <ReactMarkdown
              components={{
                h1: ({ children }) => (
                  <h1 className="text-3xl font-bold mt-8 mb-6 pb-2 border-b">{children}</h1>
                ),
                h2: ({ children }) => (
                  <h2 className="text-2xl font-bold mt-8 mb-4">{children}</h2>
                ),
                h3: ({ children }) => (
                  <h3 className="text-xl font-semibold mt-6 mb-3">{children}</h3>
                ),
                p: ({ children }) => (
                  <p className="my-4 leading-relaxed whitespace-pre-line">{children}</p>
                ),
                ul: ({ children }) => (
                  <ul className="my-4 list-disc pl-6 space-y-2">{children}</ul>
                ),
                ol: ({ children }) => (
                  <ol className="my-4 list-decimal pl-6 space-y-2">{children}</ol>
                ),
                li: ({ children }) => (
                  <li className="mb-2">{children}</li>
                ),
                blockquote: ({ children }) => (
                  <blockquote className="border-l-4 border-blue-500 pl-4 my-4 italic bg-blue-50 py-2 rounded">
                    {children}
                  </blockquote>
                ),
                code: ({ inline, children }) => (
                  inline ? (
                    <code className="bg-gray-100 text-gray-800 px-1 rounded">{children}</code>
                  ) : (
                    <pre className="bg-gray-800 text-white p-4 rounded-lg my-4 overflow-x-auto">
                      <code>{children}</code>
                    </pre>
                  )
                )
              }}
            >
              {response.content}
            </ReactMarkdown>

            {hasCharts && (
              <div className="mt-8 bg-gray-50 rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Data Visualizations</h3>
                  {charts.length > 1 && (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={prevChart}
                        className="p-1 hover:bg-gray-200 rounded-full"
                      >
                        <ChevronLeft className="h-5 w-5" />
                      </button>
                      <span className="text-sm text-gray-600">
                        {currentChartIndex + 1} / {charts.length}
                      </span>
                      <button
                        onClick={nextChart}
                        className="p-1 hover:bg-gray-200 rounded-full"
                      >
                        <ChevronRight className="h-5 w-5" />
                      </button>
                    </div>
                  )}
                </div>
                <AnalyticsVisualization 
                  config={charts[currentChartIndex]} 
                  className="w-full h-[400px]" 
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsResponsePopup;