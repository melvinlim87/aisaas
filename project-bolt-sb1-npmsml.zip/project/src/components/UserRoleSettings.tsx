import React, { useState } from 'react';
import { Shield, Lock, Save, Plus, Trash, User, UserPlus, X } from 'lucide-react';
import toast from 'react-hot-toast';
import { UserRole, DEFAULT_ROLE_PERMISSIONS, RESOURCE_LABELS } from '../types/user';

interface RoleSettings {
  id: string;
  name: string;
  description: string;
  permissions: {
    [key: string]: {
      view: boolean;
      create: boolean;
      update: boolean;
      delete: boolean;
    };
  };
  notifications: {
    ticketAssigned: boolean;
    ticketUpdated: boolean;
    newMessage: boolean;
  };
}

interface UserData {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'inactive';
}

const UserRoleSettings: React.FC = () => {
  // Role Management State
  const [roles, setRoles] = useState<RoleSettings[]>([
    {
      id: 'owner',
      name: 'Owner',
      description: 'Full system access and control',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: true, create: true, update: true, delete: true }
      }), {}),
      notifications: { ticketAssigned: true, ticketUpdated: true, newMessage: true }
    },
    {
      id: 'admin',
      name: 'Administrator',
      description: 'Administrative access to all features',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: true, create: true, update: true, delete: true }
      }), {}),
      notifications: { ticketAssigned: true, ticketUpdated: true, newMessage: true }
    },
    {
      id: 'manager',
      name: 'Manager',
      description: 'Manage team and operations',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: true, create: true, update: true, delete: false }
      }), {}),
      notifications: { ticketAssigned: true, ticketUpdated: true, newMessage: true }
    },
    {
      id: 'agent',
      name: 'Support Agent',
      description: 'Handle customer support and tickets',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: true, create: true, update: false, delete: false }
      }), {}),
      notifications: { ticketAssigned: true, ticketUpdated: true, newMessage: true }
    },
    {
      id: 'viewer',
      name: 'Viewer',
      description: 'View-only access to system',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: true, create: false, update: false, delete: false }
      }), {}),
      notifications: { ticketAssigned: false, ticketUpdated: false, newMessage: true }
    }
  ]);

  // User Management State
  const [users, setUsers] = useState<UserData[]>([
    { id: '1', name: 'John Admin', email: 'admin@example.com', role: 'admin', status: 'active' },
    { id: '2', name: 'Jane Agent', email: 'agent@example.com', role: 'agent', status: 'active' }
  ]);

  const [selectedRole, setSelectedRole] = useState<RoleSettings | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState<Partial<UserData>>({
    name: '',
    email: '',
    role: 'agent'
  });

  const [activeTab, setActiveTab] = useState<'roles' | 'users'>('roles');

  const handlePermissionChange = (
    resource: string,
    action: keyof RoleSettings['permissions'][string],
    checked: boolean
  ) => {
    if (!selectedRole) return;

    setSelectedRole({
      ...selectedRole,
      permissions: {
        ...selectedRole.permissions,
        [resource]: {
          ...selectedRole.permissions[resource],
          [action]: checked
        }
      }
    });
  };

  const handleNotificationChange = (
    type: keyof RoleSettings['notifications'],
    checked: boolean
  ) => {
    if (!selectedRole) return;

    setSelectedRole({
      ...selectedRole,
      notifications: {
        ...selectedRole.notifications,
        [type]: checked
      }
    });
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      if (selectedRole) {
        setRoles(prev => prev.map(role => 
          role.id === selectedRole.id ? selectedRole : role
        ));
        toast.success('Role settings saved successfully');
      }
    } catch (error) {
      toast.error('Failed to save role settings');
    } finally {
      setIsSaving(false);
      setIsEditing(false);
    }
  };

  const handleAddRole = () => {
    const newRole: RoleSettings = {
      id: `role_${Date.now()}`,
      name: 'New Role',
      description: 'Custom role description',
      permissions: Object.keys(RESOURCE_LABELS).reduce((acc, resource) => ({
        ...acc,
        [resource]: { view: false, create: false, update: false, delete: false }
      }), {}),
      notifications: { ticketAssigned: false, ticketUpdated: false, newMessage: false }
    };
    setRoles([...roles, newRole]);
    setSelectedRole(newRole);
    setIsEditing(true);
  };

  const handleDeleteRole = (roleId: string) => {
    if (['owner', 'admin', 'manager', 'agent', 'viewer'].includes(roleId)) {
      toast.error('Cannot delete default roles');
      return;
    }
    setRoles(prev => prev.filter(role => role.id !== roleId));
    if (selectedRole?.id === roleId) {
      setSelectedRole(null);
      setIsEditing(false);
    }
    toast.success('Role deleted successfully');
  };

  const handleAddUser = async () => {
    try {
      if (!newUser.name || !newUser.email || !newUser.role) {
        toast.error('Please fill in all required fields');
        return;
      }

      const user: UserData = {
        id: `user_${Date.now()}`,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        status: 'active'
      };

      setUsers([...users, user]);
      setShowAddUser(false);
      setNewUser({ name: '', email: '', role: 'agent' });
      toast.success('User added successfully');
    } catch (error) {
      toast.error('Failed to add user');
    }
  };

  const handleUpdateRole = async (userId: string, newRole: UserRole) => {
    try {
      setUsers(users.map(user => 
        user.id === userId ? { ...user, role: newRole } : user
      ));
      toast.success('User role updated successfully');
    } catch (error) {
      toast.error('Failed to update user role');
    }
  };

  const handleUpdateStatus = async (userId: string, newStatus: 'active' | 'inactive') => {
    try {
      setUsers(users.map(user => 
        user.id === userId ? { ...user, status: newStatus } : user
      ));
      toast.success('User status updated successfully');
    } catch (error) {
      toast.error('Failed to update user status');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center">
          <Shield className="h-5 w-5 mr-2" />
          User & Role Management
        </h2>
        <div className="flex space-x-4">
          <div className="flex rounded-lg overflow-hidden">
            <button
              onClick={() => setActiveTab('roles')}
              className={`px-4 py-2 ${
                activeTab === 'roles'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Roles
            </button>
            <button
              onClick={() => setActiveTab('users')}
              className={`px-4 py-2 ${
                activeTab === 'users'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Users
            </button>
          </div>
          {activeTab === 'roles' ? (
            <button
              onClick={handleAddRole}
              className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Role
            </button>
          ) : (
            <button
              onClick={() => setShowAddUser(true)}
              className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center"
            >
              <UserPlus className="h-5 w-5 mr-2" />
              Add User
            </button>
          )}
        </div>
      </div>

      {activeTab === 'roles' ? (
        <div className="grid grid-cols-4 gap-6">
          <div className="col-span-1">
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium mb-4">Available Roles</h3>
              <ul className="space-y-2">
                {roles.map(role => (
                  <li key={role.id} className="flex items-center justify-between">
                    <button
                      onClick={() => {
                        setSelectedRole(role);
                        setIsEditing(false);
                      }}
                      className={`flex-1 text-left px-3 py-2 rounded-lg ${
                        selectedRole?.id === role.id
                          ? 'bg-blue-50 text-blue-600'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      {role.name}
                    </button>
                    {!['owner', 'admin', 'manager', 'agent', 'viewer'].includes(role.id) && (
                      <button
                        onClick={() => handleDeleteRole(role.id)}
                        className="ml-2 text-red-500 hover:text-red-700"
                      >
                        <Trash className="h-4 w-4" />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {selectedRole && (
            <div className="col-span-3 bg-white rounded-lg shadow p-6">
              <div className="mb-6">
                <input
                  type="text"
                  value={selectedRole.name}
                  onChange={(e) => setSelectedRole({ ...selectedRole, name: e.target.value })}
                  disabled={!isEditing}
                  className="text-xl font-semibold bg-transparent border-b border-transparent focus:border-blue-500 focus:outline-none disabled:opacity-75"
                />
                <textarea
                  value={selectedRole.description}
                  onChange={(e) => setSelectedRole({ ...selectedRole, description: e.target.value })}
                  disabled={!isEditing}
                  className="mt-2 w-full bg-transparent border-b border-transparent focus:border-blue-500 focus:outline-none disabled:opacity-75 resize-none"
                />
                {!isEditing && (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="mt-2 text-blue-500 text-sm hover:text-blue-700"
                  >
                    Edit Details
                  </button>
                )}
              </div>

              <div className="space-y-6">
                {Object.entries(RESOURCE_LABELS).map(([resource, label]) => (
                  <div key={resource} className="border-b pb-4">
                    <div className="flex items-center mb-2">
                      <Lock className="h-4 w-4 mr-2 text-gray-400" />
                      <span className="font-medium">{label}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-4">
                      {Object.entries(selectedRole.permissions[resource]).map(([action, value]) => (
                        <label key={action} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={value}
                            onChange={(e) => handlePermissionChange(resource, action as keyof RoleSettings['permissions'][string], e.target.checked)}
                            disabled={!isEditing || selectedRole.id === 'owner'}
                            className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 disabled:opacity-50"
                          />
                          <span className="ml-2 text-sm capitalize">{action}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}

                <div>
                  <h4 className="font-medium mb-4">Notification Preferences</h4>
                  <div className="grid grid-cols-3 gap-4">
                    {Object.entries(selectedRole.notifications).map(([type, enabled]) => (
                      <label key={type} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={enabled}
                          onChange={(e) => handleNotificationChange(type as keyof RoleSettings['notifications'], e.target.checked)}
                          disabled={!isEditing || selectedRole.id === 'owner'}
                          className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 disabled:opacity-50"
                        />
                        <span className="ml-2 text-sm">
                          {type.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {isEditing && (
                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
                  >
                    {isSaving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white shadow-lg rounded-lg overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10">
                        <User className="h-10 w-10 rounded-full text-gray-400" />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{user.name}</div>
                        <div className="text-sm text-gray-500">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={user.role}
                      onChange={(e) => handleUpdateRole(user.id, e.target.value as UserRole)}
                      className="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      {roles.map((role) => (
                        <option key={role.id} value={role.id}>
                          {role.name}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => handleUpdateStatus(user.id, user.status === 'active' ? 'inactive' : 'active')}
                      className={`${
                        user.status === 'active' ? 'text-red-600 hover:text-red-900' : 'text-green-600 hover:text-green-900'
                      }`}
                    >
                      {user.status === 'active' ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUser && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Add New User</h2>
              <button onClick={() => setShowAddUser(false)} className="text-gray-500 hover:text-gray-700">
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Role</label>
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({ ...newUser, role: e.target.value as UserRole })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  {roles.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowAddUser(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleAddUser}
                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
              >
                Add User
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserRoleSettings;