import React, { useState } from 'react';
import { Settings, Save } from 'lucide-react';
import toast from 'react-hot-toast';
import ChannelSettings from './ChannelSettings';
import { ChannelConfig } from '../types/channels';

const IntegrationSettings: React.FC = () => {
  const [channels, setChannels] = useState<ChannelConfig[]>([
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      enabled: false,
      credentials: {
        apiKey: '',
        apiSecret: ''
      },
      webhook: {
        url: '/api/webhooks/whatsapp',
        secret: ''
      },
      settings: {
        autoReply: true,
        welcomeMessage: 'Hello! How can I assist you today?',
        handoffThreshold: 0.8,
        maxQueueSize: 1000
      }
    },
    {
      id: 'messenger',
      name: 'Facebook Messenger',
      enabled: false,
      credentials: {
        accessToken: '',
        verifyToken: ''
      },
      webhook: {
        url: '/api/webhooks/messenger',
        secret: ''
      },
      settings: {
        autoReply: true,
        welcomeMessage: 'Hi! Welcome to our Messenger chat. How can I help?',
        handoffThreshold: 0.8,
        maxQueueSize: 1000
      }
    },
    {
      id: 'instagram',
      name: 'Instagram',
      enabled: false,
      credentials: {
        accessToken: ''
      },
      webhook: {
        url: '/api/webhooks/instagram',
        secret: ''
      },
      settings: {
        autoReply: true,
        welcomeMessage: 'Hello! Thanks for reaching out. How can I assist you?',
        handoffThreshold: 0.8,
        maxQueueSize: 1000
      }
    },
    {
      id: 'telegram',
      name: 'Telegram',
      enabled: false,
      credentials: {
        apiKey: ''
      },
      webhook: {
        url: '/api/webhooks/telegram',
        secret: ''
      },
      settings: {
        autoReply: true,
        welcomeMessage: 'Hi! Welcome to our Telegram bot. How can I help you today?',
        handoffThreshold: 0.8,
        maxQueueSize: 1000
      }
    }
  ]);

  const handleUpdateChannel = async (updatedConfig: ChannelConfig) => {
    try {
      // Here you would typically make an API call to update the channel configuration
      setChannels(prev =>
        prev.map(channel =>
          channel.id === updatedConfig.id ? updatedConfig : channel
        )
      );
      
      toast.success(`${updatedConfig.name} settings updated successfully`);
    } catch (error) {
      console.error('Error updating channel:', error);
      toast.error(`Failed to update ${updatedConfig.name} settings`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Channel Integrations</h2>
      </div>

      <div className="space-y-6">
        {channels.map(channel => (
          <ChannelSettings
            key={channel.id}
            channel={channel}
            onUpdate={handleUpdateChannel}
          />
        ))}
      </div>
    </div>
  );
};

export default IntegrationSettings;