import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Maximize2, Minimize2 } from 'lucide-react';
import ExternalChatInterface from './ExternalChatInterface';

interface ExternalChatWidgetProps {
  embedded?: boolean;
}

const ExternalChatWidget: React.FC<ExternalChatWidgetProps> = ({ embedded = false }) => {
  const [isOpen, setIsOpen] = useState(embedded);
  const [isExpanded, setIsExpanded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (embedded) {
      setIsOpen(true);
    }
  }, [embedded]);

  if (embedded) {
    return (
      <div ref={containerRef} className="h-full">
        <ExternalChatInterface embedded={true} />
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-colors duration-200"
        >
          <MessageSquare className="h-6 w-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div
          ref={containerRef}
          className={`bg-white rounded-lg shadow-2xl overflow-hidden transition-all duration-200 ${
            isExpanded ? 'fixed inset-4' : 'w-[380px] h-[600px]'
          }`}
          style={{ maxHeight: isExpanded ? 'none' : '80vh' }}
        >
          {/* Header */}
          <div className="bg-indigo-600 text-white px-4 py-3 flex items-center justify-between">
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2" />
              <h3 className="font-semibold">Chat Support</h3>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1 hover:bg-indigo-700 rounded"
              >
                {isExpanded ? (
                  <Minimize2 className="h-4 w-4" />
                ) : (
                  <Maximize2 className="h-4 w-4" />
                )}
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 hover:bg-indigo-700 rounded"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Chat Interface */}
          <div className="h-[calc(100%-48px)]">
            <ExternalChatInterface embedded={true} />
          </div>
        </div>
      )}
    </div>
  );
};

export default ExternalChatWidget;