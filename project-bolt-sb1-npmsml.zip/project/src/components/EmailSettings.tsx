import React, { useState } from 'react';
import { Mail, Key, Globe, Save, AlertCircle } from 'lucide-react';
import { emailService } from '../services/emailService';
import toast from 'react-hot-toast';

interface EmailSettings {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
  from: string;
  dnsSettings: {
    spfRecord: string;
    dkimSelector: string;
    dkimPrivateKey: string;
    dkimPublicKey: string;
    dmarcRecord: string;
  };
}

const EmailSettings: React.FC = () => {
  const [settings, setSettings] = useState<EmailSettings>({
    host: '',
    port: 587,
    secure: true,
    auth: {
      user: '',
      pass: ''
    },
    from: '',
    dnsSettings: {
      spfRecord: 'v=spf1 include:_spf.yourdomain.com ~all',
      dkimSelector: 'mail',
      dkimPrivateKey: '',
      dkimPublicKey: '',
      dmarcRecord: 'v=DMARC1; p=reject; rua=mailto:dmarc@yourdomain.com'
    }
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      emailService.setConfig(settings);
      toast.success('Email settings saved successfully');
    } catch (error) {
      console.error('Error saving email settings:', error);
      toast.error('Failed to save email settings');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center">
          <Mail className="h-6 w-6 mr-2" />
          Email Settings
        </h2>
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center disabled:opacity-50"
        >
          <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
          {isSaving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>

      {/* SMTP Settings */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Mail className="h-5 w-5 mr-2" />
          SMTP Configuration
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">SMTP Host</label>
            <input
              type="text"
              value={settings.host}
              onChange={(e) => setSettings({ ...settings, host: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="smtp.yourdomain.com"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">SMTP Port</label>
            <input
              type="number"
              value={settings.port}
              onChange={(e) => setSettings({ ...settings, port: parseInt(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <input
              type="text"
              value={settings.auth.user}
              onChange={(e) => setSettings({
                ...settings,
                auth: { ...settings.auth, user: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <input
              type="password"
              value={settings.auth.pass}
              onChange={(e) => setSettings({
                ...settings,
                auth: { ...settings.auth, pass: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">From Address</label>
            <input
              type="email"
              value={settings.from}
              onChange={(e) => setSettings({ ...settings, from: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="noreply@yourdomain.com"
            />
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              checked={settings.secure}
              onChange={(e) => setSettings({ ...settings, secure: e.target.checked })}
              className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
            />
            <label className="ml-2 text-sm text-gray-700">Use SSL/TLS</label>
          </div>
        </div>
      </div>

      {/* DNS Settings */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <Globe className="h-5 w-5 mr-2" />
          DNS Configuration
        </h3>
        <div className="space-y-4">
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-yellow-400 mr-2" />
              <p className="text-sm text-yellow-700">
                Add these DNS records to your domain to ensure proper email delivery and authentication.
              </p>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">SPF Record (TXT)</label>
            <input
              type="text"
              value={settings.dnsSettings.spfRecord}
              onChange={(e) => setSettings({
                ...settings,
                dnsSettings: { ...settings.dnsSettings, spfRecord: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">DKIM Selector</label>
            <input
              type="text"
              value={settings.dnsSettings.dkimSelector}
              onChange={(e) => setSettings({
                ...settings,
                dnsSettings: { ...settings.dnsSettings, dkimSelector: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">DKIM Private Key</label>
            <textarea
              value={settings.dnsSettings.dkimPrivateKey}
              onChange={(e) => setSettings({
                ...settings,
                dnsSettings: { ...settings.dnsSettings, dkimPrivateKey: e.target.value }
              })}
              rows={4}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">DKIM Public Key (TXT)</label>
            <textarea
              value={settings.dnsSettings.dkimPublicKey}
              onChange={(e) => setSettings({
                ...settings,
                dnsSettings: { ...settings.dnsSettings, dkimPublicKey: e.target.value }
              })}
              rows={4}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">DMARC Record (TXT)</label>
            <input
              type="text"
              value={settings.dnsSettings.dmarcRecord}
              onChange={(e) => setSettings({
                ...settings,
                dnsSettings: { ...settings.dnsSettings, dmarcRecord: e.target.value }
              })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono text-sm"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailSettings;