import React, { useState, useRef, useEffect, useCallback } from 'react';
import { MessageSquare, Send, Bot, HelpCircle, Loader } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { chatbotService } from '../services/chatbotService';
import { conversationPersistence } from '../services/conversationPersistence';
import LiveChatTransferButton from './LiveChatTransferButton';
import toast from 'react-hot-toast';
import { Message } from '../types/chat';
import { walletService } from '../services/walletService';

interface ExternalChatInterfaceProps {
  embedded?: boolean;
}

const commonPrompts = [
  'What services do you offer?',
  'How can I get started?',
  'What are your pricing plans?',
  'How do I contact support?'
];

const ExternalChatInterface: React.FC<ExternalChatInterfaceProps> = ({ embedded }) => {
  const [messages, setMessages] = useState<Message[]>([{
    id: '1',
    content: "Hello! I'm your AI assistant. How can I help you today?",
    role: 'assistant',
    timestamp: new Date()
  }]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTransferring, setIsTransferring] = useState(false);
  const [isWithAgent, setIsWithAgent] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const loadConversationHistory = useCallback(async () => {
    try {
      const savedMessages = await conversationPersistence.getConversation();
      if (savedMessages.length > 0) {
        setMessages(savedMessages);
        setShowSuggestions(false);
      }
    } catch (error) {
      console.error('Error loading conversation history:', error);
      setError('Failed to load conversation history');
    }
  }, []);

  useEffect(() => {
    loadConversationHistory();
  }, [loadConversationHistory]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (content: string = input) => {
    if (!content.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: content.trim(),
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setShowSuggestions(false);
    setIsLoading(true);
    setError(null);

    try {
      // Process the message
      const response = await chatbotService.processMessage(content, 'external');

      // Deduct credits for the response
      await walletService.addTransaction({
        type: 'debit',
        amount: 0.01, // Fixed cost per response
        description: 'External AI Chat Usage',
        status: 'completed',
        metadata: {
          aiModel: 'GPT-4',
          promptTokens: content.length,
          completionTokens: response.content.length
        }
      });

      // Update messages with the response
      const updatedMessages = [...messages, userMessage, response];
      setMessages(updatedMessages);
      await conversationPersistence.saveConversation(updatedMessages);
    } catch (error) {
      console.error('Error processing message:', error);
      setError('Failed to process your message. Please try again.');
      toast.error('Failed to process your message');
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleClearHistory = async () => {
    try {
      await conversationPersistence.clearConversation();
      setMessages([{
        id: '1',
        content: "Hello! I'm your AI assistant. How can I help you today?",
        role: 'assistant',
        timestamp: new Date()
      }]);
      setShowSuggestions(true);
      setError(null);
      toast.success('Conversation history cleared');
    } catch (error) {
      console.error('Error clearing conversation history:', error);
      toast.error('Failed to clear conversation history');
    }
  };

  const handleTransferToAgent = async () => {
    try {
      setIsTransferring(true);
      setError(null);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setIsWithAgent(true);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        content: "You've been connected to a live agent. Please wait while they review your conversation.",
        role: 'system',
        timestamp: new Date()
      }]);
      
      toast.success('Connected to live agent');
    } catch (error) {
      setError('Failed to connect to live agent');
      toast.error('Failed to connect to live agent');
    } finally {
      setIsTransferring(false);
    }
  };

  return (
    <div className={`flex flex-col h-full bg-white ${embedded ? '' : 'rounded-lg shadow-lg overflow-hidden'}`}>
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-white/10 p-2 rounded-lg backdrop-blur-lg">
              {isWithAgent ? (
                <MessageSquare className="h-6 w-6 text-white" />
              ) : (
                <Bot className="h-6 w-6 text-white" />
              )}
            </div>
            <div className="ml-3">
              <h3 className="font-semibold text-lg">
                {isWithAgent ? 'Live Support' : 'Customer Support AI'}
              </h3>
              <p className="text-sm text-white/80">
                {isWithAgent ? 'Connected to agent' : 'Available 24/7 to assist you'}
              </p>
            </div>
          </div>
          {messages.length > 1 && !isWithAgent && (
            <button
              onClick={handleClearHistory}
              className="text-white/80 hover:text-white text-sm"
            >
              Clear History
            </button>
          )}
        </div>
      </div>

      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4"
      >
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                  : message.role === 'system'
                  ? 'bg-yellow-50 text-yellow-800'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <div className="flex items-center mb-2">
                <span className="text-sm font-medium">
                  {message.role === 'assistant' ? (isWithAgent ? 'Agent' : 'AI Assistant') : 
                   message.role === 'system' ? 'System' : 'You'}
                </span>
                <span className="text-xs ml-2 opacity-75">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <ReactMarkdown
                className={`prose ${message.role === 'user' ? 'prose-invert' : ''} max-w-none`}
              >
                {message.content}
              </ReactMarkdown>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-4 flex items-center">
              <Loader className="h-5 w-5 animate-spin mr-2" />
              <span>Processing your message...</span>
            </div>
          </div>
        )}

        {error && (
          <div className="flex justify-center">
            <div className="bg-red-50 text-red-800 rounded-lg p-4 flex items-center">
              <span>{error}</span>
            </div>
          </div>
        )}

        {!isWithAgent && showSuggestions && messages.length === 1 && (
          <div className="flex flex-col items-center space-y-4 my-6">
            <div className="flex items-center text-gray-500">
              <HelpCircle className="h-4 w-4 mr-2" />
              <span className="text-sm">Common Questions</span>
            </div>
            <div className="grid grid-cols-2 gap-2 w-full">
              {commonPrompts.map((prompt, index) => (
                <button
                  key={index}
                  onClick={() => handleSend(prompt)}
                  className="text-left p-3 text-sm bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors duration-200 border border-gray-200"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {!isWithAgent && messages.length > 1 && (
        <div className="px-4 border-t border-gray-100">
          <LiveChatTransferButton
            onTransfer={handleTransferToAgent}
            isTransferring={isTransferring}
          />
        </div>
      )}

      <div className="p-4 border-t">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={`Type your message${isWithAgent ? ' to the agent' : ''}...`}
            className="flex-1 rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
            disabled={isLoading || isTransferring}
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || isTransferring || !input.trim()}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-2 rounded-lg hover:opacity-90 disabled:opacity-50 transition-opacity duration-200"
          >
            {isLoading ? (
              <Loader className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExternalChatInterface;