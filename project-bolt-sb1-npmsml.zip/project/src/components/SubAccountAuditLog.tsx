import React, { useState } from 'react';
import { X, Search, Filter, Download, Clock, User, Settings, AlertCircle } from 'lucide-react';
import { ActivityLog } from '../types/subAccount';

interface SubAccountAuditLogProps {
  subAccountId: string;
  logs: ActivityLog[];
  onClose: () => void;
}

const SubAccountAuditLog: React.FC<SubAccountAuditLogProps> = ({
  subAccountId,
  logs,
  onClose
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState<ActivityLog['action'] | 'all'>('all');
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });

  const getActionIcon = (action: ActivityLog['action']) => {
    switch (action) {
      case 'login':
        return <User className="h-4 w-4" />;
      case 'settings_change':
        return <Settings className="h-4 w-4" />;
      case 'api_call':
        return <AlertCircle className="h-4 w-4" />;
      case 'credit_usage':
        return <AlertCircle className="h-4 w-4" />;
      case 'status_change':
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getActionColor = (action: ActivityLog['action']) => {
    switch (action) {
      case 'login':
        return 'text-blue-500';
      case 'settings_change':
        return 'text-purple-500';
      case 'api_call':
        return 'text-green-500';
      case 'credit_usage':
        return 'text-yellow-500';
      case 'status_change':
        return 'text-red-500';
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.performedBy.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    const matchesDate = (!dateRange.start || new Date(log.timestamp) >= new Date(dateRange.start)) &&
                       (!dateRange.end || new Date(log.timestamp) <= new Date(dateRange.end));
    return matchesSearch && matchesAction && matchesDate;
  });

  const handleExport = () => {
    const csv = [
      ['Timestamp', 'Action', 'Description', 'Performed By', 'Metadata'],
      ...filteredLogs.map(log => [
        log.timestamp.toISOString(),
        log.action,
        log.description,
        log.performedBy,
        JSON.stringify(log.metadata || {})
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-log-${subAccountId}-${new Date().toISOString()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-4xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Activity Log & Audit Trail</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="mb-6 space-y-4">
          {/* Search and Filters */}
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search logs..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value as ActivityLog['action'] | 'all')}
              className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              <option value="all">All Actions</option>
              <option value="login">Logins</option>
              <option value="settings_change">Settings Changes</option>
              <option value="api_call">API Calls</option>
              <option value="credit_usage">Credit Usage</option>
              <option value="status_change">Status Changes</option>
            </select>
            <button
              onClick={handleExport}
              className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
            >
              <Download className="h-5 w-5 mr-2" />
              Export
            </button>
          </div>

          {/* Date Range */}
          <div className="flex space-x-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                className="border rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Logs Table */}
        <div className="border rounded-lg overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      {log.timestamp.toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`flex items-center ${getActionColor(log.action)}`}>
                      {getActionIcon(log.action)}
                      <span className="ml-2 text-sm font-medium">
                        {log.action.replace('_', ' ').toUpperCase()}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900">{log.description}</div>
                    {log.metadata && (
                      <div className="mt-1 text-xs text-gray-500">
                        {Object.entries(log.metadata).map(([key, value]) => (
                          <span key={key} className="mr-2">
                            {key}: {value}
                          </span>
                        ))}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <User className="h-4 w-4 mr-2" />
                      {log.performedBy}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SubAccountAuditLog;