import React, { useState } from 'react';
import { X, Save, AlertCircle, HardDrive, Users, MessageSquare, CreditCard } from 'lucide-react';
import { UsageQuota } from '../types/subAccount';
import toast from 'react-hot-toast';

interface SubAccountQuotasProps {
  subAccountId: string;
  currentQuotas: UsageQuota;
  currentUsage: {
    responses: number;
    credits: number;
    activeUsers: number;
    storage: number;
  };
  onSave: (quotas: UsageQuota) => Promise<void>;
  onClose: () => void;
}

const SubAccountQuotas: React.FC<SubAccountQuotasProps> = ({
  subAccountId,
  currentQuotas,
  currentUsage,
  onSave,
  onClose
}) => {
  const [quotas, setQuotas] = useState<UsageQuota>(currentQuotas);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await onSave(quotas);
      toast.success('Quotas updated successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to update quotas');
    } finally {
      setIsSaving(false);
    }
  };

  const getUsagePercentage = (used: number, limit: number) => {
    const percentage = (used / limit) * 100;
    return {
      value: Math.min(percentage, 100),
      color: percentage > 90 ? 'red' : percentage > 70 ? 'yellow' : 'green'
    };
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-2xl p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Usage Quotas & Limits</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Response Quota */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <MessageSquare className="h-4 w-4 mr-2" />
                Maximum Responses
              </label>
              <span className="text-sm text-gray-500">
                {currentUsage.responses} / {quotas.maxResponses}
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                value={quotas.maxResponses}
                onChange={(e) => setQuotas({ ...quotas, maxResponses: parseInt(e.target.value) })}
                className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                min={currentUsage.responses}
              />
              <div className="absolute -bottom-5 left-0 w-full h-1 bg-gray-200 rounded">
                <div
                  className={`h-full rounded bg-${getUsagePercentage(currentUsage.responses, quotas.maxResponses).color}-500`}
                  style={{ width: `${getUsagePercentage(currentUsage.responses, quotas.maxResponses).value}%` }}
                />
              </div>
            </div>
          </div>

          {/* Credit Quota */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <CreditCard className="h-4 w-4 mr-2" />
                Maximum Credits
              </label>
              <span className="text-sm text-gray-500">
                {currentUsage.credits} / {quotas.maxCredits}
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                value={quotas.maxCredits}
                onChange={(e) => setQuotas({ ...quotas, maxCredits: parseInt(e.target.value) })}
                className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                min={currentUsage.credits}
              />
              <div className="absolute -bottom-5 left-0 w-full h-1 bg-gray-200 rounded">
                <div
                  className={`h-full rounded bg-${getUsagePercentage(currentUsage.credits, quotas.maxCredits).color}-500`}
                  style={{ width: `${getUsagePercentage(currentUsage.credits, quotas.maxCredits).value}%` }}
                />
              </div>
            </div>
          </div>

          {/* User Quota */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Users className="h-4 w-4 mr-2" />
                Maximum Users
              </label>
              <span className="text-sm text-gray-500">
                {currentUsage.activeUsers} / {quotas.maxUsers}
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                value={quotas.maxUsers}
                onChange={(e) => setQuotas({ ...quotas, maxUsers: parseInt(e.target.value) })}
                className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                min={currentUsage.activeUsers}
              />
              <div className="absolute -bottom-5 left-0 w-full h-1 bg-gray-200 rounded">
                <div
                  className={`h-full rounded bg-${getUsagePercentage(currentUsage.activeUsers, quotas.maxUsers).color}-500`}
                  style={{ width: `${getUsagePercentage(currentUsage.activeUsers, quotas.maxUsers).value}%` }}
                />
              </div>
            </div>
          </div>

          {/* Storage Quota */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <HardDrive className="h-4 w-4 mr-2" />
                Maximum Storage (MB)
              </label>
              <span className="text-sm text-gray-500">
                {currentUsage.storage} / {quotas.maxStorage} MB
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                value={quotas.maxStorage}
                onChange={(e) => setQuotas({ ...quotas, maxStorage: parseInt(e.target.value) })}
                className="w-full rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                min={currentUsage.storage}
              />
              <div className="absolute -bottom-5 left-0 w-full h-1 bg-gray-200 rounded">
                <div
                  className={`h-full rounded bg-${getUsagePercentage(currentUsage.storage, quotas.maxStorage).color}-500`}
                  style={{ width: `${getUsagePercentage(currentUsage.storage, quotas.maxStorage).value}%` }}
                />
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mt-6">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-yellow-400 mr-2" />
              <p className="text-sm text-yellow-700">
                When a quota is reached, the sub-account will be automatically paused until the limit is increased or usage is reduced.
              </p>
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center"
            >
              <Save className={`h-5 w-5 mr-2 ${isSaving ? 'animate-spin' : ''}`} />
              {isSaving ? 'Saving...' : 'Save Quotas'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubAccountQuotas;