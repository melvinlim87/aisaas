import React, { useState, useEffect } from 'react';
import { MessageSquare, User, Clock, Search, Filter, Globe, Phone, MessageCircle, Mail, ChevronLeft, ChevronRight } from 'lucide-react';
import AgentChatInterface from './AgentChatInterface';
import { Conversation } from '../../types/chat';
import toast from 'react-hot-toast';

type Channel = 'web' | 'whatsapp' | 'messenger' | 'instagram' | 'all';

const AgentDashboard: React.FC = () => {
  const [activeChats, setActiveChats] = useState<Conversation[]>([]);
  const [selectedChat, setSelectedChat] = useState<Conversation | null>(null);
  const [isOnline, setIsOnline] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChannel, setSelectedChannel] = useState<Channel>('all');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  const handleStatusToggle = () => {
    setIsOnline(!isOnline);
    toast.success(`Status set to ${!isOnline ? 'Online' : 'Offline'}`);
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const getChannelIcon = (channel: Channel) => {
    switch (channel) {
      case 'web':
        return <Globe className="h-4 w-4" />;
      case 'whatsapp':
        return <Phone className="h-4 w-4" />;
      case 'messenger':
        return <MessageCircle className="h-4 w-4" />;
      case 'instagram':
        return <Mail className="h-4 w-4" />;
      default:
        return <MessageSquare className="h-4 w-4" />;
    }
  };

  const getChannelColor = (channel: Channel) => {
    switch (channel) {
      case 'web':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'whatsapp':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'messenger':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'instagram':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getChannelLabel = (channel: Channel): string => {
    switch (channel) {
      case 'web':
        return 'Website';
      case 'whatsapp':
        return 'WhatsApp';
      case 'messenger':
        return 'Messenger';
      case 'instagram':
        return 'Instagram';
      default:
        return 'All Channels';
    }
  };

  // Calculate channel counts
  const channelCounts = activeChats.reduce((acc, chat) => {
    const channel = chat.channel as Channel;
    acc[channel] = (acc[channel] || 0) + 1;
    return acc;
  }, {} as Record<Channel, number>);

  // Filter chats based on search and selected channel
  const filteredChats = activeChats.filter(chat => {
    const matchesSearch = searchTerm 
      ? chat.messages.some(msg => 
          msg.content.toLowerCase().includes(searchTerm.toLowerCase())
        ) || chat.userId?.toLowerCase().includes(searchTerm.toLowerCase())
      : true;

    const matchesChannel = selectedChannel === 'all' || chat.channel === selectedChannel;

    return matchesSearch && matchesChannel;
  });

  useEffect(() => {
    // Mock data for demonstration
    const mockChats: Conversation[] = [
      {
        id: '1',
        messages: [{ id: 'm1', content: 'Hi, I need help with my order', role: 'user', timestamp: new Date() }],
        channel: 'web',
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date(),
        userId: 'John Doe'
      },
      {
        id: '2',
        messages: [{ id: 'm2', content: 'When will my package arrive?', role: 'user', timestamp: new Date() }],
        channel: 'whatsapp',
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date(),
        userId: 'Jane Smith'
      },
      {
        id: '3',
        messages: [{ id: 'm3', content: 'I want to change my subscription', role: 'user', timestamp: new Date() }],
        channel: 'messenger',
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date(),
        userId: 'Mike Johnson'
      },
      {
        id: '4',
        messages: [{ id: 'm4', content: 'Is there a mobile app available?', role: 'user', timestamp: new Date() }],
        channel: 'instagram',
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date(),
        userId: 'Sarah Wilson'
      }
    ];

    setActiveChats(mockChats);
  }, []);

  const stats = {
    total: activeChats.length,
    active: activeChats.filter(c => c.status === 'active').length,
  };

  return (
    <div className="flex h-full bg-gray-50">
      {/* Sidebar Container */}
      <div className={`relative flex flex-col h-full transition-all duration-300 ease-in-out ${
        isSidebarCollapsed ? 'w-0' : 'w-96'
      }`}>
        {/* Toggle Button Container */}
        <div className="absolute inset-y-0 right-0 flex items-center" style={{ transform: 'translateX(50%)' }}>
          <button
            onClick={toggleSidebar}
            className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full p-1 shadow-lg z-50"
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="h-5 w-5" />
            ) : (
              <ChevronLeft className="h-5 w-5" />
            )}
          </button>
        </div>

        {/* Sidebar Content */}
        <div className={`flex flex-col h-full bg-white border-r transition-all duration-300 ${
          isSidebarCollapsed ? 'opacity-0 w-0 overflow-hidden' : 'opacity-100 w-full'
        }`}>
          {/* Header */}
          <div className="flex-shrink-0 p-4 border-b bg-white">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Live Chat</h2>
              <button
                onClick={handleStatusToggle}
                className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors duration-200 ${
                  isOnline 
                    ? 'bg-green-100 text-green-800 hover:bg-green-200' 
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                {isOnline ? '● Online' : '○ Offline'}
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Stats */}
          <div className="flex-shrink-0 grid grid-cols-2 gap-4 p-4 bg-gray-50 border-b">
            <div className="bg-white p-3 rounded-lg border border-gray-200">
              <div className="text-sm text-gray-500">Total Chats</div>
              <div className="text-xl font-semibold text-gray-900">{stats.total}</div>
            </div>
            <div className="bg-white p-3 rounded-lg border border-gray-200">
              <div className="text-sm text-gray-500">Active</div>
              <div className="text-xl font-semibold text-gray-900">{stats.active}</div>
            </div>
          </div>

          {/* Channel Filters */}
          <div className="flex-shrink-0 p-4 border-b">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedChannel('all')}
                className={`flex flex-col items-center px-3 py-2 rounded-lg border transition-colors duration-200 min-w-[70px] ${
                  selectedChannel === 'all'
                    ? 'bg-indigo-100 text-indigo-800 border-indigo-200'
                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                <MessageSquare className="h-4 w-4 mb-1" />
                <span className="text-xs">All ({activeChats.length})</span>
              </button>
              {(['web', 'whatsapp', 'messenger', 'instagram'] as Channel[]).map(channel => (
                <button
                  key={channel}
                  onClick={() => setSelectedChannel(channel)}
                  className={`flex flex-col items-center px-3 py-2 rounded-lg border transition-colors duration-200 min-w-[70px] ${
                    selectedChannel === channel
                      ? getChannelColor(channel)
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {getChannelIcon(channel)}
                  <span className="text-xs mt-1">{getChannelLabel(channel)}</span>
                  <span className="text-xs mt-0.5">({channelCounts[channel] || 0})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Chat List */}
          <div className="flex-1 overflow-y-auto">
            {filteredChats.map((chat) => (
              <button
                key={chat.id}
                onClick={() => setSelectedChat(chat)}
                className={`w-full p-4 text-left hover:bg-gray-50 flex items-start space-x-3 border-b transition-colors duration-200 ${
                  selectedChat?.id === chat.id ? 'bg-indigo-50 hover:bg-indigo-50' : ''
                }`}
              >
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getChannelColor(chat.channel as Channel)}`}>
                    {getChannelIcon(chat.channel as Channel)}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {chat.userId}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(chat.updatedAt).toLocaleTimeString()}
                    </p>
                  </div>
                  <p className="text-sm text-gray-500 truncate mt-1">
                    {chat.messages[chat.messages.length - 1]?.content}
                  </p>
                  <div className="mt-2 flex items-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getChannelColor(chat.channel as Channel)}`}>
                      {getChannelLabel(chat.channel as Channel)}
                    </span>
                    <span className="ml-2 text-xs text-gray-500 flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {Math.floor((Date.now() - new Date(chat.createdAt).getTime()) / 60000)}m
                    </span>
                  </div>
                </div>
              </button>
            ))}

            {filteredChats.length === 0 && (
              <div className="p-8 text-center text-gray-500">
                <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No active chats</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 bg-white">
        {selectedChat ? (
          <AgentChatInterface
            conversation={selectedChat}
            onClose={() => setSelectedChat(null)}
          />
        ) : (
          <div className="h-full flex items-center justify-center text-gray-500">
            <div className="text-center">
              <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Select a chat to start responding</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AgentDashboard;