import React from 'react';
import { Activity, Clock, Brain, Target, Zap } from 'lucide-react';
import { useChatStore } from '../store/chatStore';

const TrainingMetrics: React.FC = () => {
  const { trainingActivities } = useChatStore();

  const metrics = [
    {
      title: "Total Pages Processed",
      value: trainingActivities.length * 10,
      change: `+${trainingActivities.length} in last 24h`,
      icon: Activity,
      color: "text-indigo-500"
    },
    {
      title: "Knowledge Base Size",
      value: `${trainingActivities.length * 250}KB`,
      change: `+${trainingActivities.length * 25}KB in last 24h`,
      icon: Brain,
      color: "text-purple-500"
    },
    {
      title: "Training Sessions",
      value: trainingActivities.length,
      change: `Last trained ${trainingActivities[0]?.time ? new Date(trainingActivities[0].time).toLocaleDateString() : 'Never'}`,
      icon: Target,
      color: "text-teal-500"
    }
  ];

  const performanceMetrics = [
    { label: "Processing Speed", value: 95 },
    { label: "Model Accuracy", value: 88 },
    { label: "Response Quality", value: 92 },
    { label: "Training Efficiency", value: 85 },
    { label: "Data Integration", value: 90 }
  ];

  return (
    <div className="space-y-6">
      {/* Training Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-4 border border-gray-100">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-gray-700">{metric.title}</h4>
              <metric.icon className={`h-5 w-5 ${metric.color}`} />
            </div>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {metric.value}
            </p>
            <p className="mt-1 text-sm text-gray-500">
              {metric.change}
            </p>
          </div>
        ))}
      </div>

      {/* Recent Training Activities */}
      <div className="bg-white rounded-lg shadow-lg border border-gray-100">
        <div className="p-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <Clock className="h-5 w-5 mr-2 text-indigo-500" />
            Recent Training Activities
          </h3>
        </div>
        <div className="divide-y divide-gray-200 max-h-[300px] overflow-y-auto">
          {trainingActivities.length > 0 ? (
            trainingActivities.map((activity, index) => (
              <div key={index} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors duration-150">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-indigo-50 rounded-lg">
                    <Brain className="h-5 w-5 text-indigo-500" />
                  </div>
                  <span className="text-gray-700 font-medium">{activity.event}</span>
                </div>
                <span className="text-sm text-gray-500">
                  {new Date(activity.time).toLocaleString()}
                </span>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-gray-500">
              <Brain className="h-12 w-12 mx-auto mb-3 text-gray-300" />
              <p className="font-medium">No recent training activities</p>
              <p className="text-sm mt-1">Start training your AI with files or URLs</p>
            </div>
          )}
        </div>
      </div>

      {/* Training Performance */}
      <div className="bg-white rounded-lg shadow-lg p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-6 flex items-center">
          <Zap className="h-5 w-5 mr-2 text-indigo-500" />
          Training Performance
        </h3>
        <div className="space-y-6">
          {performanceMetrics.map((metric, index) => (
            <div key={index}>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">{metric.label}</span>
                <span className="text-sm text-gray-500">{metric.value}%</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-2.5">
                <div 
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2.5 rounded-full transition-all duration-300" 
                  style={{ width: `${metric.value}%` }} 
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrainingMetrics;