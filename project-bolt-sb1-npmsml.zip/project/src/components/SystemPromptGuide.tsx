import React from 'react';
import { Book, X } from 'lucide-react';
import { DEFAULT_SYSTEM_PROMPT } from '../config/constants';

interface SystemPromptGuideProps {
  isOpen: boolean;
  onClose: () => void;
}

const SystemPromptGuide: React.FC<SystemPromptGuideProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-4xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <Book className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-xl font-semibold">AIVA System Guide</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="prose max-w-none">
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg mb-8">
              <h3 className="text-xl font-semibold text-indigo-900 mb-4">Quick Start Guide</h3>
              <p className="text-indigo-800">AIVA is your AI Virtual Assistant for Ai Business SG, designed to help with:</p>
              <ul className="list-disc pl-5 space-y-2 text-indigo-700">
                <li>Product and service information</li>
                <li>Pricing and plans</li>
                <li>Technical support</li>
                <li>Account management</li>
                <li>Company information</li>
              </ul>
            </div>

            <div className="space-y-8">
              {DEFAULT_SYSTEM_PROMPT.split('\n\n').map((section, index) => {
                if (section.trim().startsWith('#')) {
                  // Section headers
                  return (
                    <div key={index} className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">{section.replace('#', '').trim()}</h3>
                    </div>
                  );
                } else if (section.includes('-')) {
                  // Lists
                  return (
                    <div key={index} className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
                      <ul className="list-disc pl-5 space-y-2">
                        {section.split('\n').map((item, i) => (
                          <li key={i} className="text-gray-700">{item.replace('-', '').trim()}</li>
                        ))}
                      </ul>
                    </div>
                  );
                } else {
                  // Regular paragraphs
                  return (
                    <div key={index} className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
                      <p className="text-gray-700">{section}</p>
                    </div>
                  );
                }
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end p-4 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

export default SystemPromptGuide;