import React, { useState } from 'react';
import { BarChart, PieChart, LineChart, Settings, Plus, Save, Trash2, Database } from 'lucide-react';
import { Line, Bar, Pie } from 'react-chartjs-2';
import { internalDataCrawler } from '../services/internalDataCrawler';
import toast from 'react-hot-toast';

interface ChartConfig {
  id: string;
  type: 'line' | 'bar' | 'pie';
  title: string;
  data: {
    labels: string[];
    datasets: Array<{
      label: string;
      data: number[];
      backgroundColor?: string[];
      borderColor?: string;
      fill?: boolean;
    }>;
  };
}

interface CustomChartBuilderProps {
  onSave: (config: ChartConfig) => void;
  onDelete?: (id: string) => void;
  initialConfig?: ChartConfig;
}

const CustomChartBuilder: React.FC<CustomChartBuilderProps> = ({ onSave, onDelete, initialConfig }) => {
  const [chartType, setChartType] = useState<'line' | 'bar' | 'pie'>(initialConfig?.type || 'line');
  const [title, setTitle] = useState(initialConfig?.title || 'New Chart');
  const [isLoading, setIsLoading] = useState(false);

  // Sample data for each chart type
  const sampleData = {
    line: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [{
        label: 'Revenue',
        data: [30000, 35000, 32000, 38000, 42000, 45000],
        borderColor: 'rgb(139, 92, 246)',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        fill: true,
        tension: 0.4
      }]
    },
    bar: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
      datasets: [{
        label: 'Appointments',
        data: [12, 15, 8, 10, 14],
        backgroundColor: 'rgba(139, 92, 246, 0.8)',
        borderRadius: 6
      }]
    },
    pie: {
      labels: ['Active', 'Resolved', 'Pending', 'Closed'],
      datasets: [{
        data: [35, 45, 10, 10],
        backgroundColor: [
          'rgba(139, 92, 246, 0.8)',
          'rgba(45, 212, 191, 0.8)',
          'rgba(167, 139, 250, 0.8)',
          'rgba(94, 234, 212, 0.8)'
        ]
      }]
    }
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const
      }
    },
    scales: chartType !== 'pie' ? {
      y: {
        beginAtZero: true,
        grid: {
          color: 'rgba(139, 92, 246, 0.1)'
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    } : undefined
  };

  const renderChart = () => {
    const data = sampleData[chartType];
    
    switch (chartType) {
      case 'line':
        return <Line data={data} options={chartOptions} />;
      case 'bar':
        return <Bar data={data} options={chartOptions} />;
      case 'pie':
        return <Pie data={data} options={chartOptions} />;
    }
  };

  const handleSaveChart = () => {
    const config: ChartConfig = {
      id: initialConfig?.id || `chart-${Date.now()}`,
      type: chartType,
      title,
      data: sampleData[chartType]
    };
    onSave(config);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="space-y-6">
        {/* Title Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Chart Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Enter chart title"
          />
        </div>

        {/* Chart Type Selection */}
        <div className="flex space-x-4">
          <button
            onClick={() => setChartType('line')}
            className={`flex items-center p-2 rounded ${
              chartType === 'line' ? 'bg-indigo-100 text-indigo-600' : 'hover:bg-gray-100'
            }`}
          >
            <LineChart className="h-5 w-5 mr-2" />
            Line
          </button>
          <button
            onClick={() => setChartType('bar')}
            className={`flex items-center p-2 rounded ${
              chartType === 'bar' ? 'bg-indigo-100 text-indigo-600' : 'hover:bg-gray-100'
            }`}
          >
            <BarChart className="h-5 w-5 mr-2" />
            Bar
          </button>
          <button
            onClick={() => setChartType('pie')}
            className={`flex items-center p-2 rounded ${
              chartType === 'pie' ? 'bg-indigo-100 text-indigo-600' : 'hover:bg-gray-100'
            }`}
          >
            <PieChart className="h-5 w-5 mr-2" />
            Pie
          </button>
        </div>

        {/* Chart Preview */}
        <div className="border rounded-lg p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-4">Preview</h3>
          <div className="h-64">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
              </div>
            ) : (
              renderChart()
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end space-x-2">
          {onDelete && initialConfig && (
            <button
              onClick={() => onDelete(initialConfig.id)}
              className="px-4 py-2 border border-red-300 text-red-600 rounded-lg hover:bg-red-50"
            >
              Delete Chart
            </button>
          )}
          <button
            onClick={handleSaveChart}
            disabled={isLoading}
            className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50"
          >
            Save Chart
          </button>
        </div>
      </div>
    </div>
  );
};

export default CustomChartBuilder;