import React, { useState } from 'react';
import { Home, MessageSquare, Users, BookOpen, Calendar, Settings, CreditCard, Layers, MessageCircle, Ticket, ChevronDown, ChevronRight, Bot, Brain, BrainCircuit, Headphones, ChevronLeft, UserCog } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { authService } from '../services/authService';

const Sidebar = () => {
  const [isConversationsOpen, setIsConversationsOpen] = useState(true);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const isSubAccount = !!authService.getCurrentUser()?.subAccountId;

  const navItems = isSubAccount ? [
    { to: "/", icon: Home, label: "Dashboard" },
    {
      icon: MessageCircle,
      label: "Conversations",
      children: [
        { to: "/analytics-assistant", icon: BrainCircuit, label: "AI Analytics Assistant" },
        { to: "/conversations", icon: MessageSquare, label: "All Conversations" },
        { to: "/tickets", icon: Ticket, label: "Support Tickets" },
        { to: "/admin/live-chat", icon: Headphones, label: "Live Chat Dashboard" }
      ]
    },
    { to: "/crm", icon: Users, label: "CRM" },
    { to: "/knowledge-base", icon: BookOpen, label: "Knowledge Base" },
    { to: "/appointments", icon: Calendar, label: "Appointments" },
    { to: "/ai-training/chatbot", icon: Bot, label: "External AI Chat" },
    { to: "/wallet", icon: CreditCard, label: "AI Usage Wallet" },
    { to: "/profile", icon: UserCog, label: "Company Profile" }
  ] : [
    { to: "/", icon: Home, label: "Dashboard" },
    {
      icon: MessageCircle,
      label: "Conversations",
      children: [
        { to: "/analytics-assistant", icon: BrainCircuit, label: "AI Analytics Assistant" },
        { to: "/conversations", icon: MessageSquare, label: "All Conversations" },
        { to: "/tickets", icon: Ticket, label: "Support Tickets" },
        { to: "/admin/live-chat", icon: Headphones, label: "Live Chat Dashboard" }
      ]
    },
    { to: "/crm", icon: Users, label: "CRM" },
    { to: "/knowledge-base", icon: BookOpen, label: "Knowledge Base" },
    { to: "/appointments", icon: Calendar, label: "Appointments" },
    {
      to: "/ai-training",
      icon: Brain,
      label: "AI Training",
      children: [
        { to: "/ai-training/chatbot", icon: Bot, label: "External AI Chat" },
        { to: "/ai-training/settings", icon: Settings, label: "Training Settings" }
      ]
    },
    { to: "/wallet", icon: CreditCard, label: "AI Usage Wallet" },
    { to: "/sub-accounts", icon: Layers, label: "Sub-Accounts" },
    { to: "/admin/settings", icon: Settings, label: "Admin Settings" }
  ];

  return (
    <aside className={`relative bg-indigo-700 text-white transition-all duration-300 ease-in-out ${
      isCollapsed ? 'w-16' : 'w-64'
    } min-h-screen`}>
      {/* Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-6 bg-indigo-700 text-white rounded-full p-1 shadow-lg z-50"
      >
        <ChevronLeft className={`h-4 w-4 transition-transform duration-300 ${
          isCollapsed ? 'rotate-180' : ''
        }`} />
      </button>

      <nav className="p-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.label}>
              {item.children ? (
                <div className="space-y-2">
                  <button
                    onClick={() => setIsConversationsOpen(!isConversationsOpen)}
                    className={`w-full flex items-center justify-between p-2 rounded-lg hover:bg-indigo-600 transition-colors ${
                      isCollapsed ? 'justify-center' : ''
                    }`}
                  >
                    <div className="flex items-center">
                      <item.icon className="h-5 w-5" />
                      {!isCollapsed && <span className="ml-2">{item.label}</span>}
                    </div>
                    {!isCollapsed && (
                      isConversationsOpen ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )
                    )}
                  </button>
                  {isConversationsOpen && !isCollapsed && (
                    <ul className="pl-4 space-y-2">
                      {item.children.map((child) => (
                        <li key={child.to}>
                          <NavLink
                            to={child.to}
                            className={({ isActive }) =>
                              `flex items-center space-x-2 p-2 rounded-lg hover:bg-indigo-600 ${
                                isActive ? 'bg-indigo-800' : ''
                              }`
                            }
                          >
                            <child.icon className="h-5 w-5" />
                            <span>{child.label}</span>
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    `flex items-center p-2 rounded-lg hover:bg-indigo-600 ${
                      isActive ? 'bg-indigo-800' : ''
                    } ${isCollapsed ? 'justify-center' : 'space-x-2'}`
                  }
                >
                  <item.icon className="h-5 w-5" />
                  {!isCollapsed && <span>{item.label}</span>}
                </NavLink>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;