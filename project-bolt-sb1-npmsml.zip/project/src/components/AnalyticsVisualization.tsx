import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  ChartData,
  ChartOptions
} from 'chart.js';
import { Chart } from 'react-chartjs-2';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

interface AnalyticsVisualizationProps {
  config: {
    type: 'line' | 'bar' | 'pie';
    data: ChartData<'line' | 'bar' | 'pie'>;
    options?: ChartOptions;
  };
  className?: string;
}

const AnalyticsVisualization: React.FC<AnalyticsVisualizationProps> = ({ config, className }) => {
  if (!config) return null;

  const defaultOptions: ChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: {
            size: 12
          }
        }
      }
    }
  };

  const chartOptions = {
    ...defaultOptions,
    ...config.options
  };

  return (
    <div className={className}>
      <Chart
        type={config.type}
        data={config.data}
        options={chartOptions}
      />
    </div>
  );
};

export default AnalyticsVisualization;