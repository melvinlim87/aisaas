import React, { useState } from 'react';
import { MessageSquare, Users, BookOpen, Calendar, Bell, Settings, BrainCircuit, X, Bot, Brain, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';
import DualChatInterface from './DualChatInterface';
import { authService } from '../services/authService';
import toast from 'react-hot-toast';

const Header = () => {
  const [showAnalyticsAI, setShowAnalyticsAI] = useState(false);
  const navigate = useNavigate();

  const navItems = [
    { icon: BrainCircuit, label: 'AI Analytics Assistant', onClick: () => setShowAnalyticsAI(true) },
    { icon: MessageSquare, label: 'Conversations', to: '/conversations' },
    { icon: Users, label: 'CRM', to: '/crm' },
    { icon: BookOpen, label: 'Knowledge Base', to: '/knowledge-base' },
    { icon: Calendar, label: 'Appointments', to: '/appointments' },
    { icon: Bell, label: 'Notifications', onClick: () => {} },
    { icon: Settings, label: 'Admin Settings', to: '/admin/settings' }
  ];

  const handleLogout = async () => {
    try {
      await authService.logout();
      toast.success('Logged out successfully');
      navigate('/login');
    } catch (error) {
      toast.error('Failed to logout');
    }
  };

  return (
    <>
      <header className="bg-secondary border-b border-border transition-colors duration-200">
        <div className="max-w-[1920px] mx-auto">
          <div className="flex justify-between items-center h-16 px-4 md:px-6">
            {/* Logo and Title */}
            <div className="flex items-center">
              <div className="flex items-center space-x-3">
                <div className="bg-indigo-600 rounded-lg p-2">
                  <MessageSquare className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold text-primary hidden md:block">AI Chatbot CRM</span>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center">
              <nav>
                <ul className="flex items-center space-x-1 md:space-x-2">
                  {navItems.map((item, index) => (
                    <li key={index} className="relative group">
                      {item.to ? (
                        <Link
                          to={item.to}
                          className="flex items-center justify-center w-10 h-10 rounded-full text-secondary hover:bg-hover transition-colors duration-150"
                        >
                          <item.icon className="h-5 w-5" />
                          <span className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-secondary text-primary text-xs py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 whitespace-nowrap transition-all duration-150 pointer-events-none shadow-lg z-50">
                            {item.label}
                          </span>
                        </Link>
                      ) : (
                        <button
                          onClick={item.onClick}
                          className="flex items-center justify-center w-10 h-10 rounded-full text-secondary hover:bg-hover transition-colors duration-150"
                        >
                          <item.icon className="h-5 w-5" />
                          <span className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-secondary text-primary text-xs py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 whitespace-nowrap transition-all duration-150 pointer-events-none shadow-lg z-50">
                            {item.label}
                          </span>
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              </nav>

              {/* Theme Toggle and Logout */}
              <div className="pl-2 ml-2 md:pl-4 md:ml-4 border-l border-border flex items-center space-x-2">
                <ThemeToggle />
                <button
                  onClick={handleLogout}
                  className="flex items-center justify-center w-10 h-10 rounded-full text-secondary hover:bg-hover transition-colors duration-150 group relative"
                >
                  <LogOut className="h-5 w-5" />
                  <span className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 bg-secondary text-primary text-xs py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 whitespace-nowrap transition-all duration-150 pointer-events-none shadow-lg z-50">
                    Logout
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* AI Analytics Assistant Modal */}
      {showAnalyticsAI && (
        <>
          {/* Overlay */}
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30" 
            onClick={() => setShowAnalyticsAI(false)} 
          />
          
          {/* Popup Container */}
          <div className="fixed inset-4 md:inset-auto md:right-4 md:bottom-4 md:top-auto md:left-auto md:w-[600px] md:h-[600px] bg-white rounded-lg shadow-xl z-40 flex flex-col overflow-hidden">
            {/* Popup Header */}
            <div className="flex-none px-4 py-3 border-b border-gray-200 flex justify-between items-center bg-white">
              <h3 className="font-semibold">Analytics Assistant</h3>
              <button
                onClick={() => setShowAnalyticsAI(false)}
                className="text-gray-500 hover:text-gray-700 transition-colors p-1 rounded-lg hover:bg-gray-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Chat Interface Container */}
            <div className="flex-1 overflow-hidden">
              <DualChatInterface />
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default Header;