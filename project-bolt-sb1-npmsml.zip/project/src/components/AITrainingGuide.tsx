import React from 'react';
import { Book, Upload, Link as LinkIcon, Brain, Bot, FileText, CheckCircle, Command, MessageSquare, Code } from 'lucide-react';

const AITrainingGuide: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-4xl h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center">
            <Book className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-xl font-semibold">AI Training Guide</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="prose max-w-none space-y-8">
            {/* Introduction */}
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg">
              <h3 className="text-xl font-semibold text-indigo-900 mb-4 flex items-center">
                <Bot className="h-6 w-6 mr-2" />
                Getting Started with AI Training
              </h3>
              <p className="text-indigo-800">
                Train your AI assistant to better understand your business, products, and services. The more relevant information you provide, the better it can assist your customers.
              </p>
            </div>

            {/* System Prompts */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <Command className="h-5 w-5 mr-2 text-indigo-600" />
                System Prompts & Commands
              </h3>
              <div className="space-y-4">
                <p>Create effective system prompts to guide AI behavior:</p>
                
                <div className="bg-gray-900 text-gray-100 p-4 rounded-lg font-mono text-sm">
                  <p className="text-green-400 mb-2">// Example System Prompt Structure</p>
                  <pre>{`You are an AI assistant for [Company Name]. Your role is to:

1. Primary Responsibilities:
   - Handle customer inquiries about our products/services
   - Provide accurate pricing information
   - Assist with technical support
   - Guide users through our processes

2. Response Guidelines:
   - Always be professional and courteous
   - Provide specific, accurate information
   - Use clear, concise language
   - Include relevant examples

3. Knowledge Areas:
   - [List specific products/services]
   - [Pricing tiers and features]
   - [Common procedures and policies]
   - [Technical specifications]

4. Response Format:
   - Start with a clear introduction
   - Break down complex information
   - Use bullet points for lists
   - End with next steps or call to action

5. Restrictions:
   - Never share sensitive information
   - Don't make promises about future features
   - Refer complex issues to human support
   - Stay within defined scope`}</pre>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg mt-4">
                  <h4 className="font-medium mb-2">Prompt Writing Tips:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Be specific about the AI's role and limitations</li>
                    <li>Define clear response structures</li>
                    <li>Include example dialogues</li>
                    <li>Specify tone and style requirements</li>
                    <li>List prohibited actions or topics</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* File Training */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <Upload className="h-5 w-5 mr-2 text-indigo-600" />
                Training with Files
              </h3>
              <div className="space-y-4">
                <p>Upload documents to train your AI with specific information:</p>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">File Preparation Guidelines:</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm">
                    <li>
                      <strong>Document Structure:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Use clear headings and subheadings</li>
                        <li>Include a table of contents for large documents</li>
                        <li>Group related information together</li>
                        <li>Use consistent formatting</li>
                      </ul>
                    </li>
                    <li>
                      <strong>Content Organization:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Start with key concepts</li>
                        <li>Include real-world examples</li>
                        <li>Add FAQ sections</li>
                        <li>Provide step-by-step guides</li>
                      </ul>
                    </li>
                    <li>
                      <strong>File Types & Formats:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>PDF: Best for formatted documents</li>
                        <li>TXT: Clean, plain text content</li>
                        <li>DOCX: Rich text documents</li>
                        <li>MD: Markdown formatted content</li>
                      </ul>
                    </li>
                  </ul>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
                  <h4 className="font-medium mb-2 text-yellow-800">Pro Tips:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-yellow-700">
                    <li>Split large documents into smaller, focused files</li>
                    <li>Include common customer queries and their answers</li>
                    <li>Update training files regularly as information changes</li>
                    <li>Test AI responses after uploading new content</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* URL Training */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <LinkIcon className="h-5 w-5 mr-2 text-indigo-600" />
                Training with URLs
              </h3>
              <div className="space-y-4">
                <p>Train your AI using content from web pages:</p>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">URL Selection Strategy:</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm">
                    <li>
                      <strong>Priority Pages:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Product/service description pages</li>
                        <li>Technical documentation</li>
                        <li>FAQ and help center pages</li>
                        <li>Pricing and feature comparison pages</li>
                      </ul>
                    </li>
                    <li>
                      <strong>Content Quality:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Ensure content is up-to-date</li>
                        <li>Check for accurate information</li>
                        <li>Verify page accessibility</li>
                        <li>Confirm content relevance</li>
                      </ul>
                    </li>
                    <li>
                      <strong>URL Structure:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Use direct links to specific pages</li>
                        <li>Avoid dynamic or temporary URLs</li>
                        <li>Include base knowledge pages</li>
                        <li>Link to stable content sources</li>
                      </ul>
                    </li>
                  </ul>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-400">
                  <h4 className="font-medium mb-2 text-blue-800">Advanced Tips:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-blue-700">
                    <li>Create a sitemap of important pages to train</li>
                    <li>Prioritize pages with high customer value</li>
                    <li>Monitor and update trained URLs periodically</li>
                    <li>Test AI knowledge after training new URLs</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Training Process */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <Brain className="h-5 w-5 mr-2 text-indigo-600" />
                Training Process
              </h3>
              <div className="space-y-4">
                <ol className="list-decimal pl-5 space-y-4">
                  <li>
                    <strong>Prepare Your Content</strong>
                    <p className="text-sm text-gray-600 mt-1">
                      Organize your training materials and ensure they contain accurate, up-to-date information.
                    </p>
                  </li>
                  <li>
                    <strong>Upload or Link Content</strong>
                    <p className="text-sm text-gray-600 mt-1">
                      Use either the file upload or URL training feature to provide content to your AI.
                    </p>
                  </li>
                  <li>
                    <strong>Monitor Training Progress</strong>
                    <p className="text-sm text-gray-600 mt-1">
                      Track the training progress and review logs for any issues.
                    </p>
                  </li>
                  <li>
                    <strong>Test and Verify</strong>
                    <p className="text-sm text-gray-600 mt-1">
                      Use the chat interface to test the AI's understanding of the new information.
                    </p>
                  </li>
                </ol>
              </div>
            </div>

            {/* Testing & Verification */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <MessageSquare className="h-5 w-5 mr-2 text-indigo-600" />
                Testing & Verification
              </h3>
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Test Scenarios:</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm">
                    <li>
                      <strong>Basic Queries:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Product information requests</li>
                        <li>Pricing questions</li>
                        <li>Feature comparisons</li>
                        <li>Common support issues</li>
                      </ul>
                    </li>
                    <li>
                      <strong>Complex Scenarios:</strong>
                      <ul className="list-disc pl-5 mt-1">
                        <li>Multi-step processes</li>
                        <li>Technical troubleshooting</li>
                        <li>Integration questions</li>
                        <li>Edge cases</li>
                      </ul>
                    </li>
                  </ul>
                </div>

                <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-400">
                  <h4 className="font-medium mb-2 text-green-800">Verification Checklist:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-green-700">
                    <li>Verify accuracy of responses</li>
                    <li>Check consistency across similar queries</li>
                    <li>Test response format compliance</li>
                    <li>Validate proper handling of edge cases</li>
                    <li>Ensure appropriate tone and style</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Best Practices */}
            <div className="bg-white shadow-lg rounded-lg p-6 border border-gray-100">
              <h3 className="text-lg font-semibold flex items-center mb-4">
                <CheckCircle className="h-5 w-5 mr-2 text-indigo-600" />
                Best Practices
              </h3>
              <div className="space-y-4">
                <ul className="list-disc pl-5 space-y-2">
                  <li>Regularly update training materials to keep information current</li>
                  <li>Use a combination of file and URL training for comprehensive coverage</li>
                  <li>Monitor AI responses and retrain as needed</li>
                  <li>Keep training content focused and relevant to your business</li>
                  <li>Test the AI with common customer queries after training</li>
                  <li>Document training history and content updates</li>
                  <li>Maintain a consistent voice across all training materials</li>
                  <li>Review and update system prompts periodically</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end p-6 border-t">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

export default AITrainingGuide;