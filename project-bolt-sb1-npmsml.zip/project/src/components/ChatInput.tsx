import React, { useState, useRef } from 'react';
import { Send, Image as ImageIcon, Loader } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (content: string, imageBase64: string | null) => Promise<void>;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [input, setInput] = useState('');
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = async () => {
    if (input.trim() || imageBase64) {
      await onSendMessage(input.trim(), imageBase64);
      setInput('');
      setImageBase64(null);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageBase64(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex items-center bg-white rounded-lg shadow-md p-2">
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type your message..."
        className="flex-1 p-2 focus:outline-none"
        onKeyPress={handleKeyPress}
        disabled={isLoading}
      />
      
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
      
      <button
        onClick={() => fileInputRef.current?.click()}
        className="p-2 text-gray-500 hover:text-gray-700 focus:outline-none"
        disabled={isLoading}
      >
        <ImageIcon className="h-5 w-5" />
      </button>
      
      <button
        onClick={handleSend}
        className="bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed ml-2"
        disabled={isLoading || (!input.trim() && !imageBase64)}
      >
        {isLoading ? (
          <Loader className="h-5 w-5 animate-spin" />
        ) : (
          <Send className="h-5 w-5" />
        )}
      </button>
    </div>
  );
};

export default ChatInput;