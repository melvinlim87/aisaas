import React, { useState, useRef, useEffect, useCallback } from 'react';
import { MessageSquare, Send, Bot, HelpCircle, Loader } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { internalAIService } from '../services/internalAI';
import { useChatStore } from '../store/chatStore';
import AnalyticsVisualization from './AnalyticsVisualization';
import toast from 'react-hot-toast';
import { Message } from '../types/chat';
import { walletService } from '../services/walletService';

interface DualChatInterfaceProps {
  initialQuery?: string;
}

const DualChatInterface: React.FC<DualChatInterfaceProps> = ({ initialQuery = '' }) => {
  const { messages, addMessage } = useChatStore();
  const [input, setInput] = useState(initialQuery);
  const [isLoading, setIsLoading] = useState(false);
  const [currentChartIndex, setCurrentChartIndex] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const initialQueryProcessed = useRef(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const initialMessageSent = useRef(false);

  useEffect(() => {
    if (messages.length === 0 && !initialMessageSent.current) {
      initialMessageSent.current = true;
      addMessage({
        id: Date.now().toString(),
        content: "Hello! I'm your AI analytics assistant. Ask me about metrics, trends, or insights from your data.",
        role: 'assistant',
        timestamp: new Date(),
        metadata: {
          source: 'internal'
        }
      });
    }
  }, [messages.length, addMessage]);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    if (initialQuery && !initialQueryProcessed.current) {
      initialQueryProcessed.current = true;
      handleSend(initialQuery);
    }
  }, [initialQuery]);

  const handleSend = async (query: string = input) => {
    if (!query.trim() || isLoading) return;

    const userMessage = {
      id: Date.now().toString(),
      content: query,
      role: 'user' as const,
      timestamp: new Date(),
      metadata: {
        source: 'internal' as const
      }
    };

    addMessage(userMessage);
    setInput('');
    setIsLoading(true);

    try {
      const response = await internalAIService.processQuery(query);
      
      await walletService.addTransaction({
        type: 'debit',
        amount: 0.01,
        description: 'Internal AI Analytics Usage',
        status: 'completed',
        metadata: {
          aiModel: 'GPT-4',
          promptTokens: query.length,
          completionTokens: response.content.length
        }
      });

      addMessage(response);
    } catch (error) {
      console.error('Error processing query:', error);
      toast.error('Failed to process your request');
      
      addMessage({
        id: Date.now().toString(),
        content: 'Sorry, I encountered an error while processing your request. Please try again.',
        role: 'system',
        timestamp: new Date(),
        metadata: {
          source: 'internal',
          error: true
        }
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-2"
      >
        {messages.map((message) => (
          <div
            key={`${message.id}-${message.timestamp.getTime()}`}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} mb-2`}
          >
            <div
              className={`max-w-[85%] rounded-lg p-2 ${
                message.role === 'user'
                  ? 'bg-indigo-600 text-white'
                  : message.metadata?.error
                  ? 'bg-red-50 text-red-700'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <div className="flex items-center mb-1">
                <MessageSquare className="h-4 w-4 mr-1" />
                <span className="text-sm font-medium">
                  {message.role === 'assistant' ? 'AI Assistant' : 'You'}
                </span>
                <span className="text-xs ml-1 opacity-75">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <ReactMarkdown
                className={`prose ${message.role === 'user' ? 'prose-invert' : ''} max-w-none`}
                components={{
                  p: ({ children }) => <p className="mb-1">{children}</p>,
                  h1: ({ children }) => <h1 className="text-lg font-bold mb-1">{children}</h1>,
                  h2: ({ children }) => <h2 className="text-base font-bold mb-1">{children}</h2>,
                  h3: ({ children }) => <h3 className="text-sm font-bold mb-1">{children}</h3>,
                  ul: ({ children }) => <ul className="list-none pl-4 mb-1">{children}</ul>,
                  ol: ({ children }) => <ol className="list-none pl-4 mb-1">{children}</ol>,
                  li: ({ children }) => <li className="mb-0.5">{children}</li>,
                }}
              >
                {message.content}
              </ReactMarkdown>

              {message.metadata?.analytics?.chartConfig && (
                <div className="mt-2 bg-gray-50 rounded-lg p-2">
                  <div className="h-[300px]">
                    <AnalyticsVisualization 
                      config={message.metadata.analytics.chartConfig[currentChartIndex]} 
                      className="w-full h-full" 
                    />
                  </div>
                  {message.metadata.analytics.chartConfig.length > 1 && (
                    <div className="mt-1 flex justify-center items-center space-x-2">
                      <button
                        onClick={() => setCurrentChartIndex((prev) => 
                          (prev - 1 + message.metadata!.analytics!.chartConfig.length) % message.metadata!.analytics!.chartConfig.length
                        )}
                        className="text-sm text-gray-600 hover:text-gray-900"
                      >
                        Previous
                      </button>
                      <span className="text-sm text-gray-600">
                        {currentChartIndex + 1} / {message.metadata.analytics.chartConfig.length}
                      </span>
                      <button
                        onClick={() => setCurrentChartIndex((prev) => 
                          (prev + 1) % message.metadata!.analytics!.chartConfig.length
                        )}
                        className="text-sm text-gray-600 hover:text-gray-900"
                      >
                        Next
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-2 border-t">
        <div className="flex items-center space-x-1">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about analytics, metrics, or performance..."
            className="flex-1 rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSend()}
            disabled={isLoading || !input.trim()}
            className="bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center"
          >
            {isLoading ? (
              <Loader className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DualChatInterface;