import React from 'react';
import { Draggable, DraggableProvided } from 'react-beautiful-dnd';
import { MoreVertical } from 'lucide-react';
import { Task } from '../../types/crm';

interface TaskCardProps {
  task: Task;
  index: number;
  showMenu: string | null;
  onMenuToggle: (taskId: string | null) => void;
}

const TaskCard = ({ task, index, showMenu, onMenuToggle }: TaskCardProps) => {
  const renderDraggable = (provided: DraggableProvided) => (
    <div
      ref={provided.innerRef}
      {...provided.draggableProps}
      {...provided.dragHandleProps}
      className="bg-white rounded-lg p-3 shadow-sm"
    >
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-medium text-gray-900">{task.title}</h4>
          <p className="text-sm text-gray-500 mt-1">{task.description}</p>
        </div>
        <div className="relative">
          <button
            onClick={() => onMenuToggle(showMenu === task.id ? null : task.id)}
            className="text-gray-400 hover:text-gray-600"
          >
            <MoreVertical className="h-4 w-4" />
          </button>
          {showMenu === task.id && (
            <div className="absolute right-0 mt-1 w-40 bg-white rounded-md shadow-lg z-10">
              <div className="py-1">
                <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Edit
                </button>
                <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Delete
                </button>
                <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                  Move to...
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <span className="text-xs text-gray-500">{task.assignee}</span>
        <span className={`text-xs px-2 py-1 rounded-full ${
          task.priority === 'high' ? 'bg-red-100 text-red-800' :
          task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
          'bg-green-100 text-green-800'
        }`}>
          {task.priority}
        </span>
      </div>
    </div>
  );

  return (
    <Draggable draggableId={task.id} index={index}>
      {renderDraggable}
    </Draggable>
  );
};

export default TaskCard;