import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';

interface TimelineEvent {
  id: string;
  title: string;
  type: 'meeting' | 'deadline' | 'task';
  startDate: Date;
  endDate?: Date;
  owner: string;
  status: 'planned' | 'in_progress' | 'completed';
}

const CalendarView = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState<TimelineEvent[]>([
    {
      id: '1',
      title: 'Client Meeting',
      type: 'meeting',
      startDate: new Date(2024, 1, 15, 10, 0),
      endDate: new Date(2024, 1, 15, 11, 0),
      owner: 'John Doe',
      status: 'planned'
    },
    {
      id: '2',
      title: 'Proposal Deadline',
      type: 'deadline',
      startDate: new Date(2024, 1, 20),
      owner: 'Jane Smith',
      status: 'in_progress'
    }
  ]);

  const daysInMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() + 1,
    0
  ).getDate();

  const firstDayOfMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    1
  ).getDay();

  const weeks = Math.ceil((daysInMonth + firstDayOfMonth) / 7);

  const getEventColor = (type: TimelineEvent['type']) => {
    switch (type) {
      case 'meeting':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'deadline':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'task':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: TimelineEvent['status']) => {
    switch (status) {
      case 'planned':
        return 'bg-yellow-100 text-yellow-800';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDayEvents = (date: Date) => {
    return events.filter(event => {
      const eventDate = new Date(event.startDate);
      return (
        eventDate.getDate() === date.getDate() &&
        eventDate.getMonth() === date.getMonth() &&
        eventDate.getFullYear() === date.getFullYear()
      );
    });
  };

  return (
    <div className="p-6">
      {/* Calendar Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h2 className="text-xl font-semibold">
            {currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
          </h2>
          <button
            onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          Add Event
        </button>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-lg shadow">
        {/* Weekday Headers */}
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-500">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {Array.from({ length: weeks * 7 }).map((_, index) => {
            const dayNumber = index - firstDayOfMonth + 1;
            const isCurrentMonth = dayNumber > 0 && dayNumber <= daysInMonth;
            const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), dayNumber);
            const dayEvents = isCurrentMonth ? getDayEvents(date) : [];

            return (
              <div
                key={index}
                className={`min-h-32 bg-white p-2 ${
                  isCurrentMonth ? 'text-gray-900' : 'text-gray-400 bg-gray-50'
                }`}
              >
                {isCurrentMonth && (
                  <>
                    <div className="font-medium">{dayNumber}</div>
                    <div className="space-y-1 mt-1">
                      {dayEvents.map(event => (
                        <div
                          key={event.id}
                          className={`p-1 rounded text-xs border ${getEventColor(event.type)}`}
                        >
                          <div className="font-medium">{event.title}</div>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-xs">
                              {event.startDate.toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                            <span className={`px-1.5 py-0.5 rounded-full text-xs ${getStatusColor(event.status)}`}>
                              {event.status.replace('_', ' ')}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CalendarView;