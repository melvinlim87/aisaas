import React, { useState } from 'react';
import { Draggable } from 'react-beautiful-dnd';
import { MoreVertical, Calendar, User, Tag } from 'lucide-react';
import { KanbanItem } from '../../types/crm';

interface KanbanCardProps {
  item: KanbanItem;
  index: number;
  columnId: string;
  onEdit: (item: KanbanItem, columnId: string) => void;
  onDelete: (itemId: string, columnId: string) => void;
}

const KanbanCard: React.FC<KanbanCardProps> = ({
  item,
  index,
  columnId,
  onEdit,
  onDelete
}) => {
  const [showMenu, setShowMenu] = useState(false);

  const getPriorityColor = (priority: KanbanItem['priority']) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <Draggable draggableId={item.id} index={index}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className="bg-white rounded-lg p-4 shadow-sm"
        >
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-medium text-gray-900">{item.title}</h4>
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <MoreVertical className="h-4 w-4 text-gray-500" />
              </button>
              {showMenu && (
                <div className="absolute right-0 mt-1 w-48 bg-white rounded-lg shadow-lg z-10 py-1">
                  <button 
                    onClick={() => {
                      onEdit(item, columnId);
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Edit Deal
                  </button>
                  <button 
                    onClick={() => {
                      onDelete(item.id, columnId);
                      setShowMenu(false);
                    }}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100"
                  >
                    Delete Deal
                  </button>
                </div>
              )}
            </div>
          </div>
          <p className="text-sm text-gray-600 mb-3">{item.description}</p>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg font-semibold text-gray-900">
              {formatCurrency(item.value)}
            </span>
            <span className={`text-xs px-2 py-1 rounded-full ${getPriorityColor(item.priority)}`}>
              {item.priority}
            </span>
          </div>
          <div className="flex flex-wrap gap-1 mb-3">
            {item.tags.map((tag, i) => (
              <span
                key={i}
                className="inline-flex items-center px-2 py-1 rounded-md bg-gray-100 text-xs text-gray-600"
              >
                <Tag className="h-3 w-3 mr-1" />
                {tag}
              </span>
            ))}
          </div>
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center">
              <User className="h-4 w-4 mr-1" />
              {item.assignee}
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              {new Date(item.dueDate).toLocaleDateString()}
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
};

export default KanbanCard;