import React, { useState } from 'react';
import { X, Plus, Save, Trash2, Settings2, ArrowRight } from 'lucide-react';

interface WorkflowAutomationProps {
  onClose: () => void;
}

interface Workflow {
  id: string;
  name: string;
  trigger: string;
  conditions: string[];
  actions: string[];
  enabled: boolean;
}

const WorkflowAutomation: React.FC<WorkflowAutomationProps> = ({ onClose }) => {
  const [workflows, setWorkflows] = useState<Workflow[]>([
    {
      id: '1',
      name: 'New Lead Assignment',
      trigger: 'New Lead Created',
      conditions: ['Lead Source = Website'],
      actions: ['Assign to Sales Team', 'Send Welcome Email'],
      enabled: true
    },
    {
      id: '2',
      name: 'Deal Stage Update',
      trigger: 'Deal Stage Changed',
      conditions: ['New Stage = Won'],
      actions: ['Create Invoice', 'Send Customer Welcome Kit'],
      enabled: true
    }
  ]);

  const [newWorkflow, setNewWorkflow] = useState<Partial<Workflow>>({
    name: '',
    trigger: '',
    conditions: [],
    actions: [],
    enabled: true
  });

  const [showNewWorkflow, setShowNewWorkflow] = useState(false);

  const triggers = [
    'New Lead Created',
    'Deal Stage Changed',
    'Task Completed',
    'Email Opened',
    'Form Submitted'
  ];

  const availableActions = [
    'Send Email',
    'Create Task',
    'Update Field',
    'Send Notification',
    'Create Calendar Event'
  ];

  const handleSaveWorkflow = () => {
    if (newWorkflow.name && newWorkflow.trigger) {
      setWorkflows([
        ...workflows,
        {
          id: Date.now().toString(),
          name: newWorkflow.name,
          trigger: newWorkflow.trigger,
          conditions: newWorkflow.conditions || [],
          actions: newWorkflow.actions || [],
          enabled: true
        }
      ]);
      setShowNewWorkflow(false);
      setNewWorkflow({
        name: '',
        trigger: '',
        conditions: [],
        actions: [],
        enabled: true
      });
    }
  };

  const handleDeleteWorkflow = (id: string) => {
    setWorkflows(workflows.filter(w => w.id !== id));
  };

  const handleToggleWorkflow = (id: string) => {
    setWorkflows(workflows.map(w =>
      w.id === id ? { ...w, enabled: !w.enabled } : w
    ));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-4xl h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-semibold">Workflow Automation</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="mb-6 flex justify-between items-center">
            <p className="text-gray-600">
              Automate your CRM processes with custom workflows
            </p>
            <button
              onClick={() => setShowNewWorkflow(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              New Workflow
            </button>
          </div>

          {/* Workflow List */}
          <div className="space-y-4">
            {workflows.map((workflow) => (
              <div
                key={workflow.id}
                className="bg-gray-50 rounded-lg p-4 border border-gray-200"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-lg">{workflow.name}</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <span className="font-medium mr-2">Trigger:</span>
                        {workflow.trigger}
                      </div>
                      {workflow.conditions.length > 0 && (
                        <div className="flex items-start text-sm text-gray-600">
                          <span className="font-medium mr-2">Conditions:</span>
                          <ul className="list-disc list-inside">
                            {workflow.conditions.map((condition, index) => (
                              <li key={index}>{condition}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      <div className="flex items-start text-sm text-gray-600">
                        <span className="font-medium mr-2">Actions:</span>
                        <ul className="list-disc list-inside">
                          {workflow.actions.map((action, index) => (
                            <li key={index}>{action}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleToggleWorkflow(workflow.id)}
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        workflow.enabled
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {workflow.enabled ? 'Enabled' : 'Disabled'}
                    </button>
                    <button
                      onClick={() => handleDeleteWorkflow(workflow.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* New Workflow Modal */}
        {showNewWorkflow && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div className="bg-white rounded-lg w-full max-w-2xl p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold">Create New Workflow</h3>
                <button
                  onClick={() => setShowNewWorkflow(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Workflow Name
                  </label>
                  <input
                    type="text"
                    value={newWorkflow.name || ''}
                    onChange={(e) => setNewWorkflow({ ...newWorkflow, name: e.target.value })}
                    className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter workflow name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Trigger
                  </label>
                  <select
                    value={newWorkflow.trigger || ''}
                    onChange={(e) => setNewWorkflow({ ...newWorkflow, trigger: e.target.value })}
                    className="w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    <option value="">Select a trigger</option>
                    {triggers.map((trigger) => (
                      <option key={trigger} value={trigger}>
                        {trigger}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Actions
                  </label>
                  <div className="space-y-2">
                    {availableActions.map((action) => (
                      <label key={action} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={newWorkflow.actions?.includes(action) || false}
                          onChange={(e) => {
                            const actions = newWorkflow.actions || [];
                            setNewWorkflow({
                              ...newWorkflow,
                              actions: e.target.checked
                                ? [...actions, action]
                                : actions.filter(a => a !== action)
                            });
                          }}
                          className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">{action}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-2 mt-6">
                  <button
                    onClick={() => setShowNewWorkflow(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveWorkflow}
                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center"
                  >
                    <Save className="h-5 w-5 mr-2" />
                    Save Workflow
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WorkflowAutomation;