import React from 'react';
import { BarChart as BarChartIcon, PieChart, TrendingUp, DollarSign } from 'lucide-react';
import { Line, Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const ChartView: React.FC = () => {
  // Sample data for demonstration
  const revenueData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [{
      label: 'Revenue',
      data: [65000, 75000, 85000, 95000, 110000, 125000],
      borderColor: 'rgb(99, 102, 241)',
      backgroundColor: 'rgba(99, 102, 241, 0.1)',
      fill: true,
      tension: 0.4
    }]
  };

  const dealsByStatusData = {
    labels: ['New', 'In Progress', 'Negotiation', 'Closed Won', 'Closed Lost'],
    datasets: [{
      data: [15, 25, 20, 30, 10],
      backgroundColor: [
        'rgba(99, 102, 241, 0.8)',
        'rgba(59, 130, 246, 0.8)',
        'rgba(16, 185, 129, 0.8)',
        'rgba(245, 158, 11, 0.8)',
        'rgba(239, 68, 68, 0.8)'
      ]
    }]
  };

  const dealsByValueData = {
    labels: ['Q1', 'Q2', 'Q3', 'Q4'],
    datasets: [{
      label: 'Deal Value',
      data: [250000, 320000, 280000, 390000],
      backgroundColor: 'rgba(99, 102, 241, 0.8)'
    }]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const
      }
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center mb-4">
            <TrendingUp className="h-5 w-5 text-indigo-600 mr-2" />
            <h3 className="font-semibold">Revenue Trend</h3>
          </div>
          <div className="h-[300px]">
            <Line data={revenueData} options={chartOptions} />
          </div>
        </div>

        {/* Deals by Status */}
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center mb-4">
            <PieChart className="h-5 w-5 text-indigo-600 mr-2" />
            <h3 className="font-semibold">Deals by Status</h3>
          </div>
          <div className="h-[300px]">
            <Pie data={dealsByStatusData} options={chartOptions} />
          </div>
        </div>

        {/* Deals by Value */}
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center mb-4">
            <BarChartIcon className="h-5 w-5 text-indigo-600 mr-2" />
            <h3 className="font-semibold">Deals by Value</h3>
          </div>
          <div className="h-[300px]">
            <Bar data={dealsByValueData} options={chartOptions} />
          </div>
        </div>

        {/* Key Metrics */}
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center mb-4">
            <DollarSign className="h-5 w-5 text-indigo-600 mr-2" />
            <h3 className="font-semibold">Key Metrics</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-indigo-600">$1.24M</p>
              <p className="text-xs text-green-600">↑ 12% from last month</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Average Deal Size</p>
              <p className="text-2xl font-bold text-indigo-600">$85K</p>
              <p className="text-xs text-green-600">↑ 5% from last month</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Win Rate</p>
              <p className="text-2xl font-bold text-indigo-600">68%</p>
              <p className="text-xs text-green-600">↑ 3% from last month</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Active Deals</p>
              <p className="text-2xl font-bold text-indigo-600">42</p>
              <p className="text-xs text-red-600">↓ 2% from last month</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChartView;