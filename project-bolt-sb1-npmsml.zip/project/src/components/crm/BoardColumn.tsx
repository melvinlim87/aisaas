import React from 'react';
import { Droppable, Draggable } from 'react-beautiful-dnd';
import { Plus, MoreVertical } from 'lucide-react';
import { KanbanItem } from '../../types/crm';

interface BoardColumnProps {
  id: string;
  title: string;
  items: KanbanItem[];
  color?: string;
  onAddItem: () => void;
  onEditItem: (item: KanbanItem) => void;
}

const BoardColumn: React.FC<BoardColumnProps> = ({ 
  id, 
  title, 
  items = [], 
  color = 'bg-gray-100',
  onAddItem,
  onEditItem 
}) => {
  return (
    <div className="flex-shrink-0 w-80">
      <div className={`rounded-lg ${color} p-4`}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold text-gray-900">{title}</h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">{items.length}</span>
            <button
              onClick={onAddItem}
              className="p-1 hover:bg-gray-200 rounded-full"
            >
              <Plus className="h-5 w-5" />
            </button>
          </div>
        </div>

        <Droppable droppableId={id}>
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="space-y-2 min-h-[200px]"
            >
              {items.map((item, index) => (
                <Draggable key={item.id} draggableId={item.id} index={index}>
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className="bg-white rounded-lg shadow p-3"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                        </div>
                        <button
                          onClick={() => onEditItem(item)}
                          className="p-1 hover:bg-gray-100 rounded-full"
                        >
                          <MoreVertical className="h-4 w-4 text-gray-500" />
                        </button>
                      </div>

                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            item.priority === 'high' ? 'bg-red-100 text-red-800' :
                            item.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }`}>
                            {item.priority}
                          </span>
                          {item.tags.map((tag, i) => (
                            <span key={i} className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded-full">
                              {tag}
                            </span>
                          ))}
                        </div>
                        <span className="text-sm text-gray-500">${item.value}</span>
                      </div>

                      <div className="mt-2 flex items-center justify-between text-sm text-gray-500">
                        <span>{item.assignee}</span>
                        <span>{new Date(item.dueDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </div>
    </div>
  );
};

export default BoardColumn;