import React, { useState } from 'react';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import { Plus } from 'lucide-react';
import BoardColumn from './BoardColumn';
import { KanbanItem } from '../../types/crm';

const INITIAL_DATA = {
  columns: {
    'leads': {
      id: 'leads',
      title: 'Leads',
      items: [
        {
          id: '1',
          title: 'New Lead - ABC Corp',
          description: 'Initial contact from website form',
          priority: 'high',
          value: 50000,
          assignee: 'John Doe',
          dueDate: '2024-02-01',
          tags: ['Enterprise', 'Software']
        },
        {
          id: '2',
          title: 'Referral - XYZ Inc',
          description: 'Referred by existing client',
          priority: 'medium',
          value: 25000,
          assignee: 'Jane Smith',
          dueDate: '2024-02-15',
          tags: ['SMB', 'Hardware']
        }
      ]
    },
    'contacted': {
      id: 'contacted',
      title: 'Contacted',
      items: [
        {
          id: '3',
          title: 'Follow-up - Tech Solutions',
          description: 'Second meeting scheduled',
          priority: 'medium',
          value: 75000,
          assignee: 'Mike Johnson',
          dueDate: '2024-02-10',
          tags: ['Enterprise', 'Services']
        }
      ]
    },
    'qualified': {
      id: 'qualified',
      title: 'Qualified',
      items: [
        {
          id: '4',
          title: 'Proposal - Global Corp',
          description: 'Final proposal review',
          priority: 'high',
          value: 100000,
          assignee: 'Sarah Wilson',
          dueDate: '2024-02-20',
          tags: ['Enterprise', 'Consulting']
        }
      ]
    },
    'proposal': {
      id: 'proposal',
      title: 'Proposal',
      items: []
    },
    'negotiation': {
      id: 'negotiation',
      title: 'Negotiation',
      items: []
    },
    'closed': {
      id: 'closed',
      title: 'Closed',
      items: []
    }
  },
  columnOrder: ['leads', 'contacted', 'qualified', 'proposal', 'negotiation', 'closed']
};

const BoardView: React.FC = () => {
  const [data, setData] = useState(INITIAL_DATA);
  const [showNewItemModal, setShowNewItemModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<KanbanItem | null>(null);

  const onDragEnd = (result: DropResult) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;

    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) {
      return;
    }

    const sourceColumn = data.columns[source.droppableId];
    const destColumn = data.columns[destination.droppableId];
    const draggedItem = sourceColumn.items.find(item => item.id === draggableId);

    if (!draggedItem) return;

    // Create new array for source items
    const newSourceItems = [...sourceColumn.items];
    newSourceItems.splice(source.index, 1);

    // Create new array for destination items
    const newDestItems = [...destColumn.items];
    newDestItems.splice(destination.index, 0, draggedItem);

    // Update state with new data
    const newData = {
      ...data,
      columns: {
        ...data.columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: newSourceItems
        },
        [destination.droppableId]: {
          ...destColumn,
          items: newDestItems
        }
      }
    };

    setData(newData);
  };

  const handleAddItem = (columnId: string) => {
    setSelectedItem(null);
    setShowNewItemModal(true);
  };

  const handleEditItem = (item: KanbanItem) => {
    setSelectedItem(item);
    setShowNewItemModal(true);
  };

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex space-x-4 overflow-x-auto p-4">
        {data.columnOrder.map(columnId => {
          const column = data.columns[columnId];
          return (
            <BoardColumn
              key={column.id}
              id={column.id}
              title={column.title}
              items={column.items}
              onAddItem={() => handleAddItem(column.id)}
              onEditItem={handleEditItem}
            />
          );
        })}
      </div>
    </DragDropContext>
  );
};

export default BoardView;