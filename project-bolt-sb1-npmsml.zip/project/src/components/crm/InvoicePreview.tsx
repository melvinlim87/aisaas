import React from 'react';
import { X, Download, Printer, Send } from 'lucide-react';
import { Invoice } from '../../types/crm';
import toast from 'react-hot-toast';

interface InvoicePreviewProps {
  invoice: Invoice;
  onClose: () => void;
}

const InvoicePreview: React.FC<InvoicePreviewProps> = ({ invoice, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    toast.success('Invoice downloaded successfully');
  };

  const handleSend = () => {
    toast.success('Invoice sent successfully');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-3xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-lg font-semibold">Invoice Preview</h2>
          <div className="flex items-center space-x-1">
            <button
              onClick={handlePrint}
              className="p-1.5 hover:bg-gray-100 rounded-lg"
              title="Print"
            >
              <Printer className="h-4 w-4" />
            </button>
            <button
              onClick={handleDownload}
              className="p-1.5 hover:bg-gray-100 rounded-lg"
              title="Download"
            >
              <Download className="h-4 w-4" />
            </button>
            <button
              onClick={handleSend}
              className="p-1.5 hover:bg-gray-100 rounded-lg"
              title="Send"
            >
              <Send className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-gray-100 rounded-lg"
              title="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Invoice Content - Scrollable */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="max-w-2xl mx-auto">
            {/* Company Info */}
            <div className="flex justify-between mb-6">
              <div>
                <h1 className="text-xl font-bold text-gray-900">INVOICE</h1>
                <p className="text-gray-600 mt-1">{invoice.number}</p>
              </div>
              <div className="text-right">
                <h2 className="text-lg font-semibold">Your Company Name</h2>
                <p className="text-sm text-gray-600">123 Business Street</p>
                <p className="text-sm text-gray-600">City, State 12345</p>
                <p className="text-sm text-gray-600">contact@company.com</p>
              </div>
            </div>

            {/* Dates */}
            <div className="flex justify-between mb-6">
              <div>
                <h3 className="text-sm text-gray-600">Date Issued</h3>
                <p className="font-medium">{new Date(invoice.date).toLocaleDateString()}</p>
              </div>
              <div className="text-right">
                <h3 className="text-sm text-gray-600">Due Date</h3>
                <p className="font-medium">{new Date(invoice.dueDate).toLocaleDateString()}</p>
              </div>
            </div>

            {/* Items Table */}
            <div className="overflow-x-auto">
              <table className="w-full mb-6">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 text-sm">Description</th>
                    <th className="text-right py-2 text-sm">Quantity</th>
                    <th className="text-right py-2 text-sm">Unit Price</th>
                    <th className="text-right py-2 text-sm">Tax</th>
                    <th className="text-right py-2 text-sm">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((item) => (
                    <tr key={item.id} className="border-b">
                      <td className="py-2 text-sm">{item.description}</td>
                      <td className="text-right py-2 text-sm">{item.quantity}</td>
                      <td className="text-right py-2 text-sm">${item.unitPrice.toFixed(2)}</td>
                      <td className="text-right py-2 text-sm">{item.tax}%</td>
                      <td className="text-right py-2 text-sm">${item.total.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Totals */}
            <div className="w-1/2 ml-auto">
              <div className="flex justify-between py-1 text-sm">
                <span className="font-medium">Subtotal</span>
                <span>${invoice.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1 text-sm">
                <span className="font-medium">Tax</span>
                <span>${invoice.tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between py-1 border-t border-gray-200 text-sm">
                <span className="font-bold">Total</span>
                <span className="font-bold">${invoice.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Notes & Terms */}
            <div className="mt-6 space-y-3">
              {invoice.notes && (
                <div>
                  <h4 className="text-sm font-medium mb-1">Notes</h4>
                  <p className="text-sm text-gray-600">{invoice.notes}</p>
                </div>
              )}
              {invoice.terms && (
                <div>
                  <h4 className="text-sm font-medium mb-1">Terms & Conditions</h4>
                  <p className="text-sm text-gray-600">{invoice.terms}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoicePreview;