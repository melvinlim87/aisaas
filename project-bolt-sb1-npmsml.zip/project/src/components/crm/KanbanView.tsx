import React, { useState } from 'react';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import { KanbanColumn as IKanbanColumn, KanbanItem } from '../../types/crm';
import KanbanColumn from './KanbanColumn';
import KanbanItemModal from './KanbanItemModal';
import toast from 'react-hot-toast';

const initialData: IKanbanColumn[] = [
  {
    id: 'leads',
    title: 'Leads',
    items: [
      {
        id: 'item-1',
        title: 'Acme Corp - Enterprise Deal',
        description: 'Enterprise software solution for logistics management',
        priority: 'high',
        assignee: 'John Doe',
        dueDate: '2024-02-15',
        value: 150000,
        tags: ['Enterprise', 'Software', 'Logistics']
      },
      {
        id: 'item-2',
        title: 'TechStart Inc - Cloud Migration',
        description: 'Full cloud infrastructure migration project',
        priority: 'medium',
        assignee: 'Jane Smith',
        dueDate: '2024-02-20',
        value: 75000,
        tags: ['Cloud', 'Migration', 'Infrastructure']
      }
    ]
  },
  {
    id: 'contacted',
    title: 'Contacted',
    items: [
      {
        id: 'item-3',
        title: 'Global Solutions Ltd - Security',
        description: 'Enterprise security implementation and training',
        priority: 'high',
        assignee: 'Mike Johnson',
        dueDate: '2024-02-18',
        value: 200000,
        tags: ['Security', 'Enterprise', 'Training']
      }
    ]
  },
  {
    id: 'qualified',
    title: 'Qualified',
    items: [
      {
        id: 'item-4',
        title: 'InnoTech Solutions - AI Integration',
        description: 'AI and ML integration for data analytics platform',
        priority: 'medium',
        assignee: 'Sarah Wilson',
        dueDate: '2024-02-25',
        value: 120000,
        tags: ['AI', 'ML', 'Analytics']
      }
    ]
  },
  {
    id: 'proposal',
    title: 'Proposal',
    items: [
      {
        id: 'item-5',
        title: 'DataCorp Analytics - Data Warehouse',
        description: 'Enterprise data warehouse implementation',
        priority: 'high',
        assignee: 'Tom Brown',
        dueDate: '2024-03-01',
        value: 300000,
        tags: ['Data', 'Enterprise', 'Analytics']
      }
    ]
  },
  {
    id: 'negotiation',
    title: 'Negotiation',
    items: [
      {
        id: 'item-6',
        title: 'MegaCorp - Digital Transformation',
        description: 'Complete digital transformation project',
        priority: 'high',
        assignee: 'Alice Johnson',
        dueDate: '2024-03-05',
        value: 500000,
        tags: ['Digital', 'Transformation', 'Enterprise']
      }
    ]
  },
  {
    id: 'closed',
    title: 'Closed Won',
    items: [
      {
        id: 'item-7',
        title: 'Tech Innovators - Platform Migration',
        description: 'Legacy system migration to modern platform',
        priority: 'high',
        assignee: 'David Lee',
        dueDate: '2024-02-10',
        value: 250000,
        tags: ['Migration', 'Platform', 'Enterprise']
      }
    ]
  }
];

const KanbanView: React.FC = () => {
  const [columns, setColumns] = useState<IKanbanColumn[]>(initialData);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<KanbanItem | null>(null);
  const [selectedColumn, setSelectedColumn] = useState<string | null>(null);

  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const { source, destination } = result;
    const newColumns = [...columns];
    const sourceColumn = newColumns.find(col => col.id === source.droppableId);
    const destColumn = newColumns.find(col => col.id === destination.droppableId);

    if (sourceColumn && destColumn) {
      const [movedItem] = sourceColumn.items.splice(source.index, 1);
      destColumn.items.splice(destination.index, 0, movedItem);
      setColumns(newColumns);
      toast.success(`Moved deal to ${destColumn.title}`);
    }
  };

  const handleAddItem = (columnId: string) => {
    setSelectedColumn(columnId);
    setEditingItem(null);
    setShowModal(true);
  };

  const handleEditItem = (item: KanbanItem, columnId: string) => {
    setSelectedColumn(columnId);
    setEditingItem(item);
    setShowModal(true);
  };

  const handleDeleteItem = (itemId: string, columnId: string) => {
    const newColumns = columns.map(col => {
      if (col.id === columnId) {
        return {
          ...col,
          items: col.items.filter(item => item.id !== itemId)
        };
      }
      return col;
    });
    setColumns(newColumns);
    toast.success('Deal deleted successfully');
  };

  const handleSaveItem = (item: Omit<KanbanItem, 'id'>) => {
    if (!selectedColumn) return;

    const newColumns = [...columns];
    const columnIndex = newColumns.findIndex(col => col.id === selectedColumn);

    if (columnIndex === -1) return;

    if (editingItem) {
      // Edit existing item
      const itemIndex = newColumns[columnIndex].items.findIndex(i => i.id === editingItem.id);
      if (itemIndex !== -1) {
        newColumns[columnIndex].items[itemIndex] = {
          ...item,
          id: editingItem.id
        };
      }
    } else {
      // Add new item
      newColumns[columnIndex].items.push({
        ...item,
        id: `item-${Date.now()}`
      });
    }

    setColumns(newColumns);
    setShowModal(false);
    setEditingItem(null);
    setSelectedColumn(null);
    toast.success(editingItem ? 'Deal updated successfully' : 'Deal added successfully');
  };

  return (
    <>
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="flex gap-4 overflow-x-auto p-4">
          {columns.map(column => (
            <KanbanColumn
              key={column.id}
              id={column.id}
              title={column.title}
              items={column.items}
              onAddItem={() => handleAddItem(column.id)}
              onEditItem={(item) => handleEditItem(item, column.id)}
              onDeleteItem={(itemId) => handleDeleteItem(itemId, column.id)}
            />
          ))}
        </div>
      </DragDropContext>

      <KanbanItemModal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingItem(null);
          setSelectedColumn(null);
        }}
        onSave={handleSaveItem}
        editingItem={editingItem || undefined}
      />
    </>
  );
};

export default KanbanView;