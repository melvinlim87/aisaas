import React, { useState } from 'react';
import { X, Save } from 'lucide-react';

interface CRMSettings {
  customFields: Array<{
    id: string;
    name: string;
    type: 'text' | 'number' | 'date' | 'select';
    options?: string[];
  }>;
  stages: string[];
  notifications: {
    email: boolean;
    desktop: boolean;
    slack: boolean;
  };
  automations: {
    enabled: boolean;
    reminderDays: number;
  };
}

interface CRMSettingsProps {
  onClose: () => void;
  onUpdateSettings: (settings: CRMSettings) => void;
}

const CRMSettings: React.FC<CRMSettingsProps> = ({ onClose, onUpdateSettings }) => {
  const [settings, setSettings] = useState<CRMSettings>({
    customFields: [
      { id: 'field1', name: 'Company Size', type: 'select', options: ['1-10', '11-50', '51-200', '201+'] },
      { id: 'field2', name: 'Industry', type: 'text' }
    ],
    stages: ['Lead', 'Contact Made', 'Proposal Sent', 'Negotiation', 'Closed Won', 'Closed Lost'],
    notifications: {
      email: true,
      desktop: true,
      slack: false
    },
    automations: {
      enabled: true,
      reminderDays: 7
    }
  });

  const handleSave = () => {
    onUpdateSettings(settings);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[80vh] overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">CRM Settings</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-4 space-y-6 overflow-y-auto max-h-[calc(80vh-8rem)]">
          {/* Custom Fields */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Custom Fields</h3>
            <div className="space-y-3">
              {settings.customFields.map((field, index) => (
                <div key={field.id} className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={field.name}
                    onChange={(e) => {
                      const newFields = [...settings.customFields];
                      newFields[index].name = e.target.value;
                      setSettings({ ...settings, customFields: newFields });
                    }}
                    className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                  />
                  <select
                    value={field.type}
                    onChange={(e) => {
                      const newFields = [...settings.customFields];
                      newFields[index].type = e.target.value as 'text' | 'number' | 'date' | 'select';
                      setSettings({ ...settings, customFields: newFields });
                    }}
                    className="w-24 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                  >
                    <option value="text">Text</option>
                    <option value="number">Number</option>
                    <option value="date">Date</option>
                    <option value="select">Select</option>
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Pipeline Stages */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Pipeline Stages</h3>
            <div className="space-y-2">
              {settings.stages.map((stage, index) => (
                <input
                  key={index}
                  type="text"
                  value={stage}
                  onChange={(e) => {
                    const newStages = [...settings.stages];
                    newStages[index] = e.target.value;
                    setSettings({ ...settings, stages: newStages });
                  }}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                />
              ))}
            </div>
          </div>

          {/* Notifications */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Notifications</h3>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.notifications.email}
                  onChange={(e) => setSettings({
                    ...settings,
                    notifications: { ...settings.notifications, email: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="ml-2 text-sm">Email Notifications</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.notifications.desktop}
                  onChange={(e) => setSettings({
                    ...settings,
                    notifications: { ...settings.notifications, desktop: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="ml-2 text-sm">Desktop Notifications</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.notifications.slack}
                  onChange={(e) => setSettings({
                    ...settings,
                    notifications: { ...settings.notifications, slack: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="ml-2 text-sm">Slack Notifications</span>
              </label>
            </div>
          </div>

          {/* Automations */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Automations</h3>
            <div className="space-y-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.automations.enabled}
                  onChange={(e) => setSettings({
                    ...settings,
                    automations: { ...settings.automations, enabled: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="ml-2 text-sm">Enable Automations</span>
              </label>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Reminder Days</label>
                <input
                  type="number"
                  value={settings.automations.reminderDays}
                  onChange={(e) => setSettings({
                    ...settings,
                    automations: { ...settings.automations, reminderDays: parseInt(e.target.value) }
                  })}
                  className="block w-24 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                  min="1"
                  max="30"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end p-4 border-t bg-gray-50">
          <button
            onClick={onClose}
            className="px-3 py-1.5 border border-gray-300 rounded-md text-sm text-gray-700 hover:bg-gray-50 mr-2"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-3 py-1.5 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 flex items-center text-sm"
          >
            <Save className="h-4 w-4 mr-1.5" />
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default CRMSettings;