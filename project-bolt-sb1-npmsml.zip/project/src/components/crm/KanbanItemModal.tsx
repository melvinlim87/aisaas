import React, { useState } from 'react';
import { X, Search, User, Building } from 'lucide-react';
import { KanbanItem, Contact } from '../../types/crm';

interface KanbanItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: Omit<KanbanItem, 'id'>) => void;
  editingItem?: KanbanItem;
}

// Mock contacts data - in real app this would come from your contacts store
const MOCK_CONTACTS: Contact[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@company.com',
    phone: '+1 234 567 890',
    company: 'Tech Corp',
    position: 'CTO',
    status: 'active',
    type: 'lead',
    source: 'Website',
    lastContact: '2024-01-15',
    notes: 'Key decision maker for enterprise deals',
    tags: ['Enterprise', 'Tech'],
    assignedTo: 'Sarah Wilson',
    createdAt: '2024-01-01',
    updatedAt: '2024-01-15'
  },
  {
    id: '2',
    name: 'Jane Doe',
    email: 'jane.doe@startup.com',
    phone: '+1 987 654 321',
    company: 'Startup Inc',
    position: 'CEO',
    status: 'active',
    type: 'lead',
    source: 'LinkedIn',
    lastContact: '2024-01-14',
    notes: 'Interested in our premium plan',
    tags: ['Startup', 'SaaS'],
    assignedTo: 'Mike Johnson',
    createdAt: '2024-01-10',
    updatedAt: '2024-01-14'
  }
];

const KanbanItemModal: React.FC<KanbanItemModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingItem
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [formData, setFormData] = useState({
    priority: editingItem?.priority || 'medium',
    value: editingItem?.value || 0,
    dueDate: editingItem?.dueDate || new Date().toISOString().split('T')[0],
    assignee: editingItem?.assignee || '',
    tags: editingItem?.tags || []
  });

  const filteredContacts = MOCK_CONTACTS.filter(contact => 
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContact) return;

    const newItem = {
      title: `${selectedContact.company} - ${selectedContact.name}`,
      description: `${selectedContact.position} - ${selectedContact.notes}`,
      ...formData
    };

    onSave(newItem);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg w-full max-w-2xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">
            {editingItem ? 'Edit Deal' : 'New Deal'}
          </h3>
          <button onClick={onClose}>
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Contact Selector */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Select Contact/Lead
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search contacts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div className="mt-2 max-h-48 overflow-y-auto border rounded-lg divide-y">
              {filteredContacts.map(contact => (
                <div
                  key={contact.id}
                  onClick={() => setSelectedContact(contact)}
                  className={`p-3 cursor-pointer hover:bg-gray-50 ${
                    selectedContact?.id === contact.id ? 'bg-indigo-50' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center">
                        <User className="h-4 w-4 text-gray-400 mr-2" />
                        <span className="font-medium">{contact.name}</span>
                      </div>
                      <div className="flex items-center mt-1 text-sm text-gray-500">
                        <Building className="h-4 w-4 text-gray-400 mr-2" />
                        <span>{contact.company}</span>
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      contact.type === 'lead' ? 'bg-yellow-100 text-yellow-800' :
                      contact.type === 'customer' ? 'bg-green-100 text-green-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {contact.type}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Deal Details */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Priority</label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as KanbanItem['priority'] })}
                className="mt-1 block w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Deal Value</label>
              <div className="mt-1 relative rounded-lg">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">$</span>
                </div>
                <input
                  type="number"
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: parseFloat(e.target.value) })}
                  className="pl-7 block w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="0.00"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Due Date</label>
              <input
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="mt-1 block w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Assignee</label>
              <input
                type="text"
                value={formData.assignee}
                onChange={(e) => setFormData({ ...formData, assignee: e.target.value })}
                className="mt-1 block w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700">Tags (comma-separated)</label>
              <input
                type="text"
                value={formData.tags.join(', ')}
                onChange={(e) => setFormData({
                  ...formData,
                  tags: e.target.value.split(',').map(tag => tag.trim()).filter(Boolean)
                })}
                className="mt-1 block w-full rounded-lg border-gray-300 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!selectedContact}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
            >
              {editingItem ? 'Update Deal' : 'Create Deal'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default KanbanItemModal;