import React from 'react';
import { Droppable } from 'react-beautiful-dnd';
import KanbanCard from './KanbanCard';
import { KanbanItem } from '../../types/crm';
import { Plus } from 'lucide-react';

interface KanbanColumnProps {
  id: string;
  title: string;
  items?: KanbanItem[];
  onAddItem?: () => void;
  onEditItem?: (item: KanbanItem) => void;
  onDeleteItem?: (itemId: string) => void;
}

const KanbanColumn: React.FC<KanbanColumnProps> = ({
  id,
  title,
  items = [], // Using default parameter instead of defaultProps
  onAddItem = () => {}, // Default empty function
  onEditItem = () => {}, // Default empty function
  onDeleteItem = () => {} // Default empty function
}) => {
  return (
    <div className="flex-shrink-0 w-80">
      <div className="bg-gray-100 rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold flex items-center">
            {title}
            <span className="ml-2 bg-gray-200 text-gray-700 px-2 py-1 rounded-full text-sm">
              {items.length}
            </span>
          </h3>
          <button
            onClick={onAddItem}
            className="p-1 hover:bg-gray-200 rounded-full"
            title="Add new item"
          >
            <Plus className="h-5 w-5 text-gray-600" />
          </button>
        </div>

        <Droppable droppableId={id}>
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`flex-1 min-h-[200px] transition-colors duration-200 ${
                snapshot.isDraggingOver ? 'bg-gray-200' : ''
              }`}
            >
              <div className="space-y-3">
                {items.map((item, index) => (
                  <KanbanCard
                    key={item.id}
                    item={item}
                    index={index}
                    onEdit={() => onEditItem(item)}
                    onDelete={() => onDeleteItem(item.id)}
                  />
                ))}
              </div>
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </div>
    </div>
  );
};

export default KanbanColumn;