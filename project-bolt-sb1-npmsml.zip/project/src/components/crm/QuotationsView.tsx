import React, { useState } from 'react';
import { Plus, FileCheck, Download, Filter, MoreVertical, DollarSign, Calendar, User } from 'lucide-react';
import { Quotation } from '../../types/crm';
import QuotationModal from './QuotationModal';
import QuotationPreview from './QuotationPreview';
import toast from 'react-hot-toast';

const MOCK_QUOTATIONS: Quotation[] = [
  {
    id: '1',
    number: 'QT-2024-001',
    contactId: '1',
    date: '2024-01-15',
    validUntil: '2024-02-15',
    items: [
      {
        id: '1',
        description: 'Custom Software Development',
        quantity: 1,
        unitPrice: 25000,
        tax: 10,
        total: 25000
      }
    ],
    subtotal: 25000,
    tax: 2500,
    total: 27500,
    status: 'sent',
    notes: 'Quote valid for 30 days',
    terms: 'Standard terms and conditions apply',
    createdAt: '2024-01-15',
    updatedAt: '2024-01-15'
  }
];

const QuotationsView: React.FC = () => {
  const [quotations, setQuotations] = useState<Quotation[]>(MOCK_QUOTATIONS);
  const [selectedQuotation, setSelectedQuotation] = useState<Quotation | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const handleAddQuotation = (quotation: Omit<Quotation, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newQuotation: Quotation = {
      ...quotation,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setQuotations([...quotations, newQuotation]);
    setShowModal(false);
    toast.success('Quotation created successfully');
  };

  const handleEditQuotation = (quotation: Quotation) => {
    setQuotations(quotations.map(q => q.id === quotation.id ? quotation : q));
    setShowModal(false);
    setSelectedQuotation(null);
    toast.success('Quotation updated successfully');
  };

  const getStatusColor = (status: Quotation['status']) => {
    switch (status) {
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'sent':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex space-x-2">
          <button className="px-3 py-2 border rounded-lg hover:bg-gray-50 flex items-center">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </button>
          <button className="px-3 py-2 border rounded-lg hover:bg-gray-50 flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
        </div>
        <button
          onClick={() => {
            setSelectedQuotation(null);
            setShowModal(true);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
        >
          <Plus className="h-5 w-5 mr-2" />
          New Quotation
        </button>
      </div>

      {/* Quotations Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quotation
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valid Until
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {quotations.map((quotation) => (
              <tr key={quotation.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <FileCheck className="h-5 w-5 text-gray-400 mr-2" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {quotation.number}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm text-gray-900">
                    <DollarSign className="h-4 w-4 mr-1" />
                    {quotation.total.toLocaleString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(quotation.status)}`}>
                    {quotation.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-2" />
                    {new Date(quotation.date).toLocaleDateString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-2" />
                    {new Date(quotation.validUntil).toLocaleDateString()}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button
                    onClick={() => {
                      setSelectedQuotation(quotation);
                      setShowModal(true);
                    }}
                    className="text-indigo-600 hover:text-indigo-900 mr-4"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      setSelectedQuotation(quotation);
                      setShowPreview(true);
                    }}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    Preview
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Quotation Modal */}
      {showModal && (
        <QuotationModal
          quotation={selectedQuotation}
          onClose={() => {
            setShowModal(false);
            setSelectedQuotation(null);
          }}
          onSave={selectedQuotation ? handleEditQuotation : handleAddQuotation}
        />
      )}

      {/* Quotation Preview */}
      {showPreview && selectedQuotation && (
        <QuotationPreview
          quotation={selectedQuotation}
          onClose={() => {
            setShowPreview(false);
            setSelectedQuotation(null);
          }}
        />
      )}
    </div>
  );
};

export default QuotationsView;