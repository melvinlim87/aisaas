import React, { useState } from 'react';
import { MessageSquare, Settings, Key, Globe, Bell } from 'lucide-react';
import { ChannelConfig } from '../types/channels';
import toast from 'react-hot-toast';

interface ChannelSettingsProps {
  channel: ChannelConfig;
  onUpdate: (config: ChannelConfig) => void;
}

const ChannelSettings: React.FC<ChannelSettingsProps> = ({ channel, onUpdate }) => {
  const [config, setConfig] = useState(channel);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = async () => {
    try {
      await onUpdate(config);
      setIsEditing(false);
      toast.success(`${channel.name} settings updated successfully`);
    } catch (error) {
      toast.error(`Failed to update ${channel.name} settings`);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <MessageSquare className={`h-6 w-6 mr-3 ${channel.enabled ? 'text-green-500' : 'text-gray-400'}`} />
          <h3 className="text-lg font-semibold">{channel.name}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-gray-600 hover:text-gray-900"
          >
            <Settings className="h-5 w-5" />
          </button>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={(e) => setConfig({ ...config, enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
      </div>

      {isEditing && (
        <div className="space-y-4">
          {/* API Credentials */}
          <div className="border rounded-lg p-4">
            <h4 className="flex items-center text-sm font-medium text-gray-700 mb-3">
              <Key className="h-4 w-4 mr-2" />
              API Credentials
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">API Key</label>
                <input
                  type="password"
                  value={config.credentials.apiKey || ''}
                  onChange={(e) => setConfig({
                    ...config,
                    credentials: { ...config.credentials, apiKey: e.target.value }
                  })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">API Secret</label>
                <input
                  type="password"
                  value={config.credentials.apiSecret || ''}
                  onChange={(e) => setConfig({
                    ...config,
                    credentials: { ...config.credentials, apiSecret: e.target.value }
                  })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Webhook Configuration */}
          <div className="border rounded-lg p-4">
            <h4 className="flex items-center text-sm font-medium text-gray-700 mb-3">
              <Globe className="h-4 w-4 mr-2" />
              Webhook Configuration
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700">Webhook URL</label>
                <input
                  type="text"
                  value={config.webhook?.url || ''}
                  onChange={(e) => setConfig({
                    ...config,
                    webhook: { ...config.webhook, url: e.target.value }
                  })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Webhook Secret</label>
                <input
                  type="password"
                  value={config.webhook?.secret || ''}
                  onChange={(e) => setConfig({
                    ...config,
                    webhook: { ...config.webhook, secret: e.target.value }
                  })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Channel Settings */}
          <div className="border rounded-lg p-4">
            <h4 className="flex items-center text-sm font-medium text-gray-700 mb-3">
              <Bell className="h-4 w-4 mr-2" />
              Channel Settings
            </h4>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700">Welcome Message</label>
                <textarea
                  value={config.settings.welcomeMessage || ''}
                  onChange={(e) => setConfig({
                    ...config,
                    settings: { ...config.settings, welcomeMessage: e.target.value }
                  })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  rows={2}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Handoff Threshold</label>
                  <input
                    type="number"
                    min="0"
                    max="1"
                    step="0.1"
                    value={config.settings.handoffThreshold || 0.7}
                    onChange={(e) => setConfig({
                      ...config,
                      settings: { ...config.settings, handoffThreshold: parseFloat(e.target.value) }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Max Queue Size</label>
                  <input
                    type="number"
                    min="1"
                    value={config.settings.maxQueueSize || 100}
                    onChange={(e) => setConfig({
                      ...config,
                      settings: { ...config.settings, maxQueueSize: parseInt(e.target.value) }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="flex items-center mt-2">
                <input
                  type="checkbox"
                  id={`autoReply-${channel.id}`}
                  checked={config.settings.autoReply || false}
                  onChange={(e) => setConfig({
                    ...config,
                    settings: { ...config.settings, autoReply: e.target.checked }
                  })}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor={`autoReply-${channel.id}`} className="ml-2 text-sm text-gray-700">
                  Enable Auto Reply
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Save Changes
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChannelSettings;