import { useState, useEffect } from 'react';

const DEFAULT_LAYOUT = [
  { i: 'revenue', x: 0, y: 0, w: 6, h: 2 },
  { i: 'conversations', x: 6, y: 0, w: 3, h: 2 },
  { i: 'appointments', x: 9, y: 0, w: 3, h: 2 },
  { i: 'satisfaction', x: 0, y: 2, w: 6, h: 2 },
  { i: 'activity', x: 6, y: 2, w: 6, h: 2 },
  { i: 'analytics', x: 0, y: 4, w: 12, h: 2 },
  { i: 'custom-charts', x: 0, y: 6, w: 12, h: 3 }
];

export const useDashboardLayout = () => {
  const [layout, setLayout] = useState(DEFAULT_LAYOUT);
  const [isCustomizing, setIsCustomizing] = useState(false);

  useEffect(() => {
    const savedLayout = localStorage.getItem('dashboardLayout');
    if (savedLayout) {
      try {
        setLayout(JSON.parse(savedLayout));
      } catch (error) {
        console.error('Error loading saved layout:', error);
      }
    }
  }, []);

  const handleLayoutChange = (newLayout: any) => {
    setLayout(newLayout);
    localStorage.setItem('dashboardLayout', JSON.stringify(newLayout));
  };

  const toggleCustomizing = () => {
    setIsCustomizing(!isCustomizing);
  };

  return {
    layout,
    isCustomizing,
    handleLayoutChange,
    toggleCustomizing
  };
};

export default useDashboardLayout;