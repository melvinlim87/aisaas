class MessageRouter {
  private shouldTransfer(conversation: Conversation): boolean {
    const recentMessages = conversation.messages.slice(-5);
    
    // Update condition names for clarity
    const conditions = {
      repeatedQuestions: this.hasRepeatedQuestions(recentMessages),
      lowConfidence: this.hasLowConfidence(recentMessages),
      explicitRequest: this.hasExplicitTransferRequest(recentMessages), // Updated method name
      complexQuery: this.isComplexQuery(recentMessages)
    };

    return Object.values(conditions).some(condition => condition);
  }

  // Update method name and its implementation
  private hasExplicitTransferRequest(messages: Message[]): boolean {
    // Check for explicit requests for live agent support
    const transferKeywords = ['agent', 'human', 'person', 'support', 'help'];
    return messages.some(msg => 
      msg.sender === 'user' && 
      transferKeywords.some(keyword => 
        msg.content.toLowerCase().includes(keyword)
      )
    );
  }
}