import { loadStripe, Stripe } from '@stripe/stripe-js';

let stripePromise: Promise<Stripe | null>;

export const getStripe = (publicKey: string) => {
  if (!stripePromise) {
    stripePromise = loadStripe(publicKey);
  }
  return stripePromise;
};

export const createPaymentIntent = async (amount: number, currency: string = 'USD') => {
  try {
    // Mock API call - replace with actual API endpoint
    const response = await fetch('/api/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount, currency }),
    });

    const data = await response.json();
    return data.clientSecret;
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
};

export const confirmPayment = async (clientSecret: string, paymentMethodId?: string) => {
  try {
    const stripe = await getStripe(process.env.STRIPE_PUBLIC_KEY || '');
    if (!stripe) throw new Error('Stripe not initialized');

    const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: paymentMethodId,
    });

    if (error) throw error;
    return paymentIntent;
  } catch (error) {
    console.error('Error confirming payment:', error);
    throw error;
  }
};

export const stripeService = {
  getStripe,
  createPaymentIntent,
  confirmPayment,
};