import { fetchWithCorsProxy } from './corsProxyService';
import { chatbotService } from './chatbotService';
import { useChatStore } from '../store/chatStore';
import { trainingPersistenceService } from './trainingPersistenceService';
import { DEFAULT_SYSTEM_PROMPT } from '../config/constants';
import toast from 'react-hot-toast';

interface TrainingOptions {
  maxDepth?: number;
  excludePaths?: string[];
  includeImages?: boolean;
}

interface TrainingProgress {
  status: 'processing' | 'completed' | 'error';
  progress: number;
  message?: string;
  url?: string;
  content?: string;
}

export async function trainWithUrl(
  url: string, 
  options: TrainingOptions = {}, 
  progressCallback?: (progress: TrainingProgress) => void
): Promise<string[]> {
  try {
    progressCallback?.({
      status: 'processing',
      progress: 0,
      message: 'Starting content fetch...'
    });

    // Fetch and process the content
    const content = await fetchWithCorsProxy(url);
    if (!content) {
      throw new Error('No content received from URL');
    }

    progressCallback?.({
      status: 'processing',
      progress: 30,
      message: 'Processing content...'
    });

    // Process the content into a training format
    const processedContent = await processContent(content);

    progressCallback?.({
      status: 'processing',
      progress: 60,
      message: 'Updating system prompt...'
    });

    // Update the system prompt with the new training data
    const store = useChatStore.getState();
    const currentSettings = store.settings;
    
    // Append the new training data to the existing system prompt
    const updatedSystemPrompt = `${currentSettings.advanced.systemPrompt}\n\nTraining Data from ${url}:\n${processedContent}`;
    
    // Update the store with the new system prompt
    await store.updateSettings({
      ...currentSettings,
      advanced: {
        ...currentSettings.advanced,
        systemPrompt: updatedSystemPrompt
      }
    });

    progressCallback?.({
      status: 'processing',
      progress: 80,
      message: 'Saving training data...'
    });

    // Save the training data to persistent storage
    trainingPersistenceService.addTrainedUrl(url, processedContent);

    // Test the updated system prompt
    await chatbotService.testPrompt(
      updatedSystemPrompt,
      "Summarize what you've learned from the training data."
    );

    progressCallback?.({
      status: 'completed',
      progress: 100,
      message: 'Training completed successfully',
      url: url,
      content: processedContent
    });

    toast.success('Training data saved and will persist across sessions');

    return [processedContent];

  } catch (error) {
    console.error('Error training with URL:', error);
    const errorMessage = error instanceof Error 
      ? error.message 
      : 'An unexpected error occurred during training';

    progressCallback?.({
      status: 'error',
      progress: 0,
      message: errorMessage
    });

    throw new Error(errorMessage);
  }
}

async function processContent(html: string): Promise<string> {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Remove script and style elements
    doc.querySelectorAll('script, style, iframe, noscript').forEach(el => el.remove());

    // Extract structured content
    const title = doc.querySelector('title')?.textContent || '';
    const metaDescription = doc.querySelector('meta[name="description"]')?.getAttribute('content') || '';
    const headings = Array.from(doc.querySelectorAll('h1, h2, h3'))
      .map(h => h.textContent?.trim())
      .filter(Boolean);
    const paragraphs = Array.from(doc.querySelectorAll('p'))
      .map(p => p.textContent?.trim())
      .filter(Boolean);

    // Format the content in a structured way for training
    const trainingContent = [
      '# Page Information',
      `Title: ${title}`,
      metaDescription ? `Description: ${metaDescription}` : '',
      '',
      '# Main Topics',
      ...headings.map(h => `- ${h}`),
      '',
      '# Detailed Content',
      ...paragraphs.map(p => p.split('\n').map(line => line.trim()).join('\n')),
      '',
      '# Usage Instructions',
      '- Use this information to provide accurate responses about the topics covered',
      '- Reference specific details when answering related questions',
      '- Maintain the original context when discussing these topics'
    ].filter(Boolean).join('\n');

    return trainingContent;

  } catch (error) {
    console.error('Error processing content:', error);
    throw new Error('Failed to process HTML content for training');
  }
}

export async function trainWithFiles(files: File[]): Promise<void> {
  try {
    for (const file of files) {
      const content = await readFileContent(file);
      const processedContent = await processFileContent(content, file.name);
      
      // Update system prompt with new training data
      const store = useChatStore.getState();
      const currentSettings = store.settings;
      
      const updatedSystemPrompt = `${currentSettings.advanced.systemPrompt}\n\nTraining Data from ${file.name}:\n${processedContent}`;
      
      await store.updateSettings({
        ...currentSettings,
        advanced: {
          ...currentSettings.advanced,
          systemPrompt: updatedSystemPrompt
        }
      });

      // Save to persistent storage
      trainingPersistenceService.addTrainedDocument({
        name: file.name,
        content: processedContent
      });
    }

    toast.success('Files processed and training data saved successfully');
  } catch (error) {
    console.error('Error processing files:', error);
    throw error;
  }
}

async function readFileContent(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve(e.target?.result as string);
    reader.onerror = reject;
    reader.readAsText(file);
  });
}

async function processFileContent(content: string, fileName: string): Promise<string> {
  // Process based on file type
  if (fileName.endsWith('.md')) {
    return processMdContent(content);
  } else if (fileName.endsWith('.txt')) {
    return processTxtContent(content);
  } else {
    return processGenericContent(content);
  }
}

function processMdContent(content: string): string {
  // Preserve markdown structure but clean and format
  return content
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .join('\n');
}

function processTxtContent(content: string): string {
  // Basic text processing
  return content
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .join('\n');
}

function processGenericContent(content: string): string {
  // Generic content processing
  return content
    .split('\n')
    .map(line => line.trim())
    .filter(Boolean)
    .join('\n');
}

// Load saved training data on initialization
export async function initializeTraining(): Promise<void> {
  try {
    const trainingData = trainingPersistenceService.getTrainingData();
    if (!trainingData.lastUpdated) return;

    const store = useChatStore.getState();
    const currentSettings = store.settings;

    // Start with the default system prompt
    let updatedSystemPrompt = DEFAULT_SYSTEM_PROMPT;

    // Add trained URLs
    trainingData.urls.forEach(({ url, content }) => {
      updatedSystemPrompt += `\n\nTraining Data from ${url}:\n${content}`;
    });

    // Add trained documents
    trainingData.documents.forEach(({ name, content }) => {
      updatedSystemPrompt += `\n\nTraining Data from ${name}:\n${content}`;
    });

    // Update the store with the reconstructed prompt
    store.updateSettings({
      ...currentSettings,
      advanced: {
        ...currentSettings.advanced,
        systemPrompt: updatedSystemPrompt
      }
    });

    console.log('Training data restored from persistent storage');
  } catch (error) {
    console.error('Error initializing training data:', error);
  }
}