import { Message } from '../types/chat';

interface StoredConversation {
  id: string;
  messages: Array<Omit<Message, 'timestamp'> & { timestamp: string }>;
  lastUpdated: string;
}

class ConversationPersistence {
  private static instance: ConversationPersistence;
  private readonly STORAGE_KEY = 'external_chat_conversations';
  private visitorId: string | null = null;

  private constructor() {
    this.initializeVisitorId();
  }

  public static getInstance(): ConversationPersistence {
    if (!ConversationPersistence.instance) {
      ConversationPersistence.instance = new ConversationPersistence();
    }
    return ConversationPersistence.instance;
  }

  private async initializeVisitorId() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      this.visitorId = btoa(data.ip);
    } catch (error) {
      this.visitorId = btoa(navigator.userAgent + window.screen.width + window.screen.height);
    }
  }

  public async getConversation(): Promise<Message[]> {
    await this.ensureVisitorId();
    const conversations = this.loadConversations();
    const conversation = conversations.find(c => c.id === this.visitorId);
    
    if (!conversation) return [];

    // Convert string timestamps back to Date objects
    return conversation.messages.map(msg => ({
      ...msg,
      timestamp: new Date(msg.timestamp)
    }));
  }

  public async saveConversation(messages: Message[]): Promise<void> {
    await this.ensureVisitorId();
    const conversations = this.loadConversations();
    
    // Convert Date objects to ISO strings for storage
    const storedMessages = messages.map(msg => ({
      ...msg,
      timestamp: msg.timestamp.toISOString()
    }));

    const existingIndex = conversations.findIndex(c => c.id === this.visitorId);
    const updatedConversation: StoredConversation = {
      id: this.visitorId!,
      messages: storedMessages,
      lastUpdated: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      conversations[existingIndex] = updatedConversation;
    } else {
      conversations.push(updatedConversation);
    }

    const recentConversations = conversations
      .sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime())
      .slice(0, 50);

    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(recentConversations));
  }

  public async clearConversation(): Promise<void> {
    await this.ensureVisitorId();
    const conversations = this.loadConversations();
    const updatedConversations = conversations.filter(c => c.id !== this.visitorId);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedConversations));
  }

  private async ensureVisitorId() {
    if (!this.visitorId) {
      await this.initializeVisitorId();
    }
  }

  private loadConversations(): StoredConversation[] {
    const stored = localStorage.getItem(this.STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  }
}

export const conversationPersistence = ConversationPersistence.getInstance();