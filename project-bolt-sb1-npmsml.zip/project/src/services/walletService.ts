import { WalletBalance, WalletTransaction, WalletSettings } from '../types/wallet';
import { useStore } from '../store/useStore';

class WalletService {
  private static instance: WalletService;
  private mockBalance: WalletBalance = {
    amount: 50.00,
    currency: 'USD',
    updatedAt: new Date(),
    hasPaymentMethod: false,
    monthlyUsage: 0, // Reset to 0
    responseCount: 0, // Reset to 0
    averageCost: 0.01 // Fixed cost per response
  };

  private mockTransactions: WalletTransaction[] = []; // Clear transactions

  private mockSettings: WalletSettings = {
    lowBalanceAlert: 5.00,
    autoReloadAmount: 20.00,
    autoReloadEnabled: false,
    notificationEmail: ''
  };

  private constructor() {
    // Clear any stored data
    localStorage.removeItem('wallet_balance');
    localStorage.removeItem('wallet_transactions');
    this.loadStoredData();
  }

  public static getInstance(): WalletService {
    if (!WalletService.instance) {
      WalletService.instance = new WalletService();
    }
    return WalletService.instance;
  }

  private loadStoredData(): void {
    const storedBalance = localStorage.getItem('wallet_balance');
    const storedTransactions = localStorage.getItem('wallet_transactions');
    const storedSettings = localStorage.getItem('wallet_settings');

    if (storedBalance) {
      this.mockBalance = JSON.parse(storedBalance);
      this.mockBalance.updatedAt = new Date(this.mockBalance.updatedAt);
    }
    if (storedTransactions) {
      this.mockTransactions = JSON.parse(storedTransactions);
      this.mockTransactions.forEach(t => t.createdAt = new Date(t.createdAt));
    }
    if (storedSettings) {
      this.mockSettings = JSON.parse(storedSettings);
    }
  }

  private persistData(): void {
    localStorage.setItem('wallet_balance', JSON.stringify(this.mockBalance));
    localStorage.setItem('wallet_transactions', JSON.stringify(this.mockTransactions));
    localStorage.setItem('wallet_settings', JSON.stringify(this.mockSettings));
  }

  public async getBalance(): Promise<WalletBalance> {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
    return { ...this.mockBalance };
  }

  public async getTransactions(): Promise<WalletTransaction[]> {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
    return [...this.mockTransactions];
  }

  public async getSettings(): Promise<WalletSettings> {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
    return { ...this.mockSettings };
  }

  public async addTransaction(transaction: Omit<WalletTransaction, 'id' | 'createdAt'>): Promise<void> {
    const store = useStore.getState();
    const selectedModel = store.models.find(m => m.id === store.selectedModel);
    
    if (!selectedModel) {
      throw new Error('Selected model not found');
    }

    const newTransaction: WalletTransaction = {
      id: Date.now().toString(),
      ...transaction,
      createdAt: new Date()
    };

    // Update balance
    if (transaction.type === 'credit') {
      this.mockBalance.amount += transaction.amount;
    } else {
      this.mockBalance.amount -= transaction.amount;
    }
    this.mockBalance.updatedAt = new Date();

    // Update usage metrics for debit transactions (AI usage)
    if (transaction.type === 'debit') {
      this.mockBalance.responseCount++;
      this.mockBalance.monthlyUsage++; // Increment usage count
      this.mockBalance.averageCost = 0.01; // Fixed cost per response based on master account markup
    }

    this.mockTransactions.unshift(newTransaction);
    this.persistData();

    // Check for low balance
    if (this.mockBalance.amount <= this.mockSettings.lowBalanceAlert) {
      if (this.mockSettings.autoReloadEnabled && this.mockBalance.hasPaymentMethod) {
        await this.addBalance(this.mockSettings.autoReloadAmount, 'Auto-reload');
      }
    }
  }

  public async addBalance(amount: number, description: string): Promise<void> {
    await this.addTransaction({
      type: 'credit',
      amount,
      description,
      status: 'completed'
    });
  }

  public async updateSettings(settings: WalletSettings): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate API delay
    this.mockSettings = settings;
    this.persistData();
  }

  // Add method to clear all data (for testing)
  public async clearData(): Promise<void> {
    this.mockBalance = {
      amount: 50.00,
      currency: 'USD',
      updatedAt: new Date(),
      hasPaymentMethod: false,
      monthlyUsage: 0,
      responseCount: 0,
      averageCost: 0.01
    };
    this.mockTransactions = [];
    localStorage.removeItem('wallet_balance');
    localStorage.removeItem('wallet_transactions');
    this.persistData();
  }
}

export const walletService = WalletService.getInstance();