class NotificationService {
  // Update notification type in method calls
  public async notifyLiveAgentTransfer(conversation: Conversation, agent: User): Promise<void> {
    if (agent.notificationPreferences.types.liveAgentTransfer) {
      const notification = {
        title: 'Live Agent Transfer Request',
        message: `New transfer request for conversation ${conversation.id}`,
        type: 'liveAgentTransfer'
      };
      
      await this.sendNotification(notification, agent);
    }
  }
}