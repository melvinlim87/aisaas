const calculateCost = (response: string): number => {
  // Fixed cost of $0.01 per response
  return 0.01;
};