import { JSDOM } from 'jsdom';

interface CrawlResult {
  url: string;
  title: string;
  content: string;
  links: string[];
}

export class WebCrawler {
  private visited = new Set<string>();
  private queue: string[] = [];
  private baseUrl: string;
  private maxPages: number;
  private results: CrawlResult[] = [];

  constructor(baseUrl: string, maxPages: number = 100) {
    this.baseUrl = new URL(baseUrl).origin;
    this.maxPages = maxPages;
    this.queue.push(baseUrl);
  }

  private isValidUrl(url: string): boolean {
    try {
      const parsedUrl = new URL(url);
      return parsedUrl.origin === this.baseUrl;
    } catch {
      return false;
    }
  }

  private async fetchPage(url: string): Promise<string> {
    const response = await fetch(url);
    return response.text();
  }

  private extractContent(dom: JSDOM): CrawlResult {
    const doc = dom.window.document;
    
    // Remove script and style elements
    doc.querySelectorAll('script, style').forEach(el => el.remove());
    
    const title = doc.querySelector('title')?.textContent || '';
    const content = doc.body.textContent?.trim() || '';
    
    // Extract all links
    const links = Array.from(doc.querySelectorAll('a'))
      .map(a => a.href)
      .filter(href => this.isValidUrl(href));

    return {
      url: dom.window.location.href,
      title,
      content,
      links
    };
  }

  public async crawl(onProgress?: (progress: number) => void): Promise<CrawlResult[]> {
    while (this.queue.length > 0 && this.results.length < this.maxPages) {
      const url = this.queue.shift()!;
      
      if (this.visited.has(url)) continue;
      this.visited.add(url);

      try {
        const html = await this.fetchPage(url);
        const dom = new JSDOM(html, { url });
        const result = this.extractContent(dom);
        this.results.push(result);

        // Add new links to queue
        result.links
          .filter(link => !this.visited.has(link))
          .forEach(link => this.queue.push(link));

        // Report progress
        if (onProgress) {
          onProgress((this.results.length / this.maxPages) * 100);
        }
      } catch (error) {
        console.error(`Error crawling ${url}:`, error);
      }
    }

    return this.results;
  }
}