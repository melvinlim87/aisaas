import { ChatMessage } from '../types/chat';
import { generateResponse } from './deepinfra';
import { internalDataCrawler } from './internalDataCrawler';

class InternalAIService {
  private static instance: InternalAIService | null = null;
  
  private readonly systemPrompt = `You are an advanced analytics assistant specializing in business intelligence and data analysis.

# Response Structure
Follow this EXACT format for ALL responses:


1. Executive Summary
    a. Key Performance Overview
        - Current Month: **value**
        - Previous Month: **value**
        - Change: **value** (**percentage**%)
    b. Highlight Metrics
        - Best Performing: **metric** (**value**)
        - Needs Attention: **metric** (**value**)


2. Detailed Analysis
    a. Sales Performance
        - Monthly Revenue: **value**
        - YoY Growth: **value**%
        - Top Products/Services: **list**
        - Average Deal Size: **value**
    b. Comparative Analysis
        - vs Previous Month: **value**% change
        - vs Same Month Last Year: **value**% change
        - Market Trend Alignment: **analysis**
    c. Key Metrics
        - Conversion Rate: **value**%
        - Customer Acquisition Cost: **value**
        - Customer Lifetime Value: **value**
        - Retention Rate: **value**%


3. Growth Opportunities
    a. Identified Trends
        1. [Trend with supporting data]
        2. [Trend with supporting data]
        3. [Trend with supporting data]
    b. Market Insights
        1. [Market observation]
        2. [Competitive analysis]
        3. [Industry trends]


4. Action Plan
    a. Immediate Actions (0-30 days)
        1. [Specific action with expected impact]
        2. [Specific action with expected impact]
        3. [Specific action with expected impact]
    b. Strategic Initiatives (30-90 days)
        1. [Strategic initiative with goals]
        2. [Strategic initiative with goals]
        3. [Strategic initiative with goals]


5. Performance Forecast
    a. Next Month Projection
        - Expected Revenue: **value**
        - Growth Target: **value**%
        - Key Focus Areas: **list**
    b. Risk Factors
        1. [Identified risk and mitigation]
        2. [Identified risk and mitigation]


6. Data Visualization
    [Include relevant charts with clear explanations of patterns and insights]


CRITICAL Formatting Rules:
1. Use EXACTLY 4 spaces for indentation
2. Use numerical markers (1, 2, 3) for main sections
3. Use alphabetical markers (a, b, c) for sub-points
4. Keep TWO line breaks between main sections
5. Keep sub-points close together with NO extra line breaks
6. Bold ALL metrics using **value**
7. Include percentage changes where applicable
8. Always provide comparative analysis
9. Include specific, actionable recommendations
10. Support insights with data
11. Highlight both positive trends and areas for improvement`;

  private constructor() {}

  public static getInstance(): InternalAIService {
    if (!InternalAIService.instance) {
      InternalAIService.instance = new InternalAIService();
    }
    return InternalAIService.instance;
  }

  async processQuery(query: string): Promise<ChatMessage> {
    try {
      const data = await this.fetchRelevantData(query);
      
      const contextPrompt = `Based on the following company data:

${JSON.stringify(data, null, 2)}

${query}

Provide insights and recommendations following the exact format specified. Ensure proper spacing and formatting in your response.`;

      const response = await generateResponse(contextPrompt, null, 'llama-3');
      const charts = this.generateChartConfigs(data, query);

      return {
        id: Date.now().toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date(),
        metadata: {
          data,
          source: 'internal',
          analytics: {
            chartConfig: charts
          }
        }
      };
    } catch (error) {
      console.error('Error processing internal AI query:', error);
      throw error;
    }
  }

  private async fetchRelevantData(query: string) {
    const queryLower = query.toLowerCase();
    const data: any = {};

    if (queryLower.includes('revenue') || queryLower.includes('sales')) {
      data.revenue = (await internalDataCrawler.crawlAnalytics()).revenue;
    }

    if (queryLower.includes('conversation') || queryLower.includes('chat')) {
      data.conversations = await internalDataCrawler.crawlConversations();
    }

    if (queryLower.includes('appointment') || queryLower.includes('meeting')) {
      data.appointments = await internalDataCrawler.crawlAppointments();
    }

    if (queryLower.includes('customer') || queryLower.includes('crm')) {
      data.crm = await internalDataCrawler.crawlCRMData();
    }

    if (Object.keys(data).length === 0) {
      data.all = await internalDataCrawler.crawlAllData();
    }

    return data;
  }

  private generateChartConfigs(data: any, query: string) {
    const charts = [];

    // Revenue Charts
    if (data.revenue?.daily) {
      const labels = Object.keys(data.revenue.daily);
      const values = Object.values(data.revenue.daily) as number[];
      
      charts.push({
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: 'Daily Revenue',
            data: values,
            borderColor: 'rgb(59, 130, 246)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Revenue Trends' }
          }
        }
      });
    }

    return charts.length > 0 ? charts : null;
  }
}

export const internalAIService = InternalAIService.getInstance();