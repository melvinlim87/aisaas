import { LiveAgentTransferSettings } from '../types/ai';

class LiveAgentTransferService {
  private static instance: LiveAgentTransferService;
  private transferSettings: LiveAgentTransferSettings = {
    enabled: true,
    triggerKeywords: ['STOP', 'Agent', 'Support', 'Talk to agent'],
    transferMessage: 'Connecting you with a live support agent...',
    notifications: {
      email: {
        enabled: false,
        addresses: []
      },
      webhook: {
        enabled: false,
        url: '',
        secret: ''
      }
    },
    channels: {
      web: true,
      whatsapp: false,
      messenger: false,
      instagram: false
    }
  };

  private constructor() {}

  public static getInstance(): LiveAgentTransferService {
    if (!LiveAgentTransferService.instance) {
      LiveAgentTransferService.instance = new LiveAgentTransferService();
    }
    return LiveAgentTransferService.instance;
  }

  public shouldTransfer(message: string): boolean {
    if (!this.transferSettings.enabled) return false;

    const normalizedMessage = message.toLowerCase().trim();
    return this.transferSettings.triggerKeywords.some(keyword => 
      normalizedMessage.includes(keyword.toLowerCase())
    );
  }

  public async handleTransfer(conversationId: string, channel: keyof typeof this.transferSettings.channels): Promise<void> {
    if (!this.transferSettings.channels[channel]) {
      throw new Error(`Live agent transfer not enabled for channel: ${channel}`);
    }

    await this.sendNotifications(conversationId);
  }

  private async sendNotifications(conversationId: string): Promise<void> {
    const promises: Promise<void>[] = [];

    if (this.transferSettings.notifications.email.enabled) {
      promises.push(this.sendEmailNotification(conversationId));
    }

    if (this.transferSettings.notifications.webhook.enabled) {
      promises.push(this.sendWebhookNotification(conversationId));
    }

    await Promise.all(promises);
  }

  private async sendEmailNotification(conversationId: string): Promise<void> {
    const { addresses } = this.transferSettings.notifications.email;
    console.log(`Sending email notifications to: ${addresses.join(', ')}`);
  }

  private async sendWebhookNotification(conversationId: string): Promise<void> {
    const { url, secret } = this.transferSettings.notifications.webhook;
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Secret': secret
        },
        body: JSON.stringify({
          type: 'live_agent_transfer',
          conversationId,
          timestamp: new Date().toISOString()
        })
      });

      if (!response.ok) {
        throw new Error(`Webhook notification failed: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Error sending webhook notification:', error);
      throw error;
    }
  }

  public updateSettings(newSettings: Partial<LiveAgentTransferSettings>): void {
    this.transferSettings = {
      ...this.transferSettings,
      ...newSettings,
      notifications: {
        ...this.transferSettings.notifications,
        ...(newSettings.notifications || {}),
        email: {
          ...this.transferSettings.notifications.email,
          ...(newSettings.notifications?.email || {})
        },
        webhook: {
          ...this.transferSettings.notifications.webhook,
          ...(newSettings.notifications?.webhook || {})
        }
      },
      channels: {
        ...this.transferSettings.channels,
        ...(newSettings.channels || {})
      }
    };
  }

  public getSettings(): LiveAgentTransferSettings {
    return { ...this.transferSettings };
  }
}

export const liveAgentTransferService = LiveAgentTransferService.getInstance();