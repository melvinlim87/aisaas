import { DEEPINFRA_API_KEY, DEEPINFRA_MODEL_URL, STOP_TOKENS } from '../config/constants';

class TextGeneration {
  private modelUrl: string;
  private apiKey: string;

  constructor(modelUrl: string, apiKey: string) {
    this.modelUrl = modelUrl;
    this.apiKey = apiKey;
  }

  async generate(params: {
    input: string;
    stop?: string[];
    max_new_tokens?: number;
    temperature?: number;
    top_p?: number;
    min_p?: number;
    top_k?: number;
    repetition_penalty?: number;
    presence_penalty?: number;
    frequency_penalty?: number;
    response_format?: { type: 'text' | 'json_object' };
    num_responses?: number;
    stream?: boolean;
  }) {
    const response = await fetch(this.modelUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error(`DeepInfra API error: ${response.statusText}`);
    }

    const data = await response.json();
    return {
      results: data.results || []
    };
  }
}

// Singleton instance
const client = new TextGeneration(DEEPINFRA_MODEL_URL, DEEPINFRA_API_KEY);

export const generateWithRole = async (
  systemPrompt: string,
  userPrompt: string,
  config: {
    temperature?: number;
    max_new_tokens?: number;
    stop?: string[];
  } = {}
) => {
  const formattedPrompt = `<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n${systemPrompt}<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n${userPrompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n`;

  const response = await client.generate({
    input: formattedPrompt,
    stop: config.stop || STOP_TOKENS,
    temperature: config.temperature || 0.7,
    max_new_tokens: config.max_new_tokens || 1000,
  });

  return response.results[0]?.generated_text || '';
};

export const generateConversation = async (
  messages: { role: 'system' | 'user' | 'assistant'; content: string }[],
  config: {
    temperature?: number;
    max_new_tokens?: number;
    stop?: string[];
  } = {}
) => {
  const formattedPrompt = messages
    .map(msg => `<|begin_of_text|><|start_header_id|>${msg.role}<|end_header_id|>\n\n${msg.content}<|eot_id|>`)
    .join('') + '<|start_header_id|>assistant<|end_header_id|>\n\n';

  const response = await client.generate({
    input: formattedPrompt,
    stop: config.stop || STOP_TOKENS,
    temperature: config.temperature || 0.7,
    max_new_tokens: config.max_new_tokens || 1000,
  });

  return response.results[0]?.generated_text || '';
};

export default client;