import { SalesRep } from '../types/user';

// Mock data for initial development
const mockSalesReps: SalesRep[] = [
  {
    id: 'rep-1',
    name: 'John Doe',
    email: 'john@example.com',
    availability: {
      start: '09:00',
      end: '17:00',
      days: [1, 2, 3, 4, 5]
    }
  },
  {
    id: 'rep-2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    availability: {
      start: '10:00',
      end: '18:00',
      days: [1, 2, 3, 4, 5]
    }
  }
];

class UserService {
  private salesReps: SalesRep[] = [...mockSalesReps];

  async getSalesReps(): Promise<SalesRep[]> {
    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(this.salesReps);
      }, 100);
    });
  }

  async addSalesRep(rep: Omit<SalesRep, 'id'>): Promise<SalesRep> {
    const newRep: SalesRep = {
      ...rep,
      id: `rep-${this.salesReps.length + 1}`
    };
    
    this.salesReps.push(newRep);
    return newRep;
  }

  async updateSalesRep(id: string, updates: Partial<SalesRep>): Promise<SalesRep> {
    const index = this.salesReps.findIndex(rep => rep.id === id);
    if (index === -1) {
      throw new Error('Sales rep not found');
    }

    this.salesReps[index] = {
      ...this.salesReps[index],
      ...updates
    };

    return this.salesReps[index];
  }

  async deleteSalesRep(id: string): Promise<void> {
    const index = this.salesReps.findIndex(rep => rep.id === id);
    if (index === -1) {
      throw new Error('Sales rep not found');
    }

    this.salesReps.splice(index, 1);
  }

  async getSalesRepById(id: string): Promise<SalesRep | null> {
    const rep = this.salesReps.find(rep => rep.id === id);
    return rep || null;
  }
}

export const userService = new UserService();