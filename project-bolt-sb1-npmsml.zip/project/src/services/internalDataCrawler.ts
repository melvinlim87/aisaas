import { CRMData, AppointmentData, ConversationData, AnalyticsData } from '../types/data';
import { crmApi } from './api/crmApi';
import { appointmentsApi } from './api/appointmentsApi';
import { conversationsApi } from './api/conversationsApi';
import { analyticsApi } from './api/analyticsApi';

class InternalDataCrawler {
  private static instance: InternalDataCrawler;

  private constructor() {}

  public static getInstance(): InternalDataCrawler {
    if (!InternalDataCrawler.instance) {
      InternalDataCrawler.instance = new InternalDataCrawler();
    }
    return InternalDataCrawler.instance;
  }

  async crawlCRMData(): Promise<CRMData> {
    try {
      return await crmApi.getData();
    } catch (error) {
      console.error('Error crawling CRM data:', error);
      throw error;
    }
  }

  async crawlAppointments(): Promise<AppointmentData> {
    try {
      return await appointmentsApi.getData();
    } catch (error) {
      console.error('Error crawling appointment data:', error);
      throw error;
    }
  }

  async crawlConversations(): Promise<ConversationData> {
    try {
      return await conversationsApi.getData();
    } catch (error) {
      console.error('Error crawling conversation data:', error);
      throw error;
    }
  }

  async crawlAnalytics(): Promise<AnalyticsData> {
    try {
      return await analyticsApi.getData();
    } catch (error) {
      console.error('Error crawling analytics data:', error);
      throw error;
    }
  }

  async crawlAllData() {
    try {
      const [crm, appointments, conversations, analytics] = await Promise.all([
        this.crawlCRMData(),
        this.crawlAppointments(),
        this.crawlConversations(),
        this.crawlAnalytics()
      ]);

      return {
        crm,
        appointments,
        conversations,
        analytics
      };
    } catch (error) {
      console.error('Error crawling all data:', error);
      throw error;
    }
  }
}

export const internalDataCrawler = InternalDataCrawler.getInstance();