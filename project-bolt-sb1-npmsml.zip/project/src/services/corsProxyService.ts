import toast from 'react-hot-toast';

const CORS_PROXIES = [
  {
    name: 'allorigins',
    getUrl: (url: string) => `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
    processResponse: async (response: Response) => {
      const data = await response.json();
      if (!data.contents) throw new Error('No content received from proxy');
      return data.contents;
    }
  },
  {
    name: 'corsproxy',
    getUrl: (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    processResponse: async (response: Response) => {
      const text = await response.text();
      if (!text) throw new Error('No content received from proxy');
      return text;
    }
  },
  {
    name: 'corsanywhere',
    getUrl: (url: string) => `https://cors-anywhere.herokuapp.com/${url}`,
    processResponse: async (response: Response) => {
      const text = await response.text();
      if (!text) throw new Error('No content received from proxy');
      return text;
    }
  },
  {
    name: 'direct',
    getUrl: (url: string) => url,
    processResponse: async (response: Response) => {
      const text = await response.text();
      if (!text) throw new Error('No content received from direct request');
      return text;
    }
  }
];

export async function fetchWithCorsProxy(url: string): Promise<string> {
  let lastError: Error | null = null;
  let attempts = 0;

  for (const proxy of CORS_PROXIES) {
    attempts++;
    try {
      console.log(`Attempting to fetch with ${proxy.name} (attempt ${attempts}/${CORS_PROXIES.length})`);
      
      const proxyUrl = proxy.getUrl(url);
      const response = await fetch(proxyUrl, {
        headers: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'User-Agent': 'Mozilla/5.0 (compatible; URL-Training-Bot/1.0)'
        },
        mode: proxy.name === 'direct' ? 'no-cors' : 'cors'
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const content = await proxy.processResponse(response);
      console.log(`Successfully fetched content with ${proxy.name}`);
      return content;

    } catch (error) {
      lastError = error instanceof Error ? error : new Error('Unknown error occurred');
      console.warn(`Failed to fetch with ${proxy.name}:`, error);
      
      // If this is the last proxy, throw a detailed error
      if (attempts === CORS_PROXIES.length) {
        const errorMessage = `Failed to fetch content after trying ${attempts} proxies. Last error: ${lastError.message}`;
        console.error(errorMessage);
        throw new Error(errorMessage);
      }
      
      // Otherwise, continue to next proxy
      continue;
    }
  }

  throw lastError || new Error('All CORS proxies failed');
}

export async function validateUrl(url: string): Promise<boolean> {
  try {
    const urlObj = new URL(url);
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      throw new Error('URL must start with http:// or https://');
    }
    return true;
  } catch (error) {
    throw new Error('Invalid URL format. Please enter a valid URL starting with http:// or https://');
  }
}