import { Appointment } from '../types/appointments';

export interface CalendarProvider {
  id: string;
  name: string;
  icon: string;
  isConnected: boolean;
  authUrl: string;
  clientId: string;
  clientSecret: string;
  scopes: string[];
}

export interface CalendarEvent {
  id: string;
  title: string;
  description: string;
  startTime: string;
  endTime: string;
  location?: string;
  attendees: string[];
  meetingUrl?: string;
}

class CalendarService {
  private static instance: CalendarService;
  private providers: Record<string, CalendarProvider> = {
    google: {
      id: 'google',
      name: 'Google Calendar',
      icon: 'https://www.google.com/calendar/images/favicon_v2014_1.ico',
      isConnected: false,
      authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
      clientId: '',
      clientSecret: '',
      scopes: [
        'https://www.googleapis.com/auth/calendar.events',
        'https://www.googleapis.com/auth/calendar.readonly'
      ]
    },
    outlook: {
      id: 'outlook',
      name: 'Microsoft Outlook',
      icon: 'https://outlook.office.com/favicon.ico',
      isConnected: false,
      authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
      clientId: '',
      clientSecret: '',
      scopes: [
        'Calendars.ReadWrite',
        'Calendars.Read'
      ]
    },
    apple: {
      id: 'apple',
      name: 'Apple iCloud',
      icon: 'https://www.icloud.com/favicon.ico',
      isConnected: false,
      authUrl: 'https://appleid.apple.com/auth/authorize',
      clientId: '',
      clientSecret: '',
      scopes: [
        'calendar'
      ]
    }
  };

  private constructor() {}

  public static getInstance(): CalendarService {
    if (!CalendarService.instance) {
      CalendarService.instance = new CalendarService();
    }
    return CalendarService.instance;
  }

  public getProviders(): CalendarProvider[] {
    return Object.values(this.providers);
  }

  public updateProviderConfig(providerId: string, config: Partial<CalendarProvider>) {
    if (this.providers[providerId]) {
      this.providers[providerId] = {
        ...this.providers[providerId],
        ...config
      };
    }
  }

  public async createCalendarEvent(providerId: string, appointment: Appointment): Promise<CalendarEvent> {
    const provider = this.providers[providerId];
    if (!provider || !provider.isConnected) {
      throw new Error(`Calendar provider ${providerId} not configured or connected`);
    }

    // Calculate end time (1 hour duration by default)
    const startTime = `${appointment.date}T${appointment.time}:00`;
    const endTime = new Date(new Date(startTime).getTime() + 60 * 60 * 1000).toISOString();

    const event: CalendarEvent = {
      id: appointment.id.toString(),
      title: appointment.title,
      description: appointment.remarks || '',
      startTime,
      endTime,
      location: appointment.location.type === 'physical' ? appointment.location.details : undefined,
      meetingUrl: appointment.location.type === 'digital' ? appointment.location.details : undefined,
      attendees: [appointment.salesRepId] // Add customer email when available
    };

    switch (providerId) {
      case 'google':
        return await this.createGoogleCalendarEvent(event);
      case 'outlook':
        return await this.createOutlookCalendarEvent(event);
      case 'apple':
        return await this.createAppleCalendarEvent(event);
      default:
        throw new Error(`Unsupported calendar provider: ${providerId}`);
    }
  }

  private async createGoogleCalendarEvent(event: CalendarEvent): Promise<CalendarEvent> {
    // Implement Google Calendar API integration
    // Use Google Calendar API v3
    // Documentation: https://developers.google.com/calendar/api/v3/reference
    return event;
  }

  private async createOutlookCalendarEvent(event: CalendarEvent): Promise<CalendarEvent> {
    // Implement Microsoft Graph API integration for Outlook Calendar
    // Documentation: https://docs.microsoft.com/en-us/graph/api/calendar-post-events
    return event;
  }

  private async createAppleCalendarEvent(event: CalendarEvent): Promise<CalendarEvent> {
    // Implement Apple Calendar API integration
    // Documentation: https://developer.apple.com/documentation/calendarkit
    return event;
  }
}

export const calendarService = CalendarService.getInstance();