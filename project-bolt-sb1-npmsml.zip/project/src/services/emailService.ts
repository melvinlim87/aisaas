import { Appointment } from '../types/appointments';
import { Contact } from '../types/crm';
import { Ticket } from '../types/tickets';
import { Quotation } from '../types/crm';
import { Invoice } from '../types/crm';

interface EmailConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
  from: string;
  dnsSettings: {
    spfRecord: string;
    dkimSelector: string;
    dkimPrivateKey: string;
    dkimPublicKey: string;
    dmarcRecord: string;
  };
}

class EmailService {
  private static instance: EmailService;
  private config: EmailConfig | null = null;

  private constructor() {}

  public static getInstance(): EmailService {
    if (!EmailService.instance) {
      EmailService.instance = new EmailService();
    }
    return EmailService.instance;
  }

  public setConfig(config: EmailConfig) {
    this.config = config;
  }

  public async sendAppointmentConfirmation(appointment: Appointment, customer: Contact) {
    if (!this.config) throw new Error('Email configuration not set');

    const customerEmail = {
      to: customer.email,
      subject: 'Appointment Confirmation',
      html: `
        <h2>Appointment Confirmation</h2>
        <p>Dear ${customer.name},</p>
        <p>Your appointment has been confirmed:</p>
        <ul>
          <li>Date: ${appointment.date}</li>
          <li>Time: ${appointment.time}</li>
          <li>Sales Representative: ${appointment.salesRepName}</li>
          <li>Location: ${appointment.location.type === 'digital' ? 'Online Meeting' : 'In-Person'}</li>
          <li>Details: ${appointment.location.details}</li>
        </ul>
        <p>If you need to reschedule or cancel, please contact us.</p>
      `
    };

    const salesRepEmail = {
      to: appointment.salesRepId, // Assuming this is the email
      subject: 'New Appointment Scheduled',
      html: `
        <h2>New Appointment</h2>
        <p>A new appointment has been scheduled:</p>
        <ul>
          <li>Customer: ${customer.name}</li>
          <li>Date: ${appointment.date}</li>
          <li>Time: ${appointment.time}</li>
          <li>Location: ${appointment.location.type === 'digital' ? 'Online Meeting' : 'In-Person'}</li>
          <li>Details: ${appointment.location.details}</li>
        </ul>
      `
    };

    await Promise.all([
      this.sendEmail(customerEmail),
      this.sendEmail(salesRepEmail)
    ]);
  }

  public async sendTicketUpdate(ticket: Ticket) {
    if (!this.config) throw new Error('Email configuration not set');

    const email = {
      to: ticket.customer.email,
      subject: `Ticket Update - ${ticket.id}`,
      html: `
        <h2>Ticket Status Update</h2>
        <p>Dear ${ticket.customer.name},</p>
        <p>Your ticket has been updated:</p>
        <ul>
          <li>Ticket ID: ${ticket.id}</li>
          <li>Status: ${ticket.status}</li>
          <li>Subject: ${ticket.subject}</li>
          <li>Category: ${ticket.category}</li>
        </ul>
      `
    };

    await this.sendEmail(email);
  }

  public async sendQuotation(quotation: Quotation, customer: Contact) {
    if (!this.config) throw new Error('Email configuration not set');

    const email = {
      to: customer.email,
      subject: `Quotation - ${quotation.number}`,
      html: `
        <h2>Quotation</h2>
        <p>Dear ${customer.name},</p>
        <p>Please find your quotation details below:</p>
        <ul>
          <li>Quotation Number: ${quotation.number}</li>
          <li>Date: ${quotation.date}</li>
          <li>Valid Until: ${quotation.validUntil}</li>
          <li>Total Amount: $${quotation.total.toFixed(2)}</li>
        </ul>
        <p>Please review the attached quotation document.</p>
      `,
      attachments: [
        {
          filename: `quotation-${quotation.number}.pdf`,
          content: 'PDF_CONTENT' // Replace with actual PDF generation
        }
      ]
    };

    await this.sendEmail(email);
  }

  public async sendInvoice(invoice: Invoice, customer: Contact) {
    if (!this.config) throw new Error('Email configuration not set');

    const email = {
      to: customer.email,
      subject: `Invoice - ${invoice.number}`,
      html: `
        <h2>Invoice</h2>
        <p>Dear ${customer.name},</p>
        <p>Please find your invoice details below:</p>
        <ul>
          <li>Invoice Number: ${invoice.number}</li>
          <li>Date: ${invoice.date}</li>
          <li>Due Date: ${invoice.dueDate}</li>
          <li>Total Amount: $${invoice.total.toFixed(2)}</li>
        </ul>
        <p>Please review the attached invoice document.</p>
      `,
      attachments: [
        {
          filename: `invoice-${invoice.number}.pdf`,
          content: 'PDF_CONTENT' // Replace with actual PDF generation
        }
      ]
    };

    await this.sendEmail(email);
  }

  private async sendEmail({ to, subject, html, attachments }: {
    to: string;
    subject: string;
    html: string;
    attachments?: Array<{ filename: string; content: string }>;
  }) {
    if (!this.config) throw new Error('Email configuration not set');

    // Here you would implement the actual email sending logic
    // using a library like nodemailer or an email service API
    console.log('Sending email:', { to, subject, html, attachments });
  }
}

export const emailService = EmailService.getInstance();