import { ChatMessage } from '../types/chat';
import { generateResponse } from './deepinfra';
import { useChatStore } from '../store/chatStore';

class ChatbotService {
  async processMessage(message: string, type: 'internal' | 'external'): Promise<ChatMessage> {
    try {
      // Pass the type parameter to generateResponse
      const response = await generateResponse(message, null, 'llama-3', type);

      return {
        id: Date.now().toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date(),
        metadata: {
          source: type
        }
      };
    } catch (error) {
      console.error('Error processing message:', error);
      throw error;
    }
  }

  async testPrompt(systemPrompt: string, message: string): Promise<ChatMessage> {
    try {
      // Use internal type for testing to avoid credit deduction
      const response = await generateResponse(message, null, 'llama-3', 'internal');
      return {
        id: Date.now().toString(),
        content: response,
        role: 'assistant',
        timestamp: new Date(),
        metadata: {
          source: 'internal'
        }
      };
    } catch (error) {
      console.error('Error testing prompt:', error);
      throw error;
    }
  }

  async updateSystemPrompt(newPrompt: string): Promise<void> {
    const store = useChatStore.getState();
    await store.updateSettings({
      ...store.settings,
      advanced: {
        ...store.settings.advanced,
        systemPrompt: newPrompt
      }
    });
  }
}

export const chatbotService = new ChatbotService();