import { SubAccountBilling, BillingTransaction, CreditPurchase, BillingSettings, BillingOverview } from '../types/billing';
import { stripeService } from './stripe';
import { paypalService } from './paypal';

class BillingService {
  private static instance: BillingService;
  private mockBillings: Map<string, SubAccountBilling> = new Map();
  private mockTransactions: BillingTransaction[] = [];
  private mockPurchases: CreditPurchase[] = [];

  private constructor() {
    this.loadStoredData();
  }

  public static getInstance(): BillingService {
    if (!BillingService.instance) {
      BillingService.instance = new BillingService();
    }
    return BillingService.instance;
  }

  private loadStoredData(): void {
    const storedBillings = localStorage.getItem('sub_account_billings');
    const storedTransactions = localStorage.getItem('billing_transactions');
    const storedPurchases = localStorage.getItem('credit_purchases');

    if (storedBillings) {
      const billings = JSON.parse(storedBillings);
      Object.entries(billings).forEach(([id, billing]) => {
        this.mockBillings.set(id, {
          ...billing as SubAccountBilling,
          createdAt: new Date(billing.createdAt),
          updatedAt: new Date(billing.updatedAt)
        });
      });
    }

    if (storedTransactions) {
      this.mockTransactions = JSON.parse(storedTransactions).map((t: BillingTransaction) => ({
        ...t,
        createdAt: new Date(t.createdAt),
        updatedAt: new Date(t.updatedAt)
      }));
    }

    if (storedPurchases) {
      this.mockPurchases = JSON.parse(storedPurchases).map((p: CreditPurchase) => ({
        ...p,
        createdAt: new Date(p.createdAt),
        updatedAt: new Date(p.updatedAt)
      }));
    }
  }

  private persistData(): void {
    const billingsObj = Object.fromEntries(this.mockBillings);
    localStorage.setItem('sub_account_billings', JSON.stringify(billingsObj));
    localStorage.setItem('billing_transactions', JSON.stringify(this.mockTransactions));
    localStorage.setItem('credit_purchases', JSON.stringify(this.mockPurchases));
  }

  private getSubAccountName(subAccountId: string): string {
    const billing = this.mockBillings.get(subAccountId);
    return billing?.name || 'Unknown Sub-Account';
  }

  private calculateNextBillingDate(lastBillingDate: Date): Date {
    const nextDate = new Date(lastBillingDate);
    nextDate.setMonth(nextDate.getMonth() + 1);
    return nextDate;
  }

  private getSubAccountStatus(billing: SubAccountBilling): 'active' | 'overdue' | 'suspended' {
    const now = new Date();
    const lastBillingDate = new Date(billing.lastBillingDate);
    const gracePeriodEnd = new Date(lastBillingDate);
    gracePeriodEnd.setDate(gracePeriodEnd.getDate() + billing.gracePeriodDays);

    if (now > gracePeriodEnd) {
      return 'suspended';
    } else if (now > lastBillingDate) {
      return 'overdue';
    }
    return 'active';
  }

  public async getMasterAccountOverview(): Promise<BillingOverview> {
    try {
      const subAccounts = Array.from(this.mockBillings.values());
      
      const overview = {
        totalRevenue: subAccounts.reduce((sum, acc) => sum + acc.lastBillingAmount, 0),
        activeSubAccounts: subAccounts.filter(acc => this.getSubAccountStatus(acc) === 'active').length,
        totalCreditsUsed: subAccounts.reduce((sum, acc) => sum + acc.usageCredits, 0),
        recentTransactions: this.mockTransactions
          .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
          .slice(0, 10)
          .map(t => ({
            id: t.id,
            subAccountName: this.getSubAccountName(t.subAccountId),
            amount: t.amount,
            type: t.type,
            description: t.description,
            timestamp: t.createdAt
          })),
        subAccountStats: subAccounts.map(acc => ({
          id: acc.id,
          name: this.getSubAccountName(acc.id),
          creditsUsed: acc.usageCredits,
          lastBillingAmount: acc.lastBillingAmount,
          nextBillingDate: this.calculateNextBillingDate(acc.lastBillingDate),
          status: this.getSubAccountStatus(acc)
        }))
      };

      return overview;
    } catch (error) {
      console.error('Failed to get master account overview:', error);
      throw error;
    }
  }

  public async updatePaymentMethod(
    type: 'stripe' | 'paypal',
    data: { paymentMethodId?: string; subscriptionId?: string }
  ): Promise<void> {
    // Implementation for updating payment method
    console.log('Updating payment method:', { type, data });
  }
}

export const billingService = BillingService.getInstance();