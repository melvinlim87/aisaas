import { ConversationData } from '../../types/data';

const mockConversationData: ConversationData = {
  active: [
    {
      id: 'c1',
      client: 'John Smith',
      channel: 'web',
      lastMessage: 'Thanks for your help with the integration!',
      timestamp: new Date('2024-01-15T10:30:00')
    },
    {
      id: 'c2',
      client: 'Sarah Johnson',
      channel: 'whatsapp',
      lastMessage: 'When can we schedule a product demo?',
      timestamp: new Date('2024-01-15T11:15:00')
    },
    {
      id: 'c3',
      client: 'Alex Chen',
      channel: 'messenger',
      lastMessage: 'I need help with my subscription upgrade',
      timestamp: new Date('2024-01-15T09:45:00')
    },
    {
      id: 'c4',
      client: 'Maria Garcia',
      channel: 'instagram',
      lastMessage: 'Is there a mobile app available?',
      timestamp: new Date('2024-01-15T12:20:00')
    },
    {
      id: 'c5',
      client: 'David Wilson',
      channel: 'telegram',
      lastMessage: 'Having issues with the API endpoints',
      timestamp: new Date('2024-01-15T13:05:00')
    }
  ],
  resolved: [
    {
      id: 'c6',
      client: 'Mike Brown',
      channel: 'messenger',
      resolution: 'Issue resolved - product configured correctly',
      timestamp: new Date('2024-01-14T15:45:00')
    },
    {
      id: 'c7',
      client: 'Emma Taylor',
      channel: 'web',
      resolution: 'Successfully upgraded to premium plan',
      timestamp: new Date('2024-01-14T16:30:00')
    },
    {
      id: 'c8',
      client: 'James Anderson',
      channel: 'whatsapp',
      resolution: 'Technical support provided for integration',
      timestamp: new Date('2024-01-14T14:20:00')
    },
    {
      id: 'c9',
      client: 'Sophie Martin',
      channel: 'instagram',
      resolution: 'Feature request documented and forwarded to product team',
      timestamp: new Date('2024-01-14T11:15:00')
    },
    {
      id: 'c10',
      client: 'Lucas Rodriguez',
      channel: 'telegram',
      resolution: 'Account settings updated and verified',
      timestamp: new Date('2024-01-14T10:45:00')
    },
    {
      id: 'c11',
      client: 'Oliver White',
      channel: 'web',
      resolution: 'Password reset completed successfully',
      timestamp: new Date('2024-01-13T17:30:00')
    },
    {
      id: 'c12',
      client: 'Isabella Kim',
      channel: 'whatsapp',
      resolution: 'Billing issue resolved - refund processed',
      timestamp: new Date('2024-01-13T16:15:00')
    },
    {
      id: 'c13',
      client: 'William Lee',
      channel: 'messenger',
      resolution: 'New feature tutorial provided',
      timestamp: new Date('2024-01-13T15:20:00')
    },
    {
      id: 'c14',
      client: 'Ava Thompson',
      channel: 'instagram',
      resolution: 'Marketing collaboration details finalized',
      timestamp: new Date('2024-01-13T14:45:00')
    },
    {
      id: 'c15',
      client: 'Ethan Clark',
      channel: 'telegram',
      resolution: 'API documentation access granted',
      timestamp: new Date('2024-01-13T13:30:00')
    }
  ]
};

export const conversationsApi = {
  async getData(): Promise<ConversationData> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockConversationData;
  },

  async getConversation(id: string) {
    return [...mockConversationData.active, ...mockConversationData.resolved]
      .find(conversation => conversation.id === id);
  }
};