import { AppointmentData } from '../../types/data';

const mockAppointmentData: AppointmentData = {
  upcoming: [
    {
      id: 'a1',
      title: 'Product Demo',
      date: '2024-01-20',
      time: '10:00',
      client: 'Acme Corp',
      type: 'demo'
    },
    {
      id: 'a2',
      title: 'Initial Consultation',
      date: '2024-01-21',
      time: '14:00',
      client: 'TechStart Inc',
      type: 'consultation'
    }
  ],
  completed: [
    {
      id: 'a3',
      title: 'Follow-up Meeting',
      date: '2024-01-15',
      time: '11:00',
      client: 'Global Solutions',
      outcome: 'successful'
    }
  ],
  distribution: {
    'Completed': 85,
    'Cancelled': 10,
    'No-show': 5
  },
  completion: {
    'Product Demo': 92,
    'Consultation': 88,
    'Follow-up': 95,
    'Training': 90
  }
};

export const appointmentsApi = {
  async getData(): Promise<AppointmentData> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockAppointmentData;
  },

  async getAppointment(id: string) {
    return [...mockAppointmentData.upcoming, ...mockAppointmentData.completed]
      .find(appointment => appointment.id === id);
  }
};