import { AnalyticsData } from '../../types/data';

const mockAnalyticsData: AnalyticsData = {
  revenue: {
    daily: {
      '2024-01-15': 5000,
      '2024-01-14': 4500,
      '2024-01-13': 6000,
      '2024-01-12': 4800,
      '2024-01-11': 5200
    },
    monthly: {
      '2024-01': 150000,
      '2023-12': 145000,
      '2023-11': 138000
    },
    trends: [
      { metric: 'MRR', value: 50000, change: 0.15 },
      { metric: 'ARR', value: 600000, change: 0.12 },
      { metric: 'Churn Rate', value: 0.02, change: -0.01 }
    ]
  },
  conversations: {
    volume: {
      '2024-01-15': 125,
      '2024-01-14': 118,
      '2024-01-13': 132
    },
    satisfaction: {
      '2024-01-15': 4.8,
      '2024-01-14': 4.7,
      '2024-01-13': 4.9
    },
    responseTime: {
      '2024-01-15': 45,
      '2024-01-14': 52,
      '2024-01-13': 38
    }
  },
  appointments: {
    completion: {
      '2024-01': 0.95,
      '2023-12': 0.92,
      '2023-11': 0.94
    },
    cancellation: {
      '2024-01': 0.05,
      '2023-12': 0.08,
      '2023-11': 0.06
    },
    distribution: {
      'consultation': 0.4,
      'demo': 0.3,
      'follow-up': 0.2,
      'other': 0.1
    }
  }
};

export const analyticsApi = {
  async getData(): Promise<AnalyticsData> {
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockAnalyticsData;
  },

  async getRevenueMetrics() {
    return mockAnalyticsData.revenue;
  },

  async getConversationMetrics() {
    return mockAnalyticsData.conversations;
  },

  async getAppointmentMetrics() {
    return mockAnalyticsData.appointments;
  }
};