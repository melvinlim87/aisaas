import { CRMData } from '../../types/data';

// Mock CRM data for development
const mockCRMData: CRMData = {
  contacts: [
    {
      id: '1',
      name: 'John Smith',
      email: 'john@example.com',
      phone: '+1 234 567 890',
      lastContact: new Date('2024-01-15'),
      status: 'active'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      phone: '+1 234 567 891',
      lastContact: new Date('2024-01-14'),
      status: 'lead'
    }
  ],
  deals: [
    {
      id: 'd1',
      title: 'Enterprise Package',
      value: 50000,
      stage: 'negotiation',
      probability: 0.7
    },
    {
      id: 'd2',
      title: 'SMB Solution',
      value: 15000,
      stage: 'proposal',
      probability: 0.5
    }
  ]
};

export const crmApi = {
  async getData(): Promise<CRMData> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockCRMData;
  },

  async getContact(id: string) {
    return mockCRMData.contacts.find(contact => contact.id === id);
  },

  async getDeal(id: string) {
    return mockCRMData.deals.find(deal => deal.id === id);
  }
};