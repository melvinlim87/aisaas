import { Agent, Conversation, Ticket } from '../types/chat';

class SupportSystem {
  private agents: Map<string, Agent> = new Map();
  private tickets: Map<string, Ticket> = new Map();

  async handleHandoff(conversation: Conversation, reason: string): Promise<Ticket> {
    // Find available agent
    const agent = await this.findAvailableAgent(conversation);
    
    // Create ticket
    const ticket: Ticket = {
      id: `ticket_${Date.now()}`,
      conversationId: conversation.id,
      status: 'open',
      priority: this.determinePriority(conversation),
      createdAt: new Date(),
      updatedAt: new Date(),
      assignedTo: agent?.id,
      category: this.determineCategory(conversation),
      description: this.generateDescription(conversation, reason)
    };

    this.tickets.set(ticket.id, ticket);

    // Update conversation metadata
    conversation.metadata = {
      ...conversation.metadata,
      ticketId: ticket.id,
      agentId: agent?.id,
      handoffReason: reason
    };

    // Send notifications
    await this.sendNotifications(ticket, agent);

    return ticket;
  }

  private async findAvailableAgent(conversation: Conversation): Promise<Agent | undefined> {
    const availableAgents = Array.from(this.agents.values())
      .filter(agent => 
        agent.status === 'online' && 
        agent.currentLoad < 5 &&
        this.hasRequiredSkills(agent, conversation)
      )
      .sort((a, b) => a.currentLoad - b.currentLoad);

    return availableAgents[0];
  }

  private hasRequiredSkills(agent: Agent, conversation: Conversation): boolean {
    // Implement skill matching logic
    return true;
  }

  private determinePriority(conversation: Conversation): Ticket['priority'] {
    // Implement priority determination logic
    return 'medium';
  }

  private determineCategory(conversation: Conversation): string {
    // Implement category determination logic
    return 'general';
  }

  private generateDescription(conversation: Conversation, reason: string): string {
    return `Handoff requested: ${reason}\n\nConversation History:\n${
      conversation.messages
        .map(m => `${m.sender}: ${m.content}`)
        .join('\n')
    }`;
  }

  private async sendNotifications(ticket: Ticket, agent?: Agent): Promise<void> {
    if (agent) {
      // Send agent notification
      console.log(`Notifying agent ${agent.id} about ticket ${ticket.id}`);
    }

    // Send customer notification
    console.log(`Sending customer notification for ticket ${ticket.id}`);
  }
}

export const supportSystem = new SupportSystem();