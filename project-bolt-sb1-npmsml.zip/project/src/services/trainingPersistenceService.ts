import { TrainingData } from '../types/training';

class TrainingPersistenceService {
  private static instance: TrainingPersistenceService;
  private readonly STORAGE_KEY = 'ai_training_data';

  private constructor() {}

  public static getInstance(): TrainingPersistenceService {
    if (!TrainingPersistenceService.instance) {
      TrainingPersistenceService.instance = new TrainingPersistenceService();
    }
    return TrainingPersistenceService.instance;
  }

  public saveTrainingData(data: TrainingData): void {
    try {
      const existingData = this.getTrainingData();
      const updatedData = {
        ...existingData,
        ...data,
        lastUpdated: new Date().toISOString()
      };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedData));
    } catch (error) {
      console.error('Error saving training data:', error);
      throw new Error('Failed to save training data');
    }
  }

  public getTrainingData(): TrainingData {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      if (!data) return { documents: [], urls: [], lastUpdated: null };
      return JSON.parse(data);
    } catch (error) {
      console.error('Error retrieving training data:', error);
      return { documents: [], urls: [], lastUpdated: null };
    }
  }

  public clearTrainingData(): void {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing training data:', error);
      throw new Error('Failed to clear training data');
    }
  }

  public addTrainedDocument(document: { name: string; content: string }): void {
    try {
      const data = this.getTrainingData();
      data.documents.push({
        ...document,
        timestamp: new Date().toISOString()
      });
      this.saveTrainingData(data);
    } catch (error) {
      console.error('Error adding trained document:', error);
      throw new Error('Failed to add trained document');
    }
  }

  public addTrainedUrl(url: string, content: string): void {
    try {
      const data = this.getTrainingData();
      data.urls.push({
        url,
        content,
        timestamp: new Date().toISOString()
      });
      this.saveTrainingData(data);
    } catch (error) {
      console.error('Error adding trained URL:', error);
      throw new Error('Failed to add trained URL');
    }
  }

  public getTrainedDocuments(): TrainingData['documents'] {
    return this.getTrainingData().documents;
  }

  public getTrainedUrls(): TrainingData['urls'] {
    return this.getTrainingData().urls;
  }

  public removeTrainedDocument(name: string): void {
    try {
      const data = this.getTrainingData();
      data.documents = data.documents.filter(doc => doc.name !== name);
      this.saveTrainingData(data);
    } catch (error) {
      console.error('Error removing trained document:', error);
      throw new Error('Failed to remove trained document');
    }
  }

  public removeTrainedUrl(url: string): void {
    try {
      const data = this.getTrainingData();
      data.urls = data.urls.filter(item => item.url !== url);
      this.saveTrainingData(data);
    } catch (error) {
      console.error('Error removing trained URL:', error);
      throw new Error('Failed to remove trained URL');
    }
  }
}

export const trainingPersistenceService = TrainingPersistenceService.getInstance();