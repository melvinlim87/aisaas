import { AuthUser, LoginCredentials, PasswordChangeRequest, PasswordReset, SubAccountInvite } from '../types/auth';
import { emailService } from './emailService';
import toast from 'react-hot-toast';

class AuthService {
  private static instance: AuthService;
  private currentUser: AuthUser | null = null;

  private readonly MASTER_CREDENTIALS = {
    email: 'admin@example.com',
    password: 'Admin123!',
    role: 'owner'
  };

  private readonly SUB_ACCOUNT_CREDENTIALS = {
    email: 'john@companya.com',
    password: 'SubAccount123!',
    role: 'admin'
  };

  private constructor() {
    const storedUser = localStorage.getItem('auth_user');
    if (storedUser) {
      try {
        const parsed = JSON.parse(storedUser);
        this.currentUser = {
          ...parsed,
          lastLogin: new Date(parsed.lastLogin),
          createdAt: new Date(parsed.createdAt),
          updatedAt: new Date(parsed.updatedAt)
        };
      } catch (error) {
        console.error('Error parsing stored user:', error);
        localStorage.removeItem('auth_user');
      }
    }
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  public async login(credentials: LoginCredentials): Promise<AuthUser> {
    if (!credentials.email || !credentials.password) {
      throw new Error('Email and password are required');
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 500));

      let isValid = false;
      let userRole: AuthUser['role'] = 'viewer';
      let userName = '';

      if (credentials.subAccountId) {
        isValid = 
          credentials.email.toLowerCase() === this.SUB_ACCOUNT_CREDENTIALS.email.toLowerCase() && 
          credentials.password === this.SUB_ACCOUNT_CREDENTIALS.password;
        userRole = this.SUB_ACCOUNT_CREDENTIALS.role;
        userName = 'John Doe';
      } else {
        isValid = 
          credentials.email.toLowerCase() === this.MASTER_CREDENTIALS.email.toLowerCase() && 
          credentials.password === this.MASTER_CREDENTIALS.password;
        userRole = this.MASTER_CREDENTIALS.role;
        userName = 'Admin User';
      }

      if (!isValid) {
        throw new Error('Invalid credentials');
      }

      const user: AuthUser = {
        id: credentials.subAccountId || '1',
        email: credentials.email,
        name: userName,
        role: userRole,
        subAccountId: credentials.subAccountId,
        lastLogin: new Date(),
        createdAt: new Date(),
        updatedAt: new Date()
      };

      this.currentUser = user;
      localStorage.setItem('auth_user', JSON.stringify(user));
      return user;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }

  public async logout(): Promise<void> {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      this.currentUser = null;
      localStorage.removeItem('auth_user');
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  }

  public async changePassword(request: PasswordChangeRequest): Promise<void> {
    try {
      if (!this.currentUser) {
        throw new Error('Not authenticated');
      }

      if (!request.currentPassword || !request.newPassword || !request.confirmPassword) {
        throw new Error('All password fields are required');
      }

      if (request.newPassword !== request.confirmPassword) {
        throw new Error('Passwords do not match');
      }

      if (request.newPassword.length < 8) {
        throw new Error('New password must be at least 8 characters long');
      }

      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success('Password changed successfully');
    } catch (error) {
      console.error('Password change error:', error);
      throw error;
    }
  }

  public async requestPasswordReset(email: string): Promise<void> {
    try {
      if (!email) {
        throw new Error('Email is required');
      }

      const resetToken = Math.random().toString(36).substring(7);
      const resetUrl = `${window.location.origin}/reset-password?token=${resetToken}`;

      await emailService.sendPasswordResetEmail(email, resetUrl);
      toast.success('Password reset instructions sent to your email');
    } catch (error) {
      console.error('Password reset request error:', error);
      throw error;
    }
  }

  public async resetPassword(token: string, newPassword: string): Promise<void> {
    try {
      if (!token || !newPassword) {
        throw new Error('Token and new password are required');
      }

      if (newPassword.length < 8) {
        throw new Error('New password must be at least 8 characters long');
      }

      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success('Password reset successfully');
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  }

  public async inviteSubAccountUser(invite: Omit<SubAccountInvite, 'id' | 'token' | 'expiresAt' | 'accepted' | 'createdAt'>): Promise<void> {
    try {
      if (!invite.email || !invite.role || !invite.subAccountId) {
        throw new Error('Email, role, and sub-account ID are required');
      }

      const token = Math.random().toString(36).substring(7);
      const inviteUrl = `${window.location.origin}/sub-account/accept-invite?token=${token}`;

      await emailService.sendSubAccountInvite(invite.email, inviteUrl, invite.role);
      toast.success('Invitation sent successfully');
    } catch (error) {
      console.error('Sub-account invite error:', error);
      throw error;
    }
  }

  public getCurrentUser(): AuthUser | null {
    if (!this.currentUser) {
      const storedUser = localStorage.getItem('auth_user');
      if (storedUser) {
        try {
          const parsed = JSON.parse(storedUser);
          this.currentUser = {
            ...parsed,
            lastLogin: new Date(parsed.lastLogin),
            createdAt: new Date(parsed.createdAt),
            updatedAt: new Date(parsed.updatedAt)
          };
        } catch (error) {
          console.error('Error parsing stored user:', error);
          localStorage.removeItem('auth_user');
        }
      }
    }
    return this.currentUser;
  }

  public isAuthenticated(): boolean {
    return !!this.getCurrentUser();
  }

  public isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'owner' || user?.role === 'admin';
  }
}

export const authService = AuthService.getInstance();