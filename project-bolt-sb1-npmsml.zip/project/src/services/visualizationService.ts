import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

export async function generateVisualization(data: any) {
  // Generate chart configuration
  const config = {
    type: 'line',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Analytics Data',
        data: data.values,
        fill: false,
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }]
    },
    options: {
      responsive: true,
      animation: {
        duration: 1000,
        easing: 'easeInOutQuart'
      },
      plugins: {
        legend: {
          position: 'top',
        },
        title: {
          display: true,
          text: 'Analytics Visualization'
        }
      }
    }
  };

  return config;
}