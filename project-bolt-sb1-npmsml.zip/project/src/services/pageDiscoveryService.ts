import { fetchWithCorsProxy, validateUrl } from './corsProxyService';

export interface DiscoveredPage {
  url: string;
  displayPath: string;
  title: string;
  selected: boolean;
}

export async function discoverPages(url: string): Promise<DiscoveredPage[]> {
  try {
    // Validate URL format
    await validateUrl(url);

    // Clean and normalize the URL
    const baseUrl = new URL(url).origin;
    const normalizedUrl = url.endsWith('/') ? url.slice(0, -1) : url;

    console.log('Fetching content from:', normalizedUrl);
    const content = await fetchWithCorsProxy(normalizedUrl);
    
    if (!content) {
      throw new Error('No content received from the URL');
    }

    console.log('Parsing content...');
    const parser = new DOMParser();
    const doc = parser.parseFromString(content, 'text/html');
    
    if (!doc.documentElement) {
      throw new Error('Failed to parse HTML content');
    }

    // Check for common error patterns in the parsed content
    const errorNode = doc.querySelector('parsererror');
    if (errorNode) {
      throw new Error('Failed to parse HTML content: ' + errorNode.textContent);
    }

    // Always include the main page
    const mainPageTitle = doc.querySelector('title')?.textContent?.trim() || 'Home';
    const links: DiscoveredPage[] = [{
      url: normalizedUrl,
      displayPath: '/',
      title: mainPageTitle,
      selected: true
    }];

    console.log('Extracting links...');
    const discoveredLinks = Array.from(doc.querySelectorAll('a[href]'))
      .map(a => {
        try {
          const href = a.getAttribute('href');
          if (!href) return null;

          // Skip empty or invalid hrefs
          if (!href.trim() || href === '#') return null;

          // Handle relative URLs
          let absoluteUrl: string;
          try {
            // Handle different types of relative URLs
            if (href.startsWith('/')) {
              // Absolute path
              absoluteUrl = `${baseUrl}${href}`;
            } else if (href.startsWith('./') || href.startsWith('../')) {
              // Relative path
              absoluteUrl = new URL(href, normalizedUrl).toString();
            } else if (!href.startsWith('http')) {
              // Relative without ./ or ../
              absoluteUrl = `${baseUrl}/${href}`;
            } else {
              absoluteUrl = href;
            }
            
            // Normalize the URL
            absoluteUrl = new URL(absoluteUrl).toString();
          } catch {
            return null;
          }

          // Ensure URL is from the same domain
          if (!absoluteUrl.startsWith(baseUrl)) return null;

          // Skip anchor links and empty paths
          if (absoluteUrl === baseUrl || absoluteUrl === `${baseUrl}/`) return null;

          // Skip common file types and patterns
          if (/\.(jpg|jpeg|png|gif|pdf|zip|exe|dmg|pkg|mp4|avi|mp3)$/i.test(absoluteUrl)) return null;
          if (/^(mailto:|tel:|javascript:|data:)/i.test(absoluteUrl)) return null;

          const urlObj = new URL(absoluteUrl);
          const displayPath = urlObj.pathname + urlObj.search + urlObj.hash || '/';

          // Clean up the title
          let title = a.textContent?.trim();
          if (!title) {
            // Try to get title from aria-label or title attribute
            title = a.getAttribute('aria-label') || a.getAttribute('title');
          }
          if (!title) {
            // Generate title from path
            title = displayPath.split('/').pop()?.replace(/[-_]/g, ' ') || displayPath;
          }

          return {
            url: absoluteUrl,
            displayPath,
            title,
            selected: true
          };
        } catch (error) {
          console.warn('Error processing link:', error);
          return null;
        }
      })
      .filter((link): link is DiscoveredPage => 
        link !== null && 
        !links.some(existing => existing.url === link.url)
      );

    // Add discovered links to the array
    links.push(...discoveredLinks);

    // Remove duplicates and sort by path
    const uniqueLinks = links
      .filter((link, index, self) => 
        index === self.findIndex((t) => t.url === link.url)
      )
      .sort((a, b) => a.displayPath.localeCompare(b.displayPath));

    console.log(`Found ${uniqueLinks.length} valid links (including main page)`);

    if (uniqueLinks.length === 0) {
      throw new Error(
        'No valid pages discovered. This could be because:\n' +
        '- The website is blocking access\n' +
        '- The website has no discoverable links\n' +
        '- The content could not be properly parsed\n' +
        'Please check the URL and try again.'
      );
    }

    return uniqueLinks;

  } catch (error) {
    console.error('Error discovering pages:', error);
    throw error instanceof Error 
      ? error 
      : new Error('An unexpected error occurred while discovering pages');
  }
}