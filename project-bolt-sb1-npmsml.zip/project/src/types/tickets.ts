export interface Ticket {
  id: string;
  subject: string;
  description: string;
  status: 'active' | 'pending' | 'resolved' | 'closed';
  priority: 'high' | 'medium' | 'low';
  category: string;
  assignedTo: string;
  createdAt: Date;
  updatedAt: Date;
  customer: {
    name: string;
    email: string;
  };
}

export interface TicketAnalytics {
  total: number;
  active: number;
  pending: number;
  resolved: number;
  closed: number;
}