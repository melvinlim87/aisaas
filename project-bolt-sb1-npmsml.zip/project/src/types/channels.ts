export type Channel = 'web' | 'whatsapp' | 'messenger' | 'instagram' | 'telegram';

export interface ChannelConfig {
  id: Channel;
  name: string;
  enabled: boolean;
  credentials: {
    apiKey?: string;
    apiSecret?: string;
    accessToken?: string;
    verifyToken?: string;
  };
  webhook?: {
    url: string;
    secret: string;
  };
  settings: {
    autoReply?: boolean;
    welcomeMessage?: string;
    handoffThreshold?: number;
    maxQueueSize?: number;
  };
}

export interface MessageQueue {
  channel: Channel;
  messages: QueuedMessage[];
  rateLimits: {
    maxPerMinute: number;
    maxPerHour: number;
    current: number;
  };
}

export interface QueuedMessage {
  id: string;
  priority: number;
  message: string;
  metadata: any;
  retries: number;
  createdAt: Date;
  scheduledFor: Date;
}