export interface PayPalConfig {
  clientId: string;
  clientSecret: string;
  environment: 'sandbox' | 'production';
}

export interface SubAccountBilling {
  id: string;
  subAccountId: string;
  credits: number;
  usageCredits: number;
  autoReloadEnabled: boolean;
  autoReloadThreshold: number;
  autoReloadAmount: number;
  defaultPaymentMethod: 'stripe' | 'paypal';
  stripeCustomerId?: string;
  stripePaymentMethodId?: string;
  paypalSubscriptionId?: string;
  lastBillingDate: Date;
  lastBillingAmount: number;
  minimumBillAmount: number;
  billingCycle: 'monthly' | 'yearly';
  gracePeriodDays: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface BillingTransaction {
  id: string;
  subAccountId: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  metadata?: {
    aiModel?: string;
    promptTokens?: number;
    completionTokens?: number;
    purchaseId?: string;
    paymentMethod?: 'stripe' | 'paypal';
    paymentId?: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface CreditPurchase {
  id: string;
  subAccountId: string;
  amount: number;
  credits: number;
  status: 'pending' | 'completed' | 'failed';
  paymentMethod: 'stripe' | 'paypal';
  paymentId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface BillingSettings {
  creditCost: number;
  minPurchaseAmount: number;
  maxPurchaseAmount: number;
  autoReloadMin: number;
  autoReloadMax: number;
  billingCycle: 'monthly' | 'yearly';
  gracePeriod: number;
  paymentMethods: ('stripe' | 'paypal')[];
}