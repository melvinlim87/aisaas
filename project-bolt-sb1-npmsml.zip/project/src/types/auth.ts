export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: 'owner' | 'admin' | 'manager' | 'agent' | 'viewer';
  subAccountId?: string;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface SubAccountUser {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'agent' | 'viewer';
  subAccountId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PasswordReset {
  token: string;
  email: string;
  expiresAt: Date;
  used: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
  subAccountId?: string;
}

export interface PasswordChangeRequest {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface SubAccountInvite {
  id: string;
  email: string;
  role: 'admin' | 'manager' | 'agent' | 'viewer';
  subAccountId: string;
  token: string;
  expiresAt: Date;
  accepted: boolean;
  createdAt: Date;
}