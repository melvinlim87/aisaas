export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp: Date;
  metadata?: {
    source: 'internal' | 'external';
    analytics?: any;
    visualizations?: string[];
  };
}

export interface AdvancedSettings {
  temperature: number;
  maxTokens: number;
  topP: number;
  minP: number;
  topK: number;
  repetitionPenalty: number;
  presencePenalty: number;
  frequencyPenalty: number;
  responseFormat: 'text' | 'json_object';
  numResponses: number;
  stream: boolean;
  stopSequences?: string[];
}

export interface ChatbotConfig {
  type: 'internal' | 'external';
  name: string;
  systemPrompt: string;
  model: string;
  settings: AdvancedSettings;
  dataAccess: {
    crm: boolean;
    analytics: boolean;
    appointments: boolean;
    conversations: boolean;
    internal: boolean;
  };
}

export interface AnalyticsQuery {
  type: 'revenue' | 'conversations' | 'appointments' | 'custom';
  timeRange?: {
    start: Date;
    end: Date;
  };
  filters?: Record<string, any>;
  visualization?: 'bar' | 'line' | 'pie' | 'scatter';
}