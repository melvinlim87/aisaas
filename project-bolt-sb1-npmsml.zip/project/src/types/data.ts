export interface AppointmentData {
  upcoming: Array<{
    id: string;
    title: string;
    date: string;
    time: string;
    client: string;
    type: string;
  }>;
  completed: Array<{
    id: string;
    title: string;
    date: string;
    time: string;
    client: string;
    outcome: string;
  }>;
  distribution: {
    [key: string]: number;
  };
  completion: {
    [key: string]: number;
  };
}

// Rest of the types remain the same
export interface CRMData {
  contacts: Array<{
    id: string;
    name: string;
    email: string;
    phone: string;
    lastContact: Date;
    status: string;
  }>;
  deals: Array<{
    id: string;
    title: string;
    value: number;
    stage: string;
    probability: number;
  }>;
}

export interface ConversationData {
  active: Array<{
    id: string;
    client: string;
    channel: string;
    lastMessage: string;
    timestamp: Date;
  }>;
  resolved: Array<{
    id: string;
    client: string;
    channel: string;
    resolution: string;
    timestamp: Date;
  }>;
}

export interface AnalyticsData {
  revenue: {
    daily: Record<string, number>;
    monthly: Record<string, number>;
    trends: Array<{
      metric: string;
      value: number;
      change: number;
    }>;
  };
  conversations: {
    volume: Record<string, number>;
    satisfaction: Record<string, number>;
    responseTime: Record<string, number>;
  };
  appointments: {
    completion: Record<string, number>;
    cancellation: Record<string, number>;
    distribution: Record<string, number>;
  };
}