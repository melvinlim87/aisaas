export interface WalletBalance {
  amount: number;
  currency: string;
  updatedAt: Date;
  hasPaymentMethod: boolean;
  monthlyUsage: number;
  responseCount: number;
  averageCost: number;
}

export interface WalletTransaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: Date;
  metadata?: {
    aiModel?: string;
    promptTokens?: number;
    completionTokens?: number;
  };
}

export interface WalletSettings {
  lowBalanceAlert: number;
  autoReloadAmount: number;
  autoReloadEnabled: boolean;
  notificationEmail: string;
}