export interface ChatMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp: Date;
  model: string;
  cost: number;
}

export interface AIModel {
  id: string;
  name: string;
  provider: 'deepinfra' | 'openai';
  supportsVision: boolean;
  baseCost: number;
  markup: number;
}

export interface TextGenerationConfig {
  role?: string;
  max_new_tokens?: number;
  temperature?: number;
  top_p?: number;
  min_p?: number;
  top_k?: number;
  repetition_penalty?: number;
  presence_penalty?: number;
  frequency_penalty?: number;
  response_format?: { type: 'text' | 'json_object' };
  num_responses?: number;
  stream?: boolean;
  stop?: string[];
}

export enum PromptCategory {
  General = 'general',
  Vision = 'vision',
  Coding = 'coding',
  Writing = 'writing'
}

export interface PromptTemplate {
  id: string;
  category: PromptCategory;
  template: string;
  description: string;
}