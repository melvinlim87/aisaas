export interface SalesRep {
  id: string;
  name: string;
  email: string;
  availability: {
    start: string;
    end: string;
    days: number[]; // 0 = Sunday, 1 = Monday, etc.
  };
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'sales_rep' | 'user';
  createdAt: string;
  lastActive: string;
}

export interface UserRole {
  id: string;
  name: string;
  permissions: string[];
}

export const RESOURCE_LABELS = {
  DASHBOARD: 'Dashboard',
  CHATBOT: 'AI Chat',
  CRM: 'Customer Management',
  KNOWLEDGE_BASE: 'Knowledge Base',
  APPOINTMENTS: 'Appointments',
  AI_SETTINGS: 'AI Settings',
  SUBSCRIPTION: 'Subscription',
  SUB_ACCOUNTS: 'Sub-Accounts',
  ADMIN_SETTINGS: 'Admin Settings',
  CONVERSATIONS: 'Conversations',
  SUPPORT_TICKETS: 'Support Tickets',
  USER_MANAGEMENT: 'User Management'
} as const;

export type ResourceType = keyof typeof RESOURCE_LABELS;

export const PERMISSIONS = {
  VIEW: 'view',
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  MANAGE_USERS: 'manage_users',
  MANAGE_ROLES: 'manage_roles',
  MANAGE_SETTINGS: 'manage_settings',
  MANAGE_BILLING: 'manage_billing',
  ASSIGN_TICKETS: 'assign_tickets',
  UPDATE_TICKETS: 'update_tickets',
  VIEW_ANALYTICS: 'view_analytics'
} as const;

export type Permission = keyof typeof PERMISSIONS;

export interface RolePermission {
  resource: ResourceType;
  actions: Permission[];
}

export interface UserRoleWithPermissions extends UserRole {
  permissions: RolePermission[];
}