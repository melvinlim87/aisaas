export interface TrainedDocument {
  name: string;
  content: string;
  timestamp: string;
}

export interface TrainedUrl {
  url: string;
  content: string;
  timestamp: string;
}

export interface TrainingData {
  documents: TrainedDocument[];
  urls: TrainedUrl[];
  lastUpdated: string | null;
}