export interface UsageQuota {
  maxResponses: number;
  maxCredits: number;
  maxUsers: number;
  maxStorage: number; // in MB
}

export interface ActivityLog {
  id: string;
  subAccountId: string;
  action: 'login' | 'settings_change' | 'api_call' | 'credit_usage' | 'status_change';
  description: string;
  performedBy: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface AlertConfig {
  usageThreshold: number; // percentage
  creditThreshold: number;
  inactivityPeriod: number; // hours
  recipients: string[];
  channels: {
    email: boolean;
    slack: boolean;
    webhook: boolean;
  };
}

export interface SubAccountWithFeatures {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'paused';
  usage: {
    responses: number;
    credits: number;
    activeUsers: number;
    lastActive: Date;
    storage: number; // in MB
  };
  url: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  billingSettings: {
    autoReloadEnabled: boolean;
    autoReloadThreshold: number;
    autoReloadAmount: number;
  };
  credentials?: {
    username: string;
    passwordHash: string;
    lastUpdated: Date;
  };
  analytics: {
    monthlyActiveUsers: number;
    totalConversations: number;
    avgResponseTime: number;
    satisfactionRate: number;
  };
  quotas: UsageQuota;
  alerts: AlertConfig;
  features: {
    aiTraining: boolean;
    customization: boolean;
    apiAccess: boolean;
    dataExport: boolean;
    multiUser: boolean;
  };
  securitySettings: {
    ipWhitelist: string[];
    mfa: boolean;
    sessionTimeout: number; // minutes
    passwordPolicy: {
      minLength: number;
      requireSpecialChars: boolean;
      requireNumbers: boolean;
      expiryDays: number;
    };
  };
}