export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant' | 'system';
  timestamp: Date;
  channel?: Channel;
  attachments?: Attachment[];
}

export interface Conversation {
  id: string;
  messages: Message[];
  channel: Channel;
  status: ConversationStatus;
  createdAt: Date;
  updatedAt: Date;
  userId?: string;
  agentId?: string;
  metadata?: Record<string, any>;
}

export interface Ticket {
  id: string;
  conversationId: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'urgent' | 'high' | 'medium' | 'low';
  category: string;
  description: string;
  createdAt: Date;
  updatedAt: Date;
  assignedTo?: string;
  metadata?: Record<string, any>;
}

export interface Attachment {
  id: string;
  type: 'image' | 'file' | 'audio' | 'video';
  url: string;
  name: string;
  size: number;
  mimeType: string;
}

export type Channel = 'web' | 'whatsapp' | 'messenger' | 'instagram' | 'telegram';
export type ConversationStatus = 'active' | 'pending' | 'resolved' | 'closed';