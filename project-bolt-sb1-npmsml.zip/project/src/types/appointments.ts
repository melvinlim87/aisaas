export interface Appointment {
  id: number;
  title: string;
  date: string;
  time: string;
  salesRepId: string;
  salesRepName: string;
  location: {
    type: 'digital' | 'physical';
    details: string;
  };
  remarks: string;
}