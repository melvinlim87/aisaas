export const chartConfigs = {
  revenue: {
    type: 'line' as const,
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [{
        label: 'Revenue',
        data: [30000, 35000, 32000, 38000, 42000, 45000],
        borderColor: 'rgb(139, 92, 246)', // Purple-500
        backgroundColor: (context: any) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
          if (!chartArea) return;
          
          const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
          gradient.addColorStop(0, 'rgba(139, 92, 246, 0.1)'); // Purple-500
          gradient.addColorStop(1, 'rgba(45, 212, 191, 0.4)'); // Teal-400
          return gradient;
        },
        fill: true,
        tension: 0.4,
        borderWidth: 3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false
        },
        legend: {
          position: 'top' as const,
          align: 'end' as const
        }
      },
      scales: {
        y: {
          grid: {
            color: 'rgba(139, 92, 246, 0.1)'
          },
          beginAtZero: true
        },
        x: {
          grid: {
            display: false
          }
        }
      }
    }
  },

  conversations: {
    type: 'pie' as const,
    data: {
      labels: ['Active', 'Resolved', 'Pending', 'Closed'],
      datasets: [{
        data: [35, 45, 10, 10],
        backgroundColor: [
          'rgba(139, 92, 246, 0.8)', // Purple-500
          'rgba(45, 212, 191, 0.8)', // Teal-400
          'rgba(167, 139, 250, 0.8)', // Purple-400
          'rgba(94, 234, 212, 0.8)' // Teal-300
        ],
        borderWidth: 2,
        borderColor: 'rgba(255, 255, 255, 0.8)'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false
        },
        legend: {
          position: 'right' as const,
          labels: {
            boxWidth: 12,
            padding: 15
          }
        }
      },
      layout: {
        padding: {
          left: 10,
          right: 10
        }
      }
    }
  },

  appointments: {
    type: 'bar' as const,
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
      datasets: [{
        label: 'Scheduled',
        data: [12, 15, 8, 10, 14],
        backgroundColor: (context: any) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
          if (!chartArea) return;
          
          const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
          gradient.addColorStop(0, 'rgba(139, 92, 246, 0.8)'); // Purple-500
          gradient.addColorStop(1, 'rgba(45, 212, 191, 0.8)'); // Teal-400
          return gradient;
        },
        borderRadius: 6,
        borderWidth: 0,
        maxBarThickness: 40
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false
        },
        legend: {
          position: 'top' as const,
          align: 'end' as const
        }
      },
      scales: {
        y: {
          grid: {
            color: 'rgba(139, 92, 246, 0.1)'
          },
          beginAtZero: true,
          suggestedMax: 20
        },
        x: {
          grid: {
            display: false
          }
        }
      }
    }
  },

  satisfaction: {
    type: 'line' as const,
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [{
        label: 'Satisfaction Score',
        data: [4.2, 4.4, 4.3, 4.6],
        borderColor: 'rgb(45, 212, 191)', // Teal-400
        backgroundColor: (context: any) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
          if (!chartArea) return;
          
          const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
          gradient.addColorStop(0, 'rgba(45, 212, 191, 0.1)'); // Teal-400
          gradient.addColorStop(1, 'rgba(139, 92, 246, 0.4)'); // Purple-500
          return gradient;
        },
        fill: true,
        tension: 0.4,
        borderWidth: 3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false
        },
        legend: {
          position: 'top' as const,
          align: 'end' as const
        }
      },
      scales: {
        y: {
          min: 0,
          max: 5,
          grid: {
            color: 'rgba(45, 212, 191, 0.1)'
          }
        },
        x: {
          grid: {
            display: false
          }
        }
      }
    }
  }
};