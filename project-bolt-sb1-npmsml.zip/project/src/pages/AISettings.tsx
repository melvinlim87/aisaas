import React, { useState } from 'react';
import { Brain, Upload, Link, Settings, Book } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import TrainingMetrics from '../components/TrainingMetrics';
import FileUpload from '../components/FileUpload';
import UrlTraining from '../components/UrlTraining';
import SystemPromptGuide from '../components/SystemPromptGuide';
import toast from 'react-hot-toast';

const AISettings = () => {
  const { settings, updateSettings } = useChatStore();
  const [activeTab, setActiveTab] = useState('metrics');
  const [isSaving, setIsSaving] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      await updateSettings(settings);
      toast.success('AI training settings saved successfully');
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  };

  const cardClass = "bg-white/5 backdrop-blur-lg rounded-lg p-6 border border-indigo-100/10";
  const tabButtonClass = (isActive: boolean) => `
    px-4 py-2 rounded-lg transition-all duration-200
    ${isActive 
      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg'
      : 'bg-white/10 text-gray-400 hover:bg-white/20'}
  `;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center">
          <Brain className="h-6 w-6 mr-2" />
          AI Training
        </h2>
        <button
          onClick={() => setShowGuide(true)}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:opacity-90 flex items-center"
        >
          <Book className="h-5 w-5 mr-2" />
          View AIVA Guide
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-4">
        <button
          onClick={() => setActiveTab('metrics')}
          className={tabButtonClass(activeTab === 'metrics')}
        >
          <Brain className="h-5 w-5 inline-block mr-2" />
          Training Metrics
        </button>
        <button
          onClick={() => setActiveTab('files')}
          className={tabButtonClass(activeTab === 'files')}
        >
          <Upload className="h-5 w-5 inline-block mr-2" />
          File Upload
        </button>
        <button
          onClick={() => setActiveTab('url')}
          className={tabButtonClass(activeTab === 'url')}
        >
          <Link className="h-5 w-5 inline-block mr-2" />
          URL Training
        </button>
        <button
          onClick={() => setActiveTab('config')}
          className={tabButtonClass(activeTab === 'config')}
        >
          <Settings className="h-5 w-5 inline-block mr-2" />
          Advanced Config
        </button>
      </div>

      {/* Tab Content */}
      <div className={cardClass}>
        {activeTab === 'metrics' && <TrainingMetrics />}
        
        {activeTab === 'files' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Train with Files</h3>
            <FileUpload onTrainingComplete={() => toast.success('Training completed successfully')} />
            <div className="mt-4 p-4 bg-indigo-50 rounded-lg">
              <h4 className="font-medium text-indigo-900 mb-2">Training Tips</h4>
              <ul className="list-disc pl-5 space-y-2 text-sm text-indigo-800">
                <li>Upload PDF, DOC, DOCX, or TXT files containing your training data</li>
                <li>Files should be well-structured and contain relevant information</li>
                <li>Maximum file size: 10MB per file</li>
                <li>Supported languages: English, Spanish, French, German</li>
              </ul>
            </div>
          </div>
        )}
        
        {activeTab === 'url' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Train with URL</h3>
            <UrlTraining onTrainingComplete={() => toast.success('Training completed successfully')} />
            <div className="mt-4 p-4 bg-indigo-50 rounded-lg">
              <h4 className="font-medium text-indigo-900 mb-2">URL Training Tips</h4>
              <ul className="list-disc pl-5 space-y-2 text-sm text-indigo-800">
                <li>Enter URLs of knowledge base articles or documentation</li>
                <li>The system will crawl and extract relevant information</li>
                <li>Make sure the content is publicly accessible</li>
                <li>Training depth can be configured in advanced settings</li>
              </ul>
            </div>
          </div>
        )}

        {activeTab === 'config' && (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Advanced Configuration</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Temperature</label>
                <input
                  type="number"
                  value={settings.advanced.temperature}
                  onChange={(e) => updateSettings({
                    ...settings,
                    advanced: { ...settings.advanced, temperature: parseFloat(e.target.value) }
                  })}
                  step="0.1"
                  min="0"
                  max="2"
                  className="w-full rounded-lg border-gray-300"
                />
                <p className="mt-1 text-xs text-gray-500">Controls response randomness (0-2)</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Tokens</label>
                <input
                  type="number"
                  value={settings.advanced.maxTokens}
                  onChange={(e) => updateSettings({
                    ...settings,
                    advanced: { ...settings.advanced, maxTokens: parseInt(e.target.value) }
                  })}
                  min="1"
                  max="2048"
                  className="w-full rounded-lg border-gray-300"
                />
                <p className="mt-1 text-xs text-gray-500">Maximum length of generated responses</p>
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={handleSave}
                disabled={isSaving}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-500 hover:to-purple-500 disabled:opacity-50"
              >
                {isSaving ? 'Saving...' : 'Save Configuration'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* System Prompt Guide Modal */}
      <SystemPromptGuide isOpen={showGuide} onClose={() => setShowGuide(false)} />
    </div>
  );
};

export default AISettings;