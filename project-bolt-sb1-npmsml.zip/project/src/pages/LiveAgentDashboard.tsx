import React from 'react';
import AgentDashboard from '../components/LiveChatAgent/AgentDashboard';

const LiveAgentDashboard: React.FC = () => {
  return (
    <div className="h-[calc(100vh-4rem)]">
      <AgentDashboard />
    </div>
  );
};

export default LiveAgentDashboard;