import React, { useState } from 'react';
import { Bot, Code, Globe, Copy, Check, Command, Link } from 'lucide-react';
import toast from 'react-hot-toast';
import ExternalChatInterface from '../components/ExternalChatInterface';

const ExternalChatbot: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'system' | 'file' | 'url' | 'metrics' | 'embed'>('chat');
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [allowedDomains, setAllowedDomains] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const embedCode = `<!-- AI Chatbot Widget -->
<div id="ai-chatbot-widget" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;">
  <iframe 
    src="${window.location.origin}/external-chat"
    width="380"
    height="600"
    style="border: none; border-radius: 10px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);"
    allow="microphone"
    title="Chat Support"
  ></iframe>
</div>`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    toast.success('Embed code copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center">
          <Bot className="h-8 w-8 mr-3" />
          External AI Chat & Training
        </h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
          View Training Guide
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-4 border-b">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'chat'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Bot className="h-5 w-5 mr-2" />
          Chat Interface
        </button>
        <button
          onClick={() => setActiveTab('system')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'system'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Command className="h-5 w-5 mr-2" />
          System Prompt
        </button>
        <button
          onClick={() => setActiveTab('file')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'file'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Code className="h-5 w-5 mr-2" />
          File Training
        </button>
        <button
          onClick={() => setActiveTab('url')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'url'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Link className="h-5 w-5 mr-2" />
          URL Training
        </button>
        <button
          onClick={() => setActiveTab('metrics')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'metrics'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Globe className="h-5 w-5 mr-2" />
          Training Metrics
        </button>
        <button
          onClick={() => setActiveTab('embed')}
          className={`flex items-center px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'embed'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Code className="h-5 w-5 mr-2" />
          Embed Widget
        </button>
      </div>

      {/* Content */}
      {activeTab === 'embed' && (
        <div className="space-y-6">
          {/* Embed Code Section */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Code className="h-5 w-5 mr-2 text-indigo-600" />
              Widget Embed Code
            </h2>
            <p className="text-gray-600 mb-4">
              Add the AI chat widget to your website by copying and pasting the following code snippet.
            </p>
            
            <div className="relative">
              <pre className="bg-gray-50 rounded-lg p-4 text-sm font-mono overflow-x-auto">
                {embedCode}
              </pre>
              <button
                onClick={handleCopyCode}
                className="absolute top-2 right-2 p-2 bg-white rounded-lg shadow hover:bg-gray-50"
              >
                {copied ? (
                  <Check className="h-5 w-5 text-green-500" />
                ) : (
                  <Copy className="h-5 w-5 text-gray-500" />
                )}
              </button>
            </div>

            <button
              onClick={handleCopyCode}
              className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
            >
              <Code className="h-5 w-5 mr-2" />
              Copy Embed Code
            </button>
          </div>

          {/* Widget Settings */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Globe className="h-5 w-5 mr-2 text-indigo-600" />
              Widget Settings
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Widget Visibility
                </label>
                <select
                  value={visibility}
                  onChange={(e) => setVisibility(e.target.value as 'public' | 'private')}
                  className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                >
                  <option value="public">Public - Anyone can use it</option>
                  <option value="private">Private - Only specific domains</option>
                </select>
              </div>

              {visibility === 'private' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Allowed Domains (one per line)
                  </label>
                  <textarea
                    value={allowedDomains}
                    onChange={(e) => setAllowedDomains(e.target.value)}
                    className="w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    rows={3}
                    placeholder="example.com&#10;subdomain.example.com"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Preview */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Widget Preview</h2>
            <div className="relative h-[600px] border rounded-lg overflow-hidden">
              <ExternalChatInterface embedded={true} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExternalChatbot;