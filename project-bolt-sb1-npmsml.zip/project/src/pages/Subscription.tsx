import React from 'react';
import { CreditCard, Check } from 'lucide-react';

const Subscription = () => {
  const plans = [
    { name: 'Starter', price: 49, responses: 1000, features: ['1 Sub-account', 'Basic support', 'API access'] },
    { name: 'Pro', price: 99, responses: 5000, features: ['5 Sub-accounts', 'Priority support', 'API access', 'Custom branding'] },
    { name: 'Enterprise', price: 299, responses: 20000, features: ['Unlimited Sub-accounts', '24/7 support', 'API access', 'Custom branding', 'Dedicated account manager'] },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Subscription Plans</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <div key={plan.name} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900">{plan.name}</h2>
              <p className="mt-4 text-4xl font-bold text-indigo-600">${plan.price}<span className="text-base font-normal text-gray-500">/month</span></p>
              <p className="mt-2 text-gray-500">{plan.responses.toLocaleString()} AI responses included</p>
              <ul className="mt-6 space-y-4">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-6 w-6 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="px-6 py-4 bg-gray-50">
              <button className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition duration-150 ease-in-out">
                Choose Plan
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="bg-white rounded-lg shadow-lg p-6 mt-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Additional AI Responses</h2>
        <p className="text-gray-600 mb-4">Need more AI responses? Purchase additional responses at any time.</p>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-lg font-semibold">$0.01 per response</p>
            <p className="text-sm text-gray-500">Billed at the end of each month</p>
          </div>
          <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition duration-150 ease-in-out flex items-center">
            <CreditCard className="h-5 w-5 mr-2" />
            Add Responses
          </button>
        </div>
      </div>
    </div>
  );
};

export default Subscription;