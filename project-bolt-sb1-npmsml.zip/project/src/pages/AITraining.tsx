import React, { useState } from 'react';
import { Bot, Upload, Link as LinkIcon, Brain, Code, Book, Command, Globe } from 'lucide-react';
import ExternalChatInterface from '../components/ExternalChatInterface';
import FileUploadTraining from '../components/FileUploadTraining';
import UrlTraining from '../components/UrlTraining';
import TrainingMetrics from '../components/TrainingMetrics';
import AITrainingGuide from '../components/AITrainingGuide';
import SystemPromptEditor from '../components/SystemPromptEditor';
import EmbedCodeGenerator from '../components/EmbedCodeGenerator';
import toast from 'react-hot-toast';

const AITraining: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'file-training' | 'url-training' | 'metrics' | 'prompt' | 'embed'>('chat');
  const [showGuide, setShowGuide] = useState(false);

  const handleTrainingComplete = () => {
    toast.success('Training completed successfully');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'file-training':
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold text-indigo-900 mb-4">File Training Tips</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-indigo-800 mb-2">Document Preparation</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-indigo-700">
                    <li>Use clear, descriptive headings</li>
                    <li>Break content into logical sections</li>
                    <li>Include relevant examples</li>
                    <li>Keep information concise</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-indigo-800 mb-2">Best Practices</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-indigo-700">
                    <li>Upload files under 10MB</li>
                    <li>Use PDF for formatted content</li>
                    <li>Split large documents</li>
                    <li>Test after training</li>
                  </ul>
                </div>
              </div>
            </div>
            <FileUploadTraining onTrainingComplete={handleTrainingComplete} />
          </div>
        );
      case 'url-training':
        return (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold text-indigo-900 mb-4">URL Training Tips</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-indigo-800 mb-2">URL Selection</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-indigo-700">
                    <li>Choose stable, permanent URLs</li>
                    <li>Focus on documentation pages</li>
                    <li>Include FAQ and help pages</li>
                    <li>Add product/service pages</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-indigo-800 mb-2">Content Quality</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm text-indigo-700">
                    <li>Verify content accuracy</li>
                    <li>Check page accessibility</li>
                    <li>Ensure content relevance</li>
                    <li>Monitor for updates</li>
                  </ul>
                </div>
              </div>
            </div>
            <UrlTraining onTrainingComplete={handleTrainingComplete} />
          </div>
        );
      case 'metrics':
        return <TrainingMetrics />;
      case 'prompt':
        return <SystemPromptEditor />;
      case 'embed':
        return <EmbedCodeGenerator />;
      default:
        return <ExternalChatInterface />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center">
          <Bot className="h-8 w-8 mr-3" />
          External AI Chat & Training
        </h1>
        <button
          onClick={() => setShowGuide(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
        >
          <Book className="h-5 w-5 mr-2" />
          View Training Guide
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex space-x-4 border-b">
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'chat'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Bot className="h-5 w-5 mr-2" />
            Chat Interface
          </div>
        </button>
        <button
          onClick={() => setActiveTab('prompt')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'prompt'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Command className="h-5 w-5 mr-2" />
            System Prompt
          </div>
        </button>
        <button
          onClick={() => setActiveTab('file-training')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'file-training'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Upload className="h-5 w-5 mr-2" />
            File Training
          </div>
        </button>
        <button
          onClick={() => setActiveTab('url-training')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'url-training'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <LinkIcon className="h-5 w-5 mr-2" />
            URL Training
          </div>
        </button>
        <button
          onClick={() => setActiveTab('metrics')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'metrics'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Brain className="h-5 w-5 mr-2" />
            Training Metrics
          </div>
        </button>
        <button
          onClick={() => setActiveTab('embed')}
          className={`px-4 py-2 border-b-2 transition-colors ${
            activeTab === 'embed'
              ? 'border-indigo-500 text-indigo-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center">
            <Globe className="h-5 w-5 mr-2" />
            Embed Widget
          </div>
        </button>
      </div>

      {/* Content Area */}
      <div className="bg-white rounded-lg shadow-lg">
        <div className={`${activeTab === 'chat' ? 'h-[calc(100vh-12rem)]' : 'p-6'}`}>
          {renderContent()}
        </div>
      </div>

      {/* Training Guide Modal */}
      {showGuide && <AITrainingGuide onClose={() => setShowGuide(false)} />}
    </div>
  );
};

export default AITraining;