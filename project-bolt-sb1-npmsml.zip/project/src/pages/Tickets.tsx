import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';
import { Ticket } from '../types/tickets';
import TicketAnalytics from '../components/tickets/TicketAnalytics';
import TicketFilters from '../components/tickets/TicketFilters';
import TicketTable from '../components/tickets/TicketTable';

const Tickets: React.FC = () => {
  const [tickets] = useState<Ticket[]>([
    {
      id: 'TKT-001',
      subject: 'Integration Issue',
      description: 'Having trouble with API integration',
      status: 'active',
      priority: 'high',
      category: 'Technical',
      assignedTo: 'John Doe',
      createdAt: new Date('2024-01-15T10:00:00'),
      updatedAt: new Date('2024-01-15T11:00:00'),
      customer: {
        name: 'Alice Brown',
        email: 'alice@example.com'
      }
    },
    {
      id: 'TKT-002',
      subject: 'Billing Question',
      description: 'Need clarification on recent charges',
      status: 'pending',
      priority: 'medium',
      category: 'Billing',
      assignedTo: 'Jane Smith',
      createdAt: new Date('2024-01-15T09:00:00'),
      updatedAt: new Date('2024-01-15T09:30:00'),
      customer: {
        name: 'Bob Wilson',
        email: 'bob@example.com'
      }
    }
  ]);

  const [analytics] = useState({
    total: 150,
    active: 45,
    pending: 25,
    resolved: 60,
    closed: 20
  });

  const [filters, setFilters] = useState({
    status: 'all',
    priority: 'all',
    category: 'all',
    assignedTo: 'all',
    dateRange: {
      start: '',
      end: ''
    }
  });

  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Support Tickets</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center">
          <MessageSquare className="h-5 w-5 mr-2" />
          New Ticket
        </button>
      </div>

      <TicketAnalytics analytics={analytics} />

      <TicketFilters
        filters={filters}
        searchTerm={searchTerm}
        onFilterChange={setFilters}
        onSearchChange={setSearchTerm}
      />

      <TicketTable tickets={tickets} />
    </div>
  );
};

export default Tickets;