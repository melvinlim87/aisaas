import React from 'react';
import { authService } from '../services/authService';
import AIUsageWallet from './AIUsageWallet';
import SubAccountBillingOverview from '../components/wallet/SubAccountBillingOverview';

const Wallet: React.FC = () => {
  const user = authService.getCurrentUser();

  // If master account, show sub-account billing overview
  if (!user?.subAccountId) {
    return <SubAccountBillingOverview />;
  }

  // For sub-accounts, show AI usage wallet
  return <AIUsageWallet />;
};

export default Wallet;