import React, { useState, useEffect } from 'react';
import { Wallet, CreditCard, ArrowUpRight, ArrowDownRight, Settings, AlertCircle } from 'lucide-react';
import { useWalletStore } from '../store/walletStore';
import { WalletTransaction } from '../types/wallet';
import { authService } from '../services/authService';
import PaymentMethodForm from '../components/wallet/PaymentMethodForm';
import WalletTopUp from '../components/wallet/WalletTopUp';
import WalletSettings from '../components/wallet/WalletSettings';
import { walletService } from '../services/walletService';
import toast from 'react-hot-toast';

const AIUsageWallet: React.FC = () => {
  const { balance, transactions, setBalance, setTransactions } = useWalletStore();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showTopUp, setShowTopUp] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showPaymentMethod, setShowPaymentMethod] = useState(false);
  const user = authService.getCurrentUser();

  useEffect(() => {
    loadWalletData();
  }, []);

  const loadWalletData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const [walletBalance, walletTransactions] = await Promise.all([
        walletService.getBalance(),
        walletService.getTransactions()
      ]);
      setBalance(walletBalance);
      setTransactions(walletTransactions);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to load wallet data';
      console.error('Error loading wallet data:', error);
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h2 className="text-lg font-medium text-gray-900 mb-2">Error Loading Wallet</h2>
        <p className="text-gray-500">{error}</p>
        <button
          onClick={loadWalletData}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
        >
          Retry
        </button>
      </div>
    );
  }

  // Only show payment method setup if no payment method is configured
  const needsPaymentMethod = !balance?.hasPaymentMethod;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900 flex items-center">
          <Wallet className="h-8 w-8 mr-3" />
          AI Usage Wallet
        </h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowSettings(true)}
            className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 flex items-center"
          >
            <Settings className="h-5 w-5 mr-2" />
            Settings
          </button>
          <button
            onClick={() => needsPaymentMethod ? setShowPaymentMethod(true) : setShowTopUp(true)}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
          >
            <CreditCard className="h-5 w-5 mr-2" />
            {needsPaymentMethod ? 'Add Payment Method' : 'Top Up'}
          </button>
        </div>
      </div>

      {/* Balance Card */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-lg font-medium text-gray-700">Current Balance</h2>
            <p className="text-3xl font-bold text-gray-900 mt-2">
              {balance ? formatCurrency(balance.amount) : '$0.00'}
            </p>
          </div>
          {balance && balance.amount < 5 && (
            <div className="flex items-center text-amber-600 bg-amber-50 px-4 py-2 rounded-lg">
              <AlertCircle className="h-5 w-5 mr-2" />
              Low Balance Warning
            </div>
          )}
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Last updated: {balance?.updatedAt.toLocaleString()}
        </p>
      </div>

      {/* Usage Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-medium mb-2">Monthly Usage</h3>
          <p className="text-2xl font-bold">{balance?.monthlyUsage || 0} credits</p>
        </div>
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-medium mb-2">Response Count</h3>
          <p className="text-2xl font-bold">{balance?.responseCount || 0}</p>
        </div>
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h3 className="text-lg font-medium mb-2">Average Cost</h3>
          <p className="text-2xl font-bold">${balance?.averageCost?.toFixed(4) || '0.00'}</p>
        </div>
      </div>

      {/* Transactions */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Transaction History</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {transactions.length > 0 ? (
            transactions.map((transaction) => (
              <div key={transaction.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {transaction.type === 'credit' ? (
                      <ArrowUpRight className="h-5 w-5 text-green-500 mr-3" />
                    ) : (
                      <ArrowDownRight className="h-5 w-5 text-red-500 mr-3" />
                    )}
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {transaction.description}
                      </p>
                      <p className="text-sm text-gray-500">
                        {transaction.createdAt.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${
                      transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {transaction.type === 'credit' ? '+' : '-'}
                      {formatCurrency(transaction.amount)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {transaction.status}
                    </p>
                  </div>
                </div>
                {transaction.metadata && (
                  <div className="mt-2 text-xs text-gray-500">
                    {transaction.metadata.aiModel && (
                      <span className="mr-3">Model: {transaction.metadata.aiModel}</span>
                    )}
                    {transaction.metadata.promptTokens && (
                      <span className="mr-3">Prompt Tokens: {transaction.metadata.promptTokens}</span>
                    )}
                    {transaction.metadata.completionTokens && (
                      <span>Completion Tokens: {transaction.metadata.completionTokens}</span>
                    )}
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-gray-500">
              No transactions yet
            </div>
          )}
        </div>
      </div>

      {/* Payment Method Modal */}
      {showPaymentMethod && (
        <PaymentMethodForm
          subAccountId={user?.subAccountId || ''}
          onSuccess={() => {
            setShowPaymentMethod(false);
            loadWalletData();
          }}
          onClose={() => setShowPaymentMethod(false)}
        />
      )}

      {/* Top Up Modal */}
      {showTopUp && (
        <WalletTopUp
          onClose={() => setShowTopUp(false)}
          onSuccess={() => {
            setShowTopUp(false);
            loadWalletData();
          }}
        />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <WalletSettings
          onClose={() => setShowSettings(false)}
          onSave={() => {
            setShowSettings(false);
            loadWalletData();
          }}
        />
      )}
    </div>
  );
};

export default AIUsageWallet;