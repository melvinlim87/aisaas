import React, { useState } from 'react';
import { Shield, Globe, Users, CreditCard, Key, Mail, Calendar, Info } from 'lucide-react';
import UserRoleSettings from '../components/UserRoleSettings';
import IntegrationSettings from '../components/IntegrationSettings';
import LiveAgentTransferSettings from '../components/LiveAgentTransferSettings';
import StripeSettings from '../components/StripeSettings';
import EmailSettings from '../components/EmailSettings';
import CalendarProviderSettings from '../components/CalendarProviderSettings';
import AboutAndLogs from '../pages/AboutAndLogs';

const AdminSettings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('roles');

  const tabs = [
    { id: 'roles', label: 'User Roles', icon: Shield },
    { id: 'channels', label: 'Channel Integrations', icon: Globe },
    { id: 'transfer', label: 'Live Agent Transfer', icon: Users },
    { id: 'payments', label: 'Payment Settings', icon: CreditCard },
    { id: 'email', label: 'Email Settings', icon: Mail },
    { id: 'calendar', label: 'Calendar Settings', icon: Calendar },
    { id: 'api', label: 'API Settings', icon: Key },
    { id: 'about', label: 'About & Logs', icon: Info }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Admin Settings</h1>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex items-center py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === tab.id
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
            >
              <tab.icon className="h-5 w-5 mr-2" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="mt-6">
        {activeTab === 'roles' && <UserRoleSettings />}
        {activeTab === 'channels' && <IntegrationSettings />}
        {activeTab === 'transfer' && <LiveAgentTransferSettings />}
        {activeTab === 'payments' && <StripeSettings />}
        {activeTab === 'email' && <EmailSettings />}
        {activeTab === 'calendar' && <CalendarProviderSettings />}
        {activeTab === 'about' && <AboutAndLogs />}
        {activeTab === 'api' && (
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">API Settings</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">API Key</label>
                <input
                  type="password"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  placeholder="••••••••••••••••"
                  readOnly
                />
              </div>
              <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
                Generate New API Key
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminSettings;