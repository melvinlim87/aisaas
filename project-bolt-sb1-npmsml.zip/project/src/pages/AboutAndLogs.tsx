import React, { useState } from 'react';
import { Info, GitCommit, Package, Bug, Star, Clock, Mail, MessageSquare } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const AboutAndLogs: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'about' | 'changelog'>('about');
  const version = "1.2.0";
  const buildDate = "January 16, 2024";

  const features = [
    { icon: Package, name: 'AI Chatbot', description: 'Intelligent conversational AI with multi-channel support' },
    { icon: Star, name: 'CRM Integration', description: 'Full-featured customer relationship management' },
    { icon: Clock, name: 'Real-time Analytics', description: 'Live metrics and customizable dashboards' }
  ];

  return (
    <div className="space-y-6">
      {/* Version Info Card */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI Chatbot CRM</h2>
            <p className="text-sm text-gray-500 mt-1">Version {version} • Built {buildDate}</p>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setActiveTab('about')}
              className={`px-4 py-2 rounded-lg ${
                activeTab === 'about'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Info className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTab('changelog')}
              className={`px-4 py-2 rounded-lg ${
                activeTab === 'changelog'
                  ? 'bg-indigo-100 text-indigo-700'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <GitCommit className="h-5 w-5" />
            </button>
          </div>
        </div>

        {activeTab === 'about' ? (
          <div className="space-y-8">
            {/* Key Features */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Key Features</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {features.map((feature, index) => (
                  <div key={index} className="bg-gray-50 rounded-lg p-4">
                    <feature.icon className="h-8 w-8 text-indigo-600 mb-3" />
                    <h4 className="font-medium text-gray-900">{feature.name}</h4>
                    <p className="text-sm text-gray-500 mt-1">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* System Information */}
            <div>
              <h3 className="text-lg font-semibold mb-4">System Information</h3>
              <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Version</span>
                  <span className="font-medium">{version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Build Date</span>
                  <span className="font-medium">{buildDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Environment</span>
                  <span className="font-medium">Production</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">License</span>
                  <span className="font-medium">Commercial</span>
                </div>
              </div>
            </div>

            {/* Support Information */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                <p className="text-gray-600">
                  For support inquiries, please contact our team through one of the following channels:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <a href="#" className="flex items-center p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <Mail className="h-5 w-5 text-indigo-600 mr-3" />
                    <div>
                      <div className="font-medium">Email Support</div>
                      <div className="text-sm text-gray-500">support@example.com</div>
                    </div>
                  </a>
                  <a href="#" className="flex items-center p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                    <MessageSquare className="h-5 w-5 text-indigo-600 mr-3" />
                    <div>
                      <div className="font-medium">Live Chat</div>
                      <div className="text-sm text-gray-500">Available 24/7</div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="prose max-w-none">
                <ReactMarkdown>
                  {`# Changelog

## [1.2.0] - 2024-01-16

### Added
- About & Logs section moved to main navigation panel for easier access
- Improved changelog tracking system
- Enhanced user interface for system updates and logs
- Real-time update notifications for new features
- Streamlined navigation structure

### Changed
- Relocated About & Logs from Admin Settings to main sidebar
- Updated navigation hierarchy for better accessibility
- Improved user experience for viewing system updates
- Enhanced changelog organization and readability

## [1.1.0] - 2024-01-15

### Added
- User authentication system with login, logout, and password reset
- Sub-account user management with role-based access control
- Email-based invitation system for sub-account users
- Password change functionality for existing users
- Protected routes requiring authentication
- User profile management
- Role-based permissions system
- Sub-account user invitation and acceptance flow
- Email notifications for password resets and invitations

### Changed
- Updated header component to include user profile menu
- Enhanced sub-account management with user list and permissions
- Improved routing system with authentication guards

### Fixed
- Fixed issue with session persistence after page reload
- Corrected sub-account permission inheritance
- Fixed email template rendering issues

## [1.0.0] - 2024-01-01

### Added
- Initial release with core features
- AI-powered chatbot integration
- CRM system with contact management
- Knowledge base functionality
- Appointment scheduling system
- Analytics dashboard with real-time metrics
- Multi-channel conversation support
- Live agent dashboard
- Ticket management system
- Custom chart builder
- Theme customization options
- Workflow automation tools
- Calendar integration
- Email notification system
- File upload and training capabilities
- Real-time chat interface
- Support for multiple chat channels (web, WhatsApp, Messenger, Instagram)`}
                </ReactMarkdown>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AboutAndLogs;