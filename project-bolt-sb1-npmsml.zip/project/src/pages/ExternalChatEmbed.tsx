import React from 'react';
import ExternalChatWidget from '../components/ExternalChatWidget';

const ExternalChatEmbed: React.FC = () => {
  return (
    <div className="h-screen bg-transparent">
      <ExternalChatWidget embedded={true} />
    </div>
  );
};

export default ExternalChatEmbed;