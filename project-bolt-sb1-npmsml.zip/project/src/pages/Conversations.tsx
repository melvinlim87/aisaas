import React, { useState } from 'react';
import { MessageCircle, Search, Filter, Calendar, User, ArrowRight, X, MessageSquare, Phone, Mail, Clock, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { Conversation, Channel } from '../types/chat';
import ConversationView from '../components/ConversationView';
import toast from 'react-hot-toast';

interface Analytics {
  total: number;
  active: number;
  pending: number;
  resolved: number;
  closed: number;
  byChannel: Record<Channel, number>;
}

const Conversations: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: '1',
      messages: [
        { id: 'm1', content: 'Hello! How can I help you today?', role: 'assistant', timestamp: new Date('2024-01-15T10:00:00') },
        { id: 'm2', content: 'I need help with my subscription', role: 'user', timestamp: new Date('2024-01-15T10:01:00') }
      ],
      channel: 'web',
      status: 'active',
      createdAt: new Date('2024-01-15T10:00:00'),
      updatedAt: new Date('2024-01-15T10:01:00'),
      userId: 'user123',
      agentId: 'agent456'
    },
    {
      id: '2',
      messages: [
        { id: 'm3', content: 'Hi, I have a question about pricing', role: 'user', timestamp: new Date('2024-01-15T11:00:00') }
      ],
      channel: 'whatsapp',
      status: 'pending',
      createdAt: new Date('2024-01-15T11:00:00'),
      updatedAt: new Date('2024-01-15T11:00:00'),
      userId: 'user789'
    },
    {
      id: '3',
      messages: [
        { id: 'm4', content: 'Issue with login', role: 'user', timestamp: new Date('2024-01-14T15:00:00') },
        { id: 'm5', content: 'Issue resolved', role: 'assistant', timestamp: new Date('2024-01-14T15:30:00') }
      ],
      channel: 'messenger',
      status: 'resolved',
      createdAt: new Date('2024-01-14T15:00:00'),
      updatedAt: new Date('2024-01-14T15:30:00'),
      userId: 'user456',
      agentId: 'agent789'
    },
    {
      id: '4',
      messages: [
        { id: 'm6', content: 'Product inquiry', role: 'user', timestamp: new Date('2024-01-14T09:00:00') }
      ],
      channel: 'instagram',
      status: 'closed',
      createdAt: new Date('2024-01-14T09:00:00'),
      updatedAt: new Date('2024-01-14T10:00:00'),
      userId: 'user234',
      agentId: 'agent123'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [channelFilter, setChannelFilter] = useState<Channel | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'pending' | 'resolved' | 'closed'>('all');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);

  // Calculate analytics from conversations
  const analytics: Analytics = {
    total: conversations.length,
    active: conversations.filter(c => c.status === 'active').length,
    pending: conversations.filter(c => c.status === 'pending').length,
    resolved: conversations.filter(c => c.status === 'resolved').length,
    closed: conversations.filter(c => c.status === 'closed').length,
    byChannel: conversations.reduce((acc, conv) => {
      acc[conv.channel] = (acc[conv.channel] || 0) + 1;
      return acc;
    }, {} as Record<Channel, number>)
  };

  const getChannelIcon = (channel: Channel) => {
    switch (channel) {
      case 'web':
        return <MessageSquare className="h-5 w-5 text-blue-500" />;
      case 'whatsapp':
        return <Phone className="h-5 w-5 text-green-500" />;
      case 'messenger':
        return <MessageCircle className="h-5 w-5 text-purple-500" />;
      case 'instagram':
        return <Mail className="h-5 w-5 text-pink-500" />;
      default:
        return <MessageSquare className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: Conversation['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'resolved':
        return 'bg-blue-100 text-blue-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredConversations = conversations.filter(conversation => {
    const matchesChannel = channelFilter === 'all' || conversation.channel === channelFilter;
    const matchesStatus = statusFilter === 'all' || conversation.status === statusFilter;
    const matchesSearch = searchTerm === '' || 
      conversation.messages.some(msg => 
        msg.content.toLowerCase().includes(searchTerm.toLowerCase())
      );
    
    return matchesChannel && matchesStatus && matchesSearch;
  });

  const handleSendMessage = async (content: string) => {
    if (!selectedConversation) return;

    try {
      const newMessage = {
        id: `m${Date.now()}`,
        content,
        role: 'assistant' as const,
        timestamp: new Date()
      };

      setSelectedConversation(prev => prev ? {
        ...prev,
        messages: [...prev.messages, newMessage],
        updatedAt: new Date()
      } : null);

      setConversations(prev => prev.map(conv => 
        conv.id === selectedConversation.id 
          ? { ...conv, messages: [...conv.messages, newMessage], updatedAt: new Date() }
          : conv
      ));

      toast.success('Message sent successfully');
    } catch (error) {
      toast.error('Failed to send message');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Conversations</h1>
        <div className="flex space-x-2">
          <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Analytics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <div className="bg-white rounded-lg shadow p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="bg-indigo-50 p-2 rounded-lg">
              <MessageCircle className="h-5 w-5 text-indigo-500" />
            </div>
            <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
              Total
            </span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-semibold text-gray-900">{analytics.total}</p>
            <p className="text-sm text-gray-500">Total Conversations</p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="bg-green-50 p-2 rounded-lg">
              <Clock className="h-5 w-5 text-green-500" />
            </div>
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
              Active
            </span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-semibold text-gray-900">{analytics.active}</p>
            <p className="text-sm text-gray-500">Active</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="bg-yellow-50 p-2 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
            </div>
            <span className="text-xs font-medium text-yellow-600 bg-yellow-50 px-2 py-0.5 rounded-full">
              Pending
            </span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-semibold text-gray-900">{analytics.pending}</p>
            <p className="text-sm text-gray-500">Pending</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="bg-blue-50 p-2 rounded-lg">
              <CheckCircle className="h-5 w-5 text-blue-500" />
            </div>
            <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              Resolved
            </span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-semibold text-gray-900">{analytics.resolved}</p>
            <p className="text-sm text-gray-500">Resolved</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="bg-gray-50 p-2 rounded-lg">
              <XCircle className="h-5 w-5 text-gray-500" />
            </div>
            <span className="text-xs font-medium text-gray-600 bg-gray-50 px-2 py-0.5 rounded-full">
              Closed
            </span>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-semibold text-gray-900">{analytics.closed}</p>
            <p className="text-sm text-gray-500">Closed</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow-lg rounded-lg p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search conversations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>

          {/* Channel Filter */}
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value as Channel | 'all')}
            className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Channels</option>
            <option value="web">Website</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="messenger">Messenger</option>
            <option value="instagram">Instagram</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'pending' | 'resolved' | 'closed')}
            className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>

          {/* Date Range */}
          <div className="flex space-x-2">
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="border rounded-lg p-2 focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Conversations List */}
      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Channel</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Message</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Agent</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredConversations.map((conversation) => (
                <tr key={conversation.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getChannelIcon(conversation.channel)}
                      <span className="ml-2 capitalize">{conversation.channel}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(conversation.status)}`}>
                      {conversation.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 truncate max-w-xs">
                      {conversation.messages[conversation.messages.length - 1]?.content}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <User className="h-5 w-5 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-900">User {conversation.userId}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {conversation.agentId || 'Unassigned'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {conversation.createdAt.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button 
                      onClick={() => setSelectedConversation(conversation)}
                      className="text-blue-600 hover:text-blue-900 flex items-center"
                    >
                      View <ArrowRight className="h-4 w-4 ml-1" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Conversation Modal */}
      {selectedConversation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg w-full max-w-4xl h-[80vh] flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <div className="flex items-center">
                {getChannelIcon(selectedConversation.channel)}
                <h2 className="text-xl font-semibold ml-2">Conversation Details</h2>
                <span className={`ml-4 px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(selectedConversation.status)}`}>
                  {selectedConversation.status}
                </span>
                <span className="ml-4 text-sm text-gray-500 flex items-center">
                  via {selectedConversation.channel}
                </span>
              </div>
              <button 
                onClick={() => setSelectedConversation(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="flex-1 overflow-hidden">
              <ConversationView 
                conversation={selectedConversation}
                onSendMessage={handleSendMessage}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Conversations;