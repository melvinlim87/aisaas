import React, { useState } from 'react';
import { Search, Plus, FileText, Upload, File } from 'lucide-react';
import { toast } from 'react-hot-toast';

const KnowledgeBase = () => {
  const [articles, setArticles] = useState([
    { id: 1, title: "Getting Started with Our Platform", category: "Onboarding" },
    { id: 2, title: "How to Use the AI Chatbot", category: "Features" },
    { id: 3, title: "Managing Your CRM Contacts", category: "CRM" },
    { id: 4, title: "Scheduling and Managing Appointments", category: "Appointments" },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [isDragging, setIsDragging] = useState(false);

  const handleFileDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    await processFiles(files);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    await processFiles(files);
  };

  const processFiles = async (files: File[]) => {
    for (const file of files) {
      if (file.type === 'application/pdf' || file.type === 'text/plain') {
        try {
          // Here you would implement the actual file processing logic
          toast.success(`Processing ${file.name}`);
          // Simulated processing delay
          await new Promise(resolve => setTimeout(resolve, 1000));
          toast.success(`Successfully processed ${file.name}`);
        } catch (error) {
          toast.error(`Error processing ${file.name}`);
        }
      } else {
        toast.error(`Unsupported file type: ${file.name}`);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Knowledge Base</h1>
        <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          New Article
        </button>
      </div>

      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search knowledge base..."
          className="w-full p-3 pl-10 pr-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
      </div>

      {/* File Upload Section */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleFileDrop}
      >
        <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Upload Training Materials</h3>
        <p className="text-gray-500 mb-4">Drag and drop PDF or text files here, or click to select files</p>
        <input
          type="file"
          id="file-upload"
          className="hidden"
          multiple
          accept=".pdf,.txt"
          onChange={handleFileSelect}
        />
        <button
          onClick={() => document.getElementById('file-upload')?.click()}
          className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center mx-auto"
        >
          <File className="h-5 w-5 mr-2" />
          Select Files
        </button>
      </div>

      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <ul className="divide-y divide-gray-200">
          {articles
            .filter(article => 
              article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
              article.category.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .map((article) => (
              <li key={article.id} className="p-4 hover:bg-gray-50">
                <a href="#" className="flex items-center">
                  <FileText className="h-6 w-6 text-gray-400 mr-3" />
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{article.title}</h3>
                    <p className="text-sm text-gray-500">{article.category}</p>
                  </div>
                </a>
              </li>
            ))}
        </ul>
      </div>
    </div>
  );
};

export default KnowledgeBase;