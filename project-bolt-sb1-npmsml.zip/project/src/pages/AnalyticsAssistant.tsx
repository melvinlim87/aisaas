import React, { useState } from 'react';
import { BrainCircuit, Code, Bot, Book } from 'lucide-react';
import DualChatInterface from '../components/DualChatInterface';
import PromptEditor from '../components/PromptEditor';

const AnalyticsAssistant: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'chat' | 'training'>('chat');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <BrainCircuit className="h-6 w-6 text-indigo-600 mr-2" />
          <h1 className="text-3xl font-bold text-gray-900">AI Analytics Assistant</h1>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-4 py-2 rounded-lg flex items-center ${
              activeTab === 'chat'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Bot className="h-5 w-5 mr-2" />
            Chat Interface
          </button>
          <button
            onClick={() => setActiveTab('training')}
            className={`px-4 py-2 rounded-lg flex items-center ${
              activeTab === 'training'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Code className="h-5 w-5 mr-2" />
            Training & Prompts
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg h-[calc(100vh-12rem)]">
        {activeTab === 'chat' ? (
          <DualChatInterface />
        ) : (
          <PromptEditor />
        )}
      </div>
    </div>
  );
};

export default AnalyticsAssistant;