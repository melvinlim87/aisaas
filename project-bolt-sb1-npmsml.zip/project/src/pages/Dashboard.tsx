import React, { useState, useRef, useEffect } from 'react';
import { TrendingUp, Users, MessageSquare, Calendar, Settings, BarChart } from 'lucide-react';
import GridLayout from 'react-grid-layout';
import StatCard from '../components/dashboard/StatCard';
import ChartWidget from '../components/dashboard/ChartWidget';
import ActivityWidget from '../components/dashboard/ActivityWidget';
import AnalyticsWidget from '../components/dashboard/AnalyticsWidget';
import CustomChartsWidget from '../components/CustomChartsWidget';
import useDashboardLayout from '../hooks/useDashboardLayout';
import { chartConfigs } from '../config/chartConfigs';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';

const Dashboard: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [containerWidth, setContainerWidth] = useState(1200);
  const { layout, isCustomizing, handleLayoutChange, toggleCustomizing } = useDashboardLayout();

  useEffect(() => {
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.offsetWidth);
      }
    };

    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, []);

  const recentActivity = [
    { id: 1, type: 'conversation', title: 'New conversation started', time: '5 minutes ago' },
    { id: 2, type: 'appointment', title: 'Appointment scheduled', time: '15 minutes ago' },
    { id: 3, type: 'analytics', title: 'Revenue report generated', time: '1 hour ago' },
    { id: 4, type: 'crm', title: 'New contact added', time: '2 hours ago' },
  ];

  const gradientButtonClass = `
    flex items-center px-4 py-2 rounded-lg text-white
    bg-gradient-to-r from-indigo-600 to-purple-600
    hover:from-indigo-500 hover:to-purple-500
    focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
    transition-all duration-200 shadow-lg
    hover:shadow-xl
  `;

  return (
    <div className="space-y-6" ref={containerRef}>
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <button
          onClick={toggleCustomizing}
          className={`${gradientButtonClass} ${
            isCustomizing ? 'from-purple-600 to-indigo-600' : ''
          }`}
        >
          <Settings className="h-5 w-5 mr-2" />
          {isCustomizing ? 'Save Layout' : 'Customize Layout'}
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          icon={TrendingUp}
          iconColor="text-blue-500"
          title="Revenue"
          value="$24,500"
          change="+12% from last month"
          changeType="positive"
        />
        <StatCard
          icon={Users}
          iconColor="text-green-500"
          title="Active Users"
          value="1,234"
          change="+5% from last week"
          changeType="positive"
        />
        <StatCard
          icon={MessageSquare}
          iconColor="text-purple-500"
          title="Conversations"
          value="892"
          change="+8% from yesterday"
          changeType="positive"
        />
        <StatCard
          icon={Calendar}
          iconColor="text-red-500"
          title="Appointments"
          value="45"
          change="Same as last week"
          changeType="neutral"
        />
      </div>

      {/* AI Analytics Assistant */}
      <div className="mb-6">
        <AnalyticsWidget isCustomizing={isCustomizing} />
      </div>

      {/* Draggable Widgets */}
      <GridLayout
        className={`layout ${isCustomizing ? 'customizing' : ''}`}
        layout={layout}
        cols={12}
        rowHeight={150}
        width={containerWidth}
        isDraggable={isCustomizing}
        isResizable={isCustomizing}
        onLayoutChange={handleLayoutChange}
        draggableHandle=".drag-handle"
        margin={[16, 16]}
      >
        <div key="revenue">
          <ChartWidget
            title="Revenue Overview"
            config={chartConfigs.revenue}
            isCustomizing={isCustomizing}
            icon={BarChart}
          />
        </div>

        <div key="conversations">
          <ChartWidget
            title="Conversation Status"
            config={chartConfigs.conversations}
            isCustomizing={isCustomizing}
            icon={BarChart}
          />
        </div>

        <div key="appointments">
          <ChartWidget
            title="Weekly Appointments"
            config={chartConfigs.appointments}
            isCustomizing={isCustomizing}
            icon={BarChart}
          />
        </div>

        <div key="satisfaction">
          <ChartWidget
            title="Customer Satisfaction"
            config={chartConfigs.satisfaction}
            isCustomizing={isCustomizing}
            icon={BarChart}
          />
        </div>

        <div key="activity">
          <ActivityWidget
            activities={recentActivity}
            isCustomizing={isCustomizing}
          />
        </div>

        <div key="custom-charts">
          <CustomChartsWidget 
            isCustomizing={isCustomizing}
            gradientButtonClass={gradientButtonClass}
          />
        </div>
      </GridLayout>
    </div>
  );
};

export default Dashboard;