import React, { useState, useEffect } from 'react';
import { Plus, Users } from 'lucide-react';
import CalendarView from '../components/Calendar/CalendarView';
import { Appointment } from '../types/appointments';
import { SalesRep } from '../types/user';
import { userService } from '../services/userService';
import SalesRepModal from '../components/SalesRepModal';
import CalendarEventModal from '../components/Calendar/CalendarEventModal';
import toast from 'react-hot-toast';

const Appointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: 1,
      title: "Client Meeting",
      date: "2024-01-15",
      time: "10:00",
      salesRepId: "1",
      salesRepName: "John Doe",
      location: {
        type: "digital",
        details: "Google Meet"
      },
      remarks: "Initial consultation"
    }
  ]);

  const [salesReps, setSalesReps] = useState<SalesRep[]>([]);
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [showSalesRepModal, setShowSalesRepModal] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | undefined>();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [calendarView, setCalendarView] = useState<'daily' | 'weekly' | 'monthly'>('monthly');

  useEffect(() => {
    loadSalesReps();
  }, []);

  const loadSalesReps = async () => {
    try {
      const reps = await userService.getSalesReps();
      setSalesReps(reps);
    } catch (error) {
      console.error('Error loading sales reps:', error);
      toast.error('Failed to load sales representatives');
    }
  };

  const handleSalesRepAdded = (newRep: SalesRep) => {
    setSalesReps([...salesReps, newRep]);
    toast.success('Sales representative added successfully');
  };

  const handleAppointmentCreate = (appointmentData: Omit<Appointment, 'id'>) => {
    const newAppointment = {
      ...appointmentData,
      id: appointments.length + 1
    };
    setAppointments([...appointments, newAppointment]);
    setShowAppointmentModal(false);
    toast.success('Appointment created successfully');
  };

  const handleAppointmentUpdate = (updatedAppointment: Appointment) => {
    setAppointments(appointments.map(app => 
      app.id === updatedAppointment.id ? updatedAppointment : app
    ));
    setShowAppointmentModal(false);
    toast.success('Appointment updated successfully');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Appointments</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowSalesRepModal(true)}
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center"
          >
            <Users className="h-5 w-5 mr-2" />
            Manage Sales Reps
          </button>
          <button
            onClick={() => {
              setSelectedAppointment(undefined);
              setShowAppointmentModal(true);
            }}
            className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
          >
            <Plus className="h-5 w-5 mr-2" />
            New Appointment
          </button>
        </div>
      </div>

      <div className="flex justify-center space-x-4 mb-4">
        <button
          onClick={() => setCalendarView('daily')}
          className={`px-4 py-2 rounded-lg ${
            calendarView === 'daily' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          Daily
        </button>
        <button
          onClick={() => setCalendarView('weekly')}
          className={`px-4 py-2 rounded-lg ${
            calendarView === 'weekly' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          Weekly
        </button>
        <button
          onClick={() => setCalendarView('monthly')}
          className={`px-4 py-2 rounded-lg ${
            calendarView === 'monthly' ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          Monthly
        </button>
      </div>

      <CalendarView
        view={calendarView}
        currentDate={currentDate}
        appointments={appointments}
        onDateChange={setCurrentDate}
        onAppointmentClick={(appointment) => {
          setSelectedAppointment(appointment);
          setShowAppointmentModal(true);
        }}
        salesReps={salesReps}
        onAppointmentCreate={handleAppointmentCreate}
        onAppointmentUpdate={handleAppointmentUpdate}
      />

      {/* Appointment Modal */}
      {showAppointmentModal && (
        <CalendarEventModal
          isOpen={showAppointmentModal}
          onClose={() => {
            setShowAppointmentModal(false);
            setSelectedAppointment(undefined);
          }}
          onSave={selectedAppointment ? handleAppointmentUpdate : handleAppointmentCreate}
          editingEvent={selectedAppointment}
          salesReps={salesReps}
        />
      )}

      {/* Sales Rep Modal */}
      {showSalesRepModal && (
        <SalesRepModal
          isOpen={showSalesRepModal}
          onClose={() => setShowSalesRepModal(false)}
          onSalesRepAdded={handleSalesRepAdded}
          currentSalesReps={salesReps}
        />
      )}
    </div>
  );
};

export default Appointments;