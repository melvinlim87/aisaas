import React, { useState } from 'react';
import { Plus, Edit, Trash2, X, CreditCard, Settings, Key, PauseCircle, PlayCircle, BarChart2, Eye } from 'lucide-react';
import { billingService } from '../services/billingService';
import SubAccountCredentials from '../components/SubAccountCredentials';
import SubAccountUsage from '../components/SubAccountUsage';
import toast from 'react-hot-toast';

interface SubAccount {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'paused';
  usage: {
    responses: number;
    credits: number;
    activeUsers: number;
    lastActive: Date;
  };
  url: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  billingSettings: {
    autoReloadEnabled: boolean;
    autoReloadThreshold: number;
    autoReloadAmount: number;
  };
  credentials?: {
    username: string;
    passwordHash: string;
    lastUpdated: Date;
  };
  analytics: {
    monthlyActiveUsers: number;
    totalConversations: number;
    avgResponseTime: number;
    satisfactionRate: number;
  };
}

const SubAccounts: React.FC = () => {
  const [subAccounts, setSubAccounts] = useState<SubAccount[]>([
    {
      id: '1',
      name: 'Sub Account 1',
      status: 'active',
      usage: {
        responses: 1234,
        credits: 2000,
        activeUsers: 45,
        lastActive: new Date()
      },
      url: 'https://sub1.example.com',
      companyName: 'Company A',
      contactPerson: 'John Doe',
      email: 'john@companya.com',
      phone: '+1 234 567 890',
      billingSettings: {
        autoReloadEnabled: true,
        autoReloadThreshold: 100,
        autoReloadAmount: 500
      },
      analytics: {
        monthlyActiveUsers: 450,
        totalConversations: 1200,
        avgResponseTime: 2.5,
        satisfactionRate: 92
      }
    }
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<SubAccount | null>(null);
  const [showCredentials, setShowCredentials] = useState<string | null>(null);
  const [showUsage, setShowUsage] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<SubAccount>>({
    name: '',
    companyName: '',
    contactPerson: '',
    email: '',
    phone: '',
    url: '',
    billingSettings: {
      autoReloadEnabled: false,
      autoReloadThreshold: 100,
      autoReloadAmount: 500
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setFormData(prev => ({
        ...prev,
        billingSettings: {
          ...prev.billingSettings!,
          [name]: checkbox.checked
        }
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleEdit = (account: SubAccount) => {
    setEditingAccount(account);
    setFormData(account);
    setIsModalOpen(true);
  };

  const handleCredentialsUpdate = async (accountId: string, credentials: { username: string; password: string }) => {
    try {
      setSubAccounts(prev => prev.map(acc => 
        acc.id === accountId ? {
          ...acc,
          credentials: {
            username: credentials.username,
            passwordHash: 'hashed_password_here',
            lastUpdated: new Date()
          }
        } : acc
      ));
      toast.success('Login credentials updated successfully');
    } catch (error) {
      toast.error('Failed to update login credentials');
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingAccount) {
        setSubAccounts(prev => prev.map(acc => 
          acc.id === editingAccount.id ? { ...acc, ...formData } : acc
        ));
        toast.success('Sub-account updated successfully');
      } else {
        const newAccount: SubAccount = {
          ...formData as SubAccount,
          id: `sub_${Date.now()}`,
          status: 'active',
          usage: { responses: 0, credits: 0, activeUsers: 0, lastActive: new Date() },
          analytics: {
            monthlyActiveUsers: 0,
            totalConversations: 0,
            avgResponseTime: 0,
            satisfactionRate: 0
          }
        };
        setSubAccounts(prev => [...prev, newAccount]);
        setShowCredentials(newAccount.id);
        toast.success('Sub-account created successfully');
      }
      setIsModalOpen(false);
      setEditingAccount(null);
      setFormData({
        name: '',
        companyName: '',
        contactPerson: '',
        email: '',
        phone: '',
        url: '',
        billingSettings: {
          autoReloadEnabled: false,
          autoReloadThreshold: 100,
          autoReloadAmount: 500
        }
      });
    } catch (error) {
      toast.error('Failed to save sub-account');
    }
  };

  const handleDelete = async (accountId: string) => {
    try {
      setSubAccounts(prev => prev.filter(acc => acc.id !== accountId));
      toast.success('Sub-account deleted successfully');
    } catch (error) {
      toast.error('Failed to delete sub-account');
    }
  };

  const handleStatusToggle = async (accountId: string) => {
    try {
      setSubAccounts(prev => prev.map(acc => 
        acc.id === accountId ? {
          ...acc,
          status: acc.status === 'active' ? 'paused' : 'active'
        } : acc
      ));
      toast.success(`Account ${accountId} ${subAccounts.find(acc => acc.id === accountId)?.status === 'active' ? 'paused' : 'activated'}`);
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const getStatusColor = (status: SubAccount['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'inactive':
        return 'bg-red-100 text-red-800';
    }
  };

  const getStatusIcon = (status: SubAccount['status']) => {
    switch (status) {
      case 'active':
        return <PlayCircle className="h-5 w-5 text-green-500" />;
      case 'paused':
        return <PauseCircle className="h-5 w-5 text-yellow-500" />;
      case 'inactive':
        return <X className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Sub-Accounts</h1>
        <button
          onClick={() => {
            setEditingAccount(null);
            setIsModalOpen(true);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 flex items-center"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Sub-Account
        </button>
      </div>

      <div className="bg-white shadow-lg rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account Details</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Analytics</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {subAccounts.map((account) => (
              <tr key={account.id}>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-gray-900">{account.name}</span>
                    <span className="text-sm text-gray-500">{account.companyName}</span>
                    <span className="text-sm text-gray-500">{account.email}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-900">{account.usage.responses} responses</span>
                    <span className="text-sm text-gray-500">{account.usage.credits} credits</span>
                    <span className="text-sm text-gray-500">{account.usage.activeUsers} active users</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => handleStatusToggle(account.id)}
                    className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(account.status)}`}
                  >
                    {getStatusIcon(account.status)}
                    <span>{account.status}</span>
                  </button>
                </td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => setShowUsage(account.id)}
                    className="flex items-center text-indigo-600 hover:text-indigo-900"
                  >
                    <BarChart2 className="h-5 w-5 mr-1" />
                    View Analytics
                  </button>
                </td>
                <td className="px-6 py-4 space-x-2">
                  <button
                    onClick={() => handleEdit(account)}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    <Edit className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setShowCredentials(account.id)}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    <Key className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(account.id)}
                    className="text-red-600 hover:text-red-900"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {editingAccount ? 'Edit Sub-Account' : 'Create New Sub-Account'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-500 hover:text-gray-700">
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Sub-Account Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Company Name</label>
                  <input
                    type="text"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Contact Person</label>
                  <input
                    type="text"
                    name="contactPerson"
                    value={formData.contactPerson}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">URL</label>
                  <input
                    type="url"
                    name="url"
                    value={formData.url}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>

              {/* Billing Settings */}
              <div className="border-t pt-4 mt-4">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  Billing Settings
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      name="autoReloadEnabled"
                      checked={formData.billingSettings?.autoReloadEnabled}
                      onChange={handleInputChange}
                      className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                    />
                    <label className="ml-2 block text-sm text-gray-900">
                      Enable Auto-reload
                    </label>
                  </div>
                  {formData.billingSettings?.autoReloadEnabled && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Reload Threshold (credits)
                        </label>
                        <input
                          type="number"
                          name="autoReloadThreshold"
                          value={formData.billingSettings?.autoReloadThreshold}
                          onChange={handleInputChange}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          min="1"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Reload Amount (credits)
                        </label>
                        <input
                          type="number"
                          name="autoReloadAmount"
                          value={formData.billingSettings?.autoReloadAmount}
                          onChange={handleInputChange}
                          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                          min="1"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  {editingAccount ? 'Save Changes' : 'Create Sub-Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Credentials Modal */}
      {showCredentials && (
        <SubAccountCredentials
          subAccountId={showCredentials}
          email={subAccounts.find(acc => acc.id === showCredentials)?.email || ''}
          onCredentialsUpdate={(credentials) => handleCredentialsUpdate(showCredentials, credentials)}
          onClose={() => setShowCredentials(null)}
        />
      )}

      {/* Usage Modal */}
      {showUsage && (
        <SubAccountUsage
          account={subAccounts.find(acc => acc.id === showUsage)!}
          onClose={() => setShowUsage(null)}
        />
      )}
    </div>
  );
};

export default SubAccounts;