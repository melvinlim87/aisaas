import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './contexts/ThemeContext';
import DeviceRedirect from './components/DeviceRedirect';

// Auth Pages
import Login from './pages/auth/Login';
import ForgotPassword from './pages/auth/ForgotPassword';
import ResetPassword from './pages/auth/ResetPassword';
import SubAccountLogin from './pages/auth/SubAccountLogin';

// Main Pages
import Dashboard from './pages/Dashboard';
import Chatbot from './pages/Chatbot';
import CRM from './pages/CRM';
import KnowledgeBase from './pages/KnowledgeBase';
import Appointments from './pages/Appointments';
import AISettings from './pages/AISettings';
import AITraining from './pages/AITraining';
import Wallet from './pages/Wallet';
import SubAccounts from './pages/SubAccounts';
import AdminSettings from './pages/AdminSettings';
import Conversations from './pages/Conversations';
import Tickets from './pages/Tickets';
import UserManagement from './pages/UserManagement';
import AboutAndLogs from './pages/AboutAndLogs';
import AnalyticsAssistant from './pages/AnalyticsAssistant';
import LiveAgentDashboard from './pages/LiveAgentDashboard';
import CompanyProfile from './pages/CompanyProfile';
import ExternalChatEmbed from './pages/ExternalChatEmbed';
import ExternalChatbot from './pages/ExternalChatbot';

// Components
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import PrivateRoute from './components/PrivateRoute';

// Auth Service
import { authService } from './services/authService';

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <Router>
        <Toaster position="top-right" />
        <DeviceRedirect />
        <Routes>
          {/* Public Routes */}
          <Route path="/login" element={
            authService.isAuthenticated() ? <Navigate to="/" /> : <Login />
          } />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/sub-account/login" element={<SubAccountLogin />} />
          <Route path="/external-chat" element={<ExternalChatEmbed />} />

          {/* Protected Routes */}
          <Route element={<PrivateRoute />}>
            <Route path="/" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Dashboard />
                  </main>
                </div>
              </>
            } />

            <Route path="/chatbot" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Chatbot />
                  </main>
                </div>
              </>
            } />

            <Route path="/external-chatbot" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <ExternalChatbot />
                  </main>
                </div>
              </>
            } />

            <Route path="/crm" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <CRM />
                  </main>
                </div>
              </>
            } />

            <Route path="/knowledge-base" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <KnowledgeBase />
                  </main>
                </div>
              </>
            } />

            <Route path="/appointments" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Appointments />
                  </main>
                </div>
              </>
            } />

            <Route path="/ai-training/settings" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <AISettings />
                  </main>
                </div>
              </>
            } />

            <Route path="/ai-training/chatbot" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <AITraining />
                  </main>
                </div>
              </>
            } />

            <Route path="/wallet" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Wallet />
                  </main>
                </div>
              </>
            } />

            <Route path="/sub-accounts" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <SubAccounts />
                  </main>
                </div>
              </>
            } />

            <Route path="/admin/settings" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <AdminSettings />
                  </main>
                </div>
              </>
            } />

            <Route path="/conversations" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Conversations />
                  </main>
                </div>
              </>
            } />

            <Route path="/tickets" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <Tickets />
                  </main>
                </div>
              </>
            } />

            <Route path="/admin/users" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <UserManagement />
                  </main>
                </div>
              </>
            } />

            <Route path="/about" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <AboutAndLogs />
                  </main>
                </div>
              </>
            } />

            <Route path="/analytics-assistant" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <AnalyticsAssistant />
                  </main>
                </div>
              </>
            } />

            <Route path="/admin/live-chat" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <LiveAgentDashboard />
                  </main>
                </div>
              </>
            } />

            <Route path="/profile" element={
              <>
                <Header />
                <div className="flex flex-1">
                  <Sidebar />
                  <main className="flex-1 p-6 overflow-y-auto">
                    <CompanyProfile />
                  </main>
                </div>
              </>
            } />
          </Route>
        </Routes>
      </Router>
    </ThemeProvider>
  );
};

export default App;